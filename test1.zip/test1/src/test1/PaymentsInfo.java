/**
 */
package test1;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Payments Info</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.PaymentsInfo#getPaymentId <em>Payment Id</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getCardNo <em>Card No</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getExpiryDate <em>Expiry Date</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getCardHolderName <em>Card Holder Name</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getCvv <em>Cvv</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getCardId <em>Card Id</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getTransactions <em>Transactions</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getOrder <em>Order</em>}</li>
 *   <li>{@link test1.PaymentsInfo#getCard <em>Card</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getPaymentsInfo()
 * @model
 * @generated
 */
public interface PaymentsInfo extends EObject {
	/**
	 * Returns the value of the '<em><b>Payment Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Payment Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payment Id</em>' attribute.
	 * @see #setPaymentId(String)
	 * @see test1.Test1Package#getPaymentsInfo_PaymentId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getPaymentId();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getPaymentId <em>Payment Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payment Id</em>' attribute.
	 * @see #getPaymentId()
	 * @generated
	 */
	void setPaymentId(String value);

	/**
	 * Returns the value of the '<em><b>Card No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Card No</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card No</em>' attribute.
	 * @see #setCardNo(int)
	 * @see test1.Test1Package#getPaymentsInfo_CardNo()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getCardNo();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getCardNo <em>Card No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card No</em>' attribute.
	 * @see #getCardNo()
	 * @generated
	 */
	void setCardNo(int value);

	/**
	 * Returns the value of the '<em><b>Expiry Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Expiry Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Expiry Date</em>' attribute.
	 * @see #setExpiryDate(String)
	 * @see test1.Test1Package#getPaymentsInfo_ExpiryDate()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getExpiryDate();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getExpiryDate <em>Expiry Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Expiry Date</em>' attribute.
	 * @see #getExpiryDate()
	 * @generated
	 */
	void setExpiryDate(String value);

	/**
	 * Returns the value of the '<em><b>Card Holder Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Card Holder Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card Holder Name</em>' attribute.
	 * @see #setCardHolderName(String)
	 * @see test1.Test1Package#getPaymentsInfo_CardHolderName()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getCardHolderName();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getCardHolderName <em>Card Holder Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card Holder Name</em>' attribute.
	 * @see #getCardHolderName()
	 * @generated
	 */
	void setCardHolderName(String value);

	/**
	 * Returns the value of the '<em><b>Cvv</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cvv</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cvv</em>' attribute.
	 * @see #setCvv(int)
	 * @see test1.Test1Package#getPaymentsInfo_Cvv()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getCvv();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getCvv <em>Cvv</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cvv</em>' attribute.
	 * @see #getCvv()
	 * @generated
	 */
	void setCvv(int value);

	/**
	 * Returns the value of the '<em><b>Card Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Card Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card Id</em>' reference.
	 * @see #setCardId(Card)
	 * @see test1.Test1Package#getPaymentsInfo_CardId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Card getCardId();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getCardId <em>Card Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card Id</em>' reference.
	 * @see #getCardId()
	 * @generated
	 */
	void setCardId(Card value);

	/**
	 * Returns the value of the '<em><b>User Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Id</em>' reference.
	 * @see #setUserId(UserDetails)
	 * @see test1.Test1Package#getPaymentsInfo_UserId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	UserDetails getUserId();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getUserId <em>User Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Id</em>' reference.
	 * @see #getUserId()
	 * @generated
	 */
	void setUserId(UserDetails value);

	/**
	 * Returns the value of the '<em><b>Transactions</b></em>' container reference list.
	 * The list contents are of type {@link test1.Transactions}.
	 * It is bidirectional and its opposite is '{@link test1.Transactions#getPaymentsInfo <em>Payments Info</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transactions</em>' container reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transactions</em>' container reference list.
	 * @see test1.Test1Package#getPaymentsInfo_Transactions()
	 * @see test1.Transactions#getPaymentsInfo
	 * @model opposite="paymentsInfo" required="true" transient="false" ordered="false"
	 * @generated
	 */
	EList<Transactions> getTransactions();

	/**
	 * Returns the value of the '<em><b>Order</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Order#getPaymentsInfo <em>Payments Info</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order</em>' reference.
	 * @see #setOrder(Order)
	 * @see test1.Test1Package#getPaymentsInfo_Order()
	 * @see test1.Order#getPaymentsInfo
	 * @model opposite="paymentsInfo" required="true" ordered="false"
	 * @generated
	 */
	Order getOrder();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getOrder <em>Order</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order</em>' reference.
	 * @see #getOrder()
	 * @generated
	 */
	void setOrder(Order value);

	/**
	 * Returns the value of the '<em><b>Card</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Card#getPaymentsInfo <em>Payments Info</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Card</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card</em>' reference.
	 * @see #setCard(Card)
	 * @see test1.Test1Package#getPaymentsInfo_Card()
	 * @see test1.Card#getPaymentsInfo
	 * @model opposite="paymentsInfo" required="true" ordered="false"
	 * @generated
	 */
	Card getCard();

	/**
	 * Sets the value of the '{@link test1.PaymentsInfo#getCard <em>Card</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card</em>' reference.
	 * @see #getCard()
	 * @generated
	 */
	void setCard(Card value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='cardNo attribute in the PaymentsInfo class is a positive integer.'"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setCardNo();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setExpiryDate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setCardHolderName();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setCvv();

} // PaymentsInfo
