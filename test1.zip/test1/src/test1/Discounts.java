/**
 */
package test1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Discounts</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Discounts#getPromotionId <em>Promotion Id</em>}</li>
 *   <li>{@link test1.Discounts#getPromotionName <em>Promotion Name</em>}</li>
 *   <li>{@link test1.Discounts#getPromotionCode <em>Promotion Code</em>}</li>
 *   <li>{@link test1.Discounts#getOrder <em>Order</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getDiscounts()
 * @model
 * @generated
 */
public interface Discounts extends EObject {
	/**
	 * Returns the value of the '<em><b>Promotion Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Promotion Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Promotion Id</em>' attribute.
	 * @see #setPromotionId(String)
	 * @see test1.Test1Package#getDiscounts_PromotionId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getPromotionId();

	/**
	 * Sets the value of the '{@link test1.Discounts#getPromotionId <em>Promotion Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Promotion Id</em>' attribute.
	 * @see #getPromotionId()
	 * @generated
	 */
	void setPromotionId(String value);

	/**
	 * Returns the value of the '<em><b>Promotion Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Promotion Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Promotion Name</em>' attribute.
	 * @see #setPromotionName(String)
	 * @see test1.Test1Package#getDiscounts_PromotionName()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getPromotionName();

	/**
	 * Sets the value of the '{@link test1.Discounts#getPromotionName <em>Promotion Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Promotion Name</em>' attribute.
	 * @see #getPromotionName()
	 * @generated
	 */
	void setPromotionName(String value);

	/**
	 * Returns the value of the '<em><b>Promotion Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Promotion Code</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Promotion Code</em>' attribute.
	 * @see #setPromotionCode(String)
	 * @see test1.Test1Package#getDiscounts_PromotionCode()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getPromotionCode();

	/**
	 * Sets the value of the '{@link test1.Discounts#getPromotionCode <em>Promotion Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Promotion Code</em>' attribute.
	 * @see #getPromotionCode()
	 * @generated
	 */
	void setPromotionCode(String value);

	/**
	 * Returns the value of the '<em><b>Order</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Order#getDiscounts <em>Discounts</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order</em>' reference.
	 * @see #setOrder(Order)
	 * @see test1.Test1Package#getDiscounts_Order()
	 * @see test1.Order#getDiscounts
	 * @model opposite="discounts" required="true" ordered="false"
	 * @generated
	 */
	Order getOrder();

	/**
	 * Sets the value of the '{@link test1.Discounts#getOrder <em>Order</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order</em>' reference.
	 * @see #getOrder()
	 * @generated
	 */
	void setOrder(Order value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setPromotionId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setPromotionName();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setPromotionCode();

} // Discounts
