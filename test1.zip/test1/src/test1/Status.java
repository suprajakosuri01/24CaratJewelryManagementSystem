/**
 */
package test1;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Status</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Status#getStatusId <em>Status Id</em>}</li>
 *   <li>{@link test1.Status#getStatusType <em>Status Type</em>}</li>
 *   <li>{@link test1.Status#getTransactions <em>Transactions</em>}</li>
 *   <li>{@link test1.Status#getOrder <em>Order</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getStatus()
 * @model
 * @generated
 */
public interface Status extends EObject {
	/**
	 * Returns the value of the '<em><b>Status Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Status Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status Id</em>' attribute.
	 * @see #setStatusId(String)
	 * @see test1.Test1Package#getStatus_StatusId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getStatusId();

	/**
	 * Sets the value of the '{@link test1.Status#getStatusId <em>Status Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status Id</em>' attribute.
	 * @see #getStatusId()
	 * @generated
	 */
	void setStatusId(String value);

	/**
	 * Returns the value of the '<em><b>Status Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Status Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status Type</em>' attribute.
	 * @see #setStatusType(String)
	 * @see test1.Test1Package#getStatus_StatusType()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getStatusType();

	/**
	 * Sets the value of the '{@link test1.Status#getStatusType <em>Status Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status Type</em>' attribute.
	 * @see #getStatusType()
	 * @generated
	 */
	void setStatusType(String value);

	/**
	 * Returns the value of the '<em><b>Transactions</b></em>' reference list.
	 * The list contents are of type {@link test1.Transactions}.
	 * It is bidirectional and its opposite is '{@link test1.Transactions#getStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transactions</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transactions</em>' reference list.
	 * @see test1.Test1Package#getStatus_Transactions()
	 * @see test1.Transactions#getStatus
	 * @model opposite="status" required="true" ordered="false"
	 * @generated
	 */
	EList<Transactions> getTransactions();

	/**
	 * Returns the value of the '<em><b>Order</b></em>' container reference list.
	 * The list contents are of type {@link test1.Order}.
	 * It is bidirectional and its opposite is '{@link test1.Order#getStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order</em>' container reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order</em>' container reference list.
	 * @see test1.Test1Package#getStatus_Order()
	 * @see test1.Order#getStatus
	 * @model opposite="status" required="true" transient="false" ordered="false"
	 * @generated
	 */
	EList<Order> getOrder();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='inv: status.statusType = \'Pending\' or status.statusType = \'Shipped\' or status.statusType = \'Delivered\''"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setStatusId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setStatusType();

} // Status
