/**
 */
package test1.util;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import test1.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see test1.Test1Package
 * @generated
 */
public class Test1Validator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final Test1Validator INSTANCE = new Test1Validator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "test1";

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Card'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CARD__CONSTRAINT1 = 1;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Payments Info'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int PAYMENTS_INFO__CONSTRAINT1 = 2;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'User Details'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int USER_DETAILS__CONSTRAINT1 = 3;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Delivery Agent'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int DELIVERY_AGENT__CONSTRAINT1 = 4;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Location'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int LOCATION__CONSTRAINT1 = 5;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Status'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int STATUS__CONSTRAINT1 = 6;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Catalog'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CATALOG__CONSTRAINT1 = 7;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Product'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int PRODUCT__CONSTRAINT1 = 8;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Product Category'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int PRODUCT_CATEGORY__CONSTRAINT1 = 9;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Order Items'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int ORDER_ITEMS__CONSTRAINT1 = 10;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Constraint1' of 'Ratings'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int RATINGS__CONSTRAINT1 = 11;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 11;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Test1Validator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return Test1Package.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case Test1Package.CARD:
				return validateCard((Card)value, diagnostics, context);
			case Test1Package.PAYMENTS_INFO:
				return validatePaymentsInfo((PaymentsInfo)value, diagnostics, context);
			case Test1Package.USER_DETAILS:
				return validateUserDetails((UserDetails)value, diagnostics, context);
			case Test1Package.DELIVERY_AGENT:
				return validateDeliveryAgent((DeliveryAgent)value, diagnostics, context);
			case Test1Package.PERSON:
				return validatePerson((Person)value, diagnostics, context);
			case Test1Package.DATE:
				return validateDate((Date)value, diagnostics, context);
			case Test1Package.CUSTOMER:
				return validateCustomer((Customer)value, diagnostics, context);
			case Test1Package.ADDRESS:
				return validateAddress((Address)value, diagnostics, context);
			case Test1Package.LOCATION:
				return validateLocation((Location)value, diagnostics, context);
			case Test1Package.ZIPCODE:
				return validateZipcode((Zipcode)value, diagnostics, context);
			case Test1Package.TRANSACTIONS:
				return validateTransactions((Transactions)value, diagnostics, context);
			case Test1Package.ORDER:
				return validateOrder((Order)value, diagnostics, context);
			case Test1Package.STATUS:
				return validateStatus((Status)value, diagnostics, context);
			case Test1Package.DISCOUNTS:
				return validateDiscounts((Discounts)value, diagnostics, context);
			case Test1Package.CATALOG:
				return validateCatalog((Catalog)value, diagnostics, context);
			case Test1Package.PRODUCT:
				return validateProduct((Product)value, diagnostics, context);
			case Test1Package.PRODUCT_CATEGORY:
				return validateProductCategory((ProductCategory)value, diagnostics, context);
			case Test1Package.ORDER_ITEMS:
				return validateOrderItems((OrderItems)value, diagnostics, context);
			case Test1Package.RATINGS:
				return validateRatings((Ratings)value, diagnostics, context);
			case Test1Package.ORDER_FEEDBACK:
				return validateOrderFeedback((OrderFeedback)value, diagnostics, context);
			case Test1Package.PRIMITIVE_TYPES_DATE:
				return validatePrimitiveTypesDate((PrimitiveTypesDate)value, diagnostics, context);
			case Test1Package.TEST1_DATE:
				return validatetest1Date((test1Date)value, diagnostics, context);
			case Test1Package.TEST1_DATE:
				return validatetest1Date((test1Date)value, diagnostics, context);
			case Test1Package.GENDER:
				return validateGender((Gender)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCard(Card card, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(card, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(card, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(card, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(card, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(card, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(card, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(card, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(card, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(card, diagnostics, context);
		if (result || diagnostics != null) result &= validateCard_constraint1(card, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Card</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCard_constraint1(Card card, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return card.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePaymentsInfo(PaymentsInfo paymentsInfo, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(paymentsInfo, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(paymentsInfo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(paymentsInfo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(paymentsInfo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(paymentsInfo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(paymentsInfo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(paymentsInfo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(paymentsInfo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(paymentsInfo, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaymentsInfo_constraint1(paymentsInfo, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Payments Info</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePaymentsInfo_constraint1(PaymentsInfo paymentsInfo, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return paymentsInfo.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUserDetails(UserDetails userDetails, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(userDetails, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(userDetails, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(userDetails, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(userDetails, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(userDetails, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(userDetails, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(userDetails, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(userDetails, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(userDetails, diagnostics, context);
		if (result || diagnostics != null) result &= validateUserDetails_constraint1(userDetails, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>User Details</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUserDetails_constraint1(UserDetails userDetails, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return userDetails.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDeliveryAgent(DeliveryAgent deliveryAgent, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(deliveryAgent, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(deliveryAgent, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(deliveryAgent, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(deliveryAgent, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(deliveryAgent, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(deliveryAgent, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(deliveryAgent, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(deliveryAgent, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(deliveryAgent, diagnostics, context);
		if (result || diagnostics != null) result &= validateDeliveryAgent_constraint1(deliveryAgent, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Delivery Agent</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDeliveryAgent_constraint1(DeliveryAgent deliveryAgent, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return deliveryAgent.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePerson(Person person, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(person, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDate(Date date, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(date, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCustomer(Customer customer, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(customer, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAddress(Address address, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(address, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLocation(Location location, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(location, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(location, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(location, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(location, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(location, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(location, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(location, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(location, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(location, diagnostics, context);
		if (result || diagnostics != null) result &= validateLocation_constraint1(location, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLocation_constraint1(Location location, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return location.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateZipcode(Zipcode zipcode, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(zipcode, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTransactions(Transactions transactions, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(transactions, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOrder(Order order, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(order, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStatus(Status status, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(status, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(status, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(status, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(status, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(status, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(status, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(status, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(status, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(status, diagnostics, context);
		if (result || diagnostics != null) result &= validateStatus_constraint1(status, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Status</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStatus_constraint1(Status status, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return status.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDiscounts(Discounts discounts, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(discounts, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCatalog(Catalog catalog, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(catalog, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(catalog, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(catalog, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(catalog, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(catalog, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(catalog, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(catalog, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(catalog, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(catalog, diagnostics, context);
		if (result || diagnostics != null) result &= validateCatalog_constraint1(catalog, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Catalog</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCatalog_constraint1(Catalog catalog, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return catalog.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProduct(Product product, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(product, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(product, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(product, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(product, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(product, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(product, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(product, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(product, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(product, diagnostics, context);
		if (result || diagnostics != null) result &= validateProduct_constraint1(product, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Product</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProduct_constraint1(Product product, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return product.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProductCategory(ProductCategory productCategory, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(productCategory, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(productCategory, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(productCategory, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(productCategory, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(productCategory, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(productCategory, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(productCategory, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(productCategory, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(productCategory, diagnostics, context);
		if (result || diagnostics != null) result &= validateProductCategory_constraint1(productCategory, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Product Category</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProductCategory_constraint1(ProductCategory productCategory, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return productCategory.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOrderItems(OrderItems orderItems, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(orderItems, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(orderItems, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(orderItems, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(orderItems, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(orderItems, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(orderItems, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(orderItems, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(orderItems, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(orderItems, diagnostics, context);
		if (result || diagnostics != null) result &= validateOrderItems_constraint1(orderItems, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Order Items</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOrderItems_constraint1(OrderItems orderItems, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return orderItems.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRatings(Ratings ratings, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(ratings, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(ratings, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(ratings, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(ratings, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(ratings, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(ratings, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(ratings, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(ratings, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(ratings, diagnostics, context);
		if (result || diagnostics != null) result &= validateRatings_constraint1(ratings, diagnostics, context);
		return result;
	}

	/**
	 * Validates the constraint1 constraint of '<em>Ratings</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRatings_constraint1(Ratings ratings, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return ratings.constraint1(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOrderFeedback(OrderFeedback orderFeedback, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(orderFeedback, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePrimitiveTypesDate(PrimitiveTypesDate primitiveTypesDate, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(primitiveTypesDate, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatetest1Date(test1Date test1Date, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(test1Date, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatetest1Date(test1Date test1Date, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(test1Date, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatetest1Date(test1Date test1Date, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(test1Date, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatetest1Date(test1Date test1Date, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(test1Date, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatetest1Date(test1Date test1Date, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(test1Date, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateGender(Gender gender, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //Test1Validator
