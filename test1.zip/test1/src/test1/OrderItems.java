/**
 */
package test1;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Order Items</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.OrderItems#getOrderItemsId <em>Order Items Id</em>}</li>
 *   <li>{@link test1.OrderItems#getProductQuantity <em>Product Quantity</em>}</li>
 *   <li>{@link test1.OrderItems#getProductId <em>Product Id</em>}</li>
 *   <li>{@link test1.OrderItems#getOrderId <em>Order Id</em>}</li>
 *   <li>{@link test1.OrderItems#getProduct <em>Product</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getOrderItems()
 * @model
 * @generated
 */
public interface OrderItems extends EObject {
	/**
	 * Returns the value of the '<em><b>Order Items Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Items Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Items Id</em>' attribute.
	 * @see #setOrderItemsId(String)
	 * @see test1.Test1Package#getOrderItems_OrderItemsId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getOrderItemsId();

	/**
	 * Sets the value of the '{@link test1.OrderItems#getOrderItemsId <em>Order Items Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Items Id</em>' attribute.
	 * @see #getOrderItemsId()
	 * @generated
	 */
	void setOrderItemsId(String value);

	/**
	 * Returns the value of the '<em><b>Product Quantity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Quantity</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Quantity</em>' attribute.
	 * @see #setProductQuantity(int)
	 * @see test1.Test1Package#getOrderItems_ProductQuantity()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getProductQuantity();

	/**
	 * Sets the value of the '{@link test1.OrderItems#getProductQuantity <em>Product Quantity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Quantity</em>' attribute.
	 * @see #getProductQuantity()
	 * @generated
	 */
	void setProductQuantity(int value);

	/**
	 * Returns the value of the '<em><b>Product Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Id</em>' reference.
	 * @see #setProductId(Product)
	 * @see test1.Test1Package#getOrderItems_ProductId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Product getProductId();

	/**
	 * Sets the value of the '{@link test1.OrderItems#getProductId <em>Product Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Id</em>' reference.
	 * @see #getProductId()
	 * @generated
	 */
	void setProductId(Product value);

	/**
	 * Returns the value of the '<em><b>Order Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Id</em>' reference.
	 * @see #setOrderId(Order)
	 * @see test1.Test1Package#getOrderItems_OrderId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Order getOrderId();

	/**
	 * Sets the value of the '{@link test1.OrderItems#getOrderId <em>Order Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Id</em>' reference.
	 * @see #getOrderId()
	 * @generated
	 */
	void setOrderId(Order value);

	/**
	 * Returns the value of the '<em><b>Product</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link test1.Product#getOrderItems <em>Order Items</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product</em>' container reference.
	 * @see #setProduct(Product)
	 * @see test1.Test1Package#getOrderItems_Product()
	 * @see test1.Product#getOrderItems
	 * @model opposite="orderItems" required="true" transient="false" ordered="false"
	 * @generated
	 */
	Product getProduct();

	/**
	 * Sets the value of the '{@link test1.OrderItems#getProduct <em>Product</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product</em>' container reference.
	 * @see #getProduct()
	 * @generated
	 */
	void setProduct(Product value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='productQuantity attribute is a non-negative integer'"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setOrderItemsId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setProductQuantity();

} // OrderItems
