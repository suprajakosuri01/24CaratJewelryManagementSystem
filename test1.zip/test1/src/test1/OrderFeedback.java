/**
 */
package test1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Order Feedback</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.OrderFeedback#getProductFeedback <em>Product Feedback</em>}</li>
 *   <li>{@link test1.OrderFeedback#getDeliveryAgentFeedback <em>Delivery Agent Feedback</em>}</li>
 *   <li>{@link test1.OrderFeedback#getProductRatingId <em>Product Rating Id</em>}</li>
 *   <li>{@link test1.OrderFeedback#getDeliveryAgentRatingId <em>Delivery Agent Rating Id</em>}</li>
 *   <li>{@link test1.OrderFeedback#getRatingId <em>Rating Id</em>}</li>
 *   <li>{@link test1.OrderFeedback#getOrderId <em>Order Id</em>}</li>
 *   <li>{@link test1.OrderFeedback#getRatings <em>Ratings</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getOrderFeedback()
 * @model
 * @generated
 */
public interface OrderFeedback extends EObject {
	/**
	 * Returns the value of the '<em><b>Product Feedback</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Feedback</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Feedback</em>' attribute.
	 * @see #setProductFeedback(String)
	 * @see test1.Test1Package#getOrderFeedback_ProductFeedback()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getProductFeedback();

	/**
	 * Sets the value of the '{@link test1.OrderFeedback#getProductFeedback <em>Product Feedback</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Feedback</em>' attribute.
	 * @see #getProductFeedback()
	 * @generated
	 */
	void setProductFeedback(String value);

	/**
	 * Returns the value of the '<em><b>Delivery Agent Feedback</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delivery Agent Feedback</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delivery Agent Feedback</em>' attribute.
	 * @see #setDeliveryAgentFeedback(String)
	 * @see test1.Test1Package#getOrderFeedback_DeliveryAgentFeedback()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getDeliveryAgentFeedback();

	/**
	 * Sets the value of the '{@link test1.OrderFeedback#getDeliveryAgentFeedback <em>Delivery Agent Feedback</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delivery Agent Feedback</em>' attribute.
	 * @see #getDeliveryAgentFeedback()
	 * @generated
	 */
	void setDeliveryAgentFeedback(String value);

	/**
	 * Returns the value of the '<em><b>Product Rating Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Rating Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Rating Id</em>' attribute.
	 * @see #setProductRatingId(String)
	 * @see test1.Test1Package#getOrderFeedback_ProductRatingId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getProductRatingId();

	/**
	 * Sets the value of the '{@link test1.OrderFeedback#getProductRatingId <em>Product Rating Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Rating Id</em>' attribute.
	 * @see #getProductRatingId()
	 * @generated
	 */
	void setProductRatingId(String value);

	/**
	 * Returns the value of the '<em><b>Delivery Agent Rating Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delivery Agent Rating Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delivery Agent Rating Id</em>' reference.
	 * @see #setDeliveryAgentRatingId(DeliveryAgent)
	 * @see test1.Test1Package#getOrderFeedback_DeliveryAgentRatingId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	DeliveryAgent getDeliveryAgentRatingId();

	/**
	 * Sets the value of the '{@link test1.OrderFeedback#getDeliveryAgentRatingId <em>Delivery Agent Rating Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delivery Agent Rating Id</em>' reference.
	 * @see #getDeliveryAgentRatingId()
	 * @generated
	 */
	void setDeliveryAgentRatingId(DeliveryAgent value);

	/**
	 * Returns the value of the '<em><b>Rating Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rating Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rating Id</em>' reference.
	 * @see #setRatingId(Ratings)
	 * @see test1.Test1Package#getOrderFeedback_RatingId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Ratings getRatingId();

	/**
	 * Sets the value of the '{@link test1.OrderFeedback#getRatingId <em>Rating Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rating Id</em>' reference.
	 * @see #getRatingId()
	 * @generated
	 */
	void setRatingId(Ratings value);

	/**
	 * Returns the value of the '<em><b>Order Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Id</em>' reference.
	 * @see #setOrderId(Order)
	 * @see test1.Test1Package#getOrderFeedback_OrderId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Order getOrderId();

	/**
	 * Sets the value of the '{@link test1.OrderFeedback#getOrderId <em>Order Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Id</em>' reference.
	 * @see #getOrderId()
	 * @generated
	 */
	void setOrderId(Order value);

	/**
	 * Returns the value of the '<em><b>Ratings</b></em>' containment reference.
	 * It is bidirectional and its opposite is '{@link test1.Ratings#getOrderfeedback <em>Orderfeedback</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ratings</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ratings</em>' containment reference.
	 * @see #setRatings(Ratings)
	 * @see test1.Test1Package#getOrderFeedback_Ratings()
	 * @see test1.Ratings#getOrderfeedback
	 * @model opposite="orderfeedback" containment="true" required="true" ordered="false"
	 * @generated
	 */
	Ratings getRatings();

	/**
	 * Sets the value of the '{@link test1.OrderFeedback#getRatings <em>Ratings</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ratings</em>' containment reference.
	 * @see #getRatings()
	 * @generated
	 */
	void setRatings(Ratings value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setProductFeedback();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setDeliveryAgentFeedback();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setProductRatingId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setDeliveryAgentRatingId();

} // OrderFeedback
