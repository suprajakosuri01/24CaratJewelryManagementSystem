/**
 */
package test1;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Delivery Agent</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.DeliveryAgent#getAgentId <em>Agent Id</em>}</li>
 *   <li>{@link test1.DeliveryAgent#getContactNo <em>Contact No</em>}</li>
 *   <li>{@link test1.DeliveryAgent#getSsn <em>Ssn</em>}</li>
 *   <li>{@link test1.DeliveryAgent#getDrivingLicenseNo <em>Driving License No</em>}</li>
 *   <li>{@link test1.DeliveryAgent#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.DeliveryAgent#getUserDetails <em>User Details</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getDeliveryAgent()
 * @model
 * @generated
 */
public interface DeliveryAgent extends Person {
	/**
	 * Returns the value of the '<em><b>Agent Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agent Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agent Id</em>' attribute.
	 * @see #setAgentId(String)
	 * @see test1.Test1Package#getDeliveryAgent_AgentId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getAgentId();

	/**
	 * Sets the value of the '{@link test1.DeliveryAgent#getAgentId <em>Agent Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agent Id</em>' attribute.
	 * @see #getAgentId()
	 * @generated
	 */
	void setAgentId(String value);

	/**
	 * Returns the value of the '<em><b>Contact No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Contact No</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contact No</em>' attribute.
	 * @see #setContactNo(int)
	 * @see test1.Test1Package#getDeliveryAgent_ContactNo()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getContactNo();

	/**
	 * Sets the value of the '{@link test1.DeliveryAgent#getContactNo <em>Contact No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Contact No</em>' attribute.
	 * @see #getContactNo()
	 * @generated
	 */
	void setContactNo(int value);

	/**
	 * Returns the value of the '<em><b>Ssn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ssn</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ssn</em>' attribute.
	 * @see #setSsn(int)
	 * @see test1.Test1Package#getDeliveryAgent_Ssn()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getSsn();

	/**
	 * Sets the value of the '{@link test1.DeliveryAgent#getSsn <em>Ssn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ssn</em>' attribute.
	 * @see #getSsn()
	 * @generated
	 */
	void setSsn(int value);

	/**
	 * Returns the value of the '<em><b>Driving License No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Driving License No</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Driving License No</em>' attribute.
	 * @see #setDrivingLicenseNo(String)
	 * @see test1.Test1Package#getDeliveryAgent_DrivingLicenseNo()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getDrivingLicenseNo();

	/**
	 * Sets the value of the '{@link test1.DeliveryAgent#getDrivingLicenseNo <em>Driving License No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Driving License No</em>' attribute.
	 * @see #getDrivingLicenseNo()
	 * @generated
	 */
	void setDrivingLicenseNo(String value);

	/**
	 * Returns the value of the '<em><b>User Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Id</em>' reference.
	 * @see #setUserId(UserDetails)
	 * @see test1.Test1Package#getDeliveryAgent_UserId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	UserDetails getUserId();

	/**
	 * Sets the value of the '{@link test1.DeliveryAgent#getUserId <em>User Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Id</em>' reference.
	 * @see #getUserId()
	 * @generated
	 */
	void setUserId(UserDetails value);

	/**
	 * Returns the value of the '<em><b>User Details</b></em>' containment reference.
	 * It is bidirectional and its opposite is '{@link test1.UserDetails#getDeliveryAgent <em>Delivery Agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Details</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Details</em>' containment reference.
	 * @see #setUserDetails(UserDetails)
	 * @see test1.Test1Package#getDeliveryAgent_UserDetails()
	 * @see test1.UserDetails#getDeliveryAgent
	 * @model opposite="deliveryAgent" containment="true" required="true" ordered="false"
	 * @generated
	 */
	UserDetails getUserDetails();

	/**
	 * Sets the value of the '{@link test1.DeliveryAgent#getUserDetails <em>User Details</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Details</em>' containment reference.
	 * @see #getUserDetails()
	 * @generated
	 */
	void setUserDetails(UserDetails value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='ssn attribute in the DeliveryAgent class is not null and has a length of 9.'"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setAgentId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setContactNo();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setSsn();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setDrivingLicenseNo();

} // DeliveryAgent
