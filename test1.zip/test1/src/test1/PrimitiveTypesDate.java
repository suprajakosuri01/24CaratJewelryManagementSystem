/**
 */
package test1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Types Date</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see test1.Test1Package#getPrimitiveTypesDate()
 * @model annotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='PrimitiveTypes::Date'"
 * @generated
 */
public interface PrimitiveTypesDate extends EObject {
} // PrimitiveTypesDate
