/**
 */
package test1;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ratings</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Ratings#getRatingId <em>Rating Id</em>}</li>
 *   <li>{@link test1.Ratings#getRating <em>Rating</em>}</li>
 *   <li>{@link test1.Ratings#getOrderfeedback <em>Orderfeedback</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getRatings()
 * @model
 * @generated
 */
public interface Ratings extends EObject {
	/**
	 * Returns the value of the '<em><b>Rating Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rating Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rating Id</em>' attribute.
	 * @see #setRatingId(String)
	 * @see test1.Test1Package#getRatings_RatingId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getRatingId();

	/**
	 * Sets the value of the '{@link test1.Ratings#getRatingId <em>Rating Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rating Id</em>' attribute.
	 * @see #getRatingId()
	 * @generated
	 */
	void setRatingId(String value);

	/**
	 * Returns the value of the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rating</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rating</em>' attribute.
	 * @see #setRating(String)
	 * @see test1.Test1Package#getRatings_Rating()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getRating();

	/**
	 * Sets the value of the '{@link test1.Ratings#getRating <em>Rating</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rating</em>' attribute.
	 * @see #getRating()
	 * @generated
	 */
	void setRating(String value);

	/**
	 * Returns the value of the '<em><b>Orderfeedback</b></em>' container reference list.
	 * The list contents are of type {@link test1.OrderFeedback}.
	 * It is bidirectional and its opposite is '{@link test1.OrderFeedback#getRatings <em>Ratings</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Orderfeedback</em>' container reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Orderfeedback</em>' container reference list.
	 * @see test1.Test1Package#getRatings_Orderfeedback()
	 * @see test1.OrderFeedback#getRatings
	 * @model opposite="ratings" required="true" transient="false" ordered="false"
	 * @generated
	 */
	EList<OrderFeedback> getOrderfeedback();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='Ensures that the rating attribute is not empty'"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setRatingId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setRating();

} // Ratings
