/**
 */
package test1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Date</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see test1.Test1Package#getDate()
 * @model
 * @generated
 */
public interface Date extends EObject {
} // Date
