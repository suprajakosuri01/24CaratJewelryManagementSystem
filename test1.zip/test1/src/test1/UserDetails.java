/**
 */
package test1;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>User Details</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.UserDetails#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.UserDetails#getUsername <em>Username</em>}</li>
 *   <li>{@link test1.UserDetails#getPassword <em>Password</em>}</li>
 *   <li>{@link test1.UserDetails#getDeliveryAgent <em>Delivery Agent</em>}</li>
 *   <li>{@link test1.UserDetails#getCustomer <em>Customer</em>}</li>
 *   <li>{@link test1.UserDetails#getAddress <em>Address</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getUserDetails()
 * @model
 * @generated
 */
public interface UserDetails extends EObject {
	/**
	 * Returns the value of the '<em><b>User Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Id</em>' attribute.
	 * @see #setUserId(String)
	 * @see test1.Test1Package#getUserDetails_UserId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getUserId();

	/**
	 * Sets the value of the '{@link test1.UserDetails#getUserId <em>User Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Id</em>' attribute.
	 * @see #getUserId()
	 * @generated
	 */
	void setUserId(String value);

	/**
	 * Returns the value of the '<em><b>Username</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Username</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Username</em>' attribute.
	 * @see #setUsername(String)
	 * @see test1.Test1Package#getUserDetails_Username()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getUsername();

	/**
	 * Sets the value of the '{@link test1.UserDetails#getUsername <em>Username</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Username</em>' attribute.
	 * @see #getUsername()
	 * @generated
	 */
	void setUsername(String value);

	/**
	 * Returns the value of the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Password</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Password</em>' attribute.
	 * @see #setPassword(String)
	 * @see test1.Test1Package#getUserDetails_Password()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getPassword();

	/**
	 * Sets the value of the '{@link test1.UserDetails#getPassword <em>Password</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Password</em>' attribute.
	 * @see #getPassword()
	 * @generated
	 */
	void setPassword(String value);

	/**
	 * Returns the value of the '<em><b>Delivery Agent</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link test1.DeliveryAgent#getUserDetails <em>User Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delivery Agent</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delivery Agent</em>' container reference.
	 * @see #setDeliveryAgent(DeliveryAgent)
	 * @see test1.Test1Package#getUserDetails_DeliveryAgent()
	 * @see test1.DeliveryAgent#getUserDetails
	 * @model opposite="userDetails" required="true" transient="false" ordered="false"
	 * @generated
	 */
	DeliveryAgent getDeliveryAgent();

	/**
	 * Sets the value of the '{@link test1.UserDetails#getDeliveryAgent <em>Delivery Agent</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delivery Agent</em>' container reference.
	 * @see #getDeliveryAgent()
	 * @generated
	 */
	void setDeliveryAgent(DeliveryAgent value);

	/**
	 * Returns the value of the '<em><b>Customer</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link test1.Customer#getUserDetails <em>User Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Customer</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer</em>' container reference.
	 * @see #setCustomer(Customer)
	 * @see test1.Test1Package#getUserDetails_Customer()
	 * @see test1.Customer#getUserDetails
	 * @model opposite="userDetails" required="true" transient="false" ordered="false"
	 * @generated
	 */
	Customer getCustomer();

	/**
	 * Sets the value of the '{@link test1.UserDetails#getCustomer <em>Customer</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Customer</em>' container reference.
	 * @see #getCustomer()
	 * @generated
	 */
	void setCustomer(Customer value);

	/**
	 * Returns the value of the '<em><b>Address</b></em>' reference list.
	 * The list contents are of type {@link test1.Address}.
	 * It is bidirectional and its opposite is '{@link test1.Address#getUserDetails <em>User Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Address</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Address</em>' reference list.
	 * @see test1.Test1Package#getUserDetails_Address()
	 * @see test1.Address#getUserDetails
	 * @model opposite="userDetails" required="true" ordered="false"
	 * @generated
	 */
	EList<Address> getAddress();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='username attribute contains only alphanumeric characters'"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setUserId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setUsername();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setPassword();

} // UserDetails
