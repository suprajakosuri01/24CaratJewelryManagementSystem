/**
 */
package test1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>test1 Date</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see test1.Test1Package#gettest1Date()
 * @model annotation="http://www.eclipse.org/uml2/2.0.0/UML originalName='test1:: Date'"
 * @generated
 */
public interface test1Date extends EObject {
} // test1Date
