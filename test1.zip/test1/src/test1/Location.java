/**
 */
package test1;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Location</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Location#getLocationId <em>Location Id</em>}</li>
 *   <li>{@link test1.Location#getStreetName <em>Street Name</em>}</li>
 *   <li>{@link test1.Location#getHouseNo <em>House No</em>}</li>
 *   <li>{@link test1.Location#getZip <em>Zip</em>}</li>
 *   <li>{@link test1.Location#getZipcode <em>Zipcode</em>}</li>
 *   <li>{@link test1.Location#getAddress <em>Address</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getLocation()
 * @model
 * @generated
 */
public interface Location extends EObject {
	/**
	 * Returns the value of the '<em><b>Location Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Location Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location Id</em>' attribute.
	 * @see #setLocationId(String)
	 * @see test1.Test1Package#getLocation_LocationId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getLocationId();

	/**
	 * Sets the value of the '{@link test1.Location#getLocationId <em>Location Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location Id</em>' attribute.
	 * @see #getLocationId()
	 * @generated
	 */
	void setLocationId(String value);

	/**
	 * Returns the value of the '<em><b>Street Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Street Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Street Name</em>' attribute.
	 * @see #setStreetName(String)
	 * @see test1.Test1Package#getLocation_StreetName()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getStreetName();

	/**
	 * Sets the value of the '{@link test1.Location#getStreetName <em>Street Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Street Name</em>' attribute.
	 * @see #getStreetName()
	 * @generated
	 */
	void setStreetName(String value);

	/**
	 * Returns the value of the '<em><b>House No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>House No</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>House No</em>' attribute.
	 * @see #setHouseNo(String)
	 * @see test1.Test1Package#getLocation_HouseNo()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getHouseNo();

	/**
	 * Sets the value of the '{@link test1.Location#getHouseNo <em>House No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>House No</em>' attribute.
	 * @see #getHouseNo()
	 * @generated
	 */
	void setHouseNo(String value);

	/**
	 * Returns the value of the '<em><b>Zip</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Zip</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Zip</em>' reference.
	 * @see #setZip(Zipcode)
	 * @see test1.Test1Package#getLocation_Zip()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Zipcode getZip();

	/**
	 * Sets the value of the '{@link test1.Location#getZip <em>Zip</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Zip</em>' reference.
	 * @see #getZip()
	 * @generated
	 */
	void setZip(Zipcode value);

	/**
	 * Returns the value of the '<em><b>Zipcode</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Zipcode#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Zipcode</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Zipcode</em>' reference.
	 * @see #setZipcode(Zipcode)
	 * @see test1.Test1Package#getLocation_Zipcode()
	 * @see test1.Zipcode#getLocation
	 * @model opposite="location" required="true" ordered="false"
	 * @generated
	 */
	Zipcode getZipcode();

	/**
	 * Sets the value of the '{@link test1.Location#getZipcode <em>Zipcode</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Zipcode</em>' reference.
	 * @see #getZipcode()
	 * @generated
	 */
	void setZipcode(Zipcode value);

	/**
	 * Returns the value of the '<em><b>Address</b></em>' reference list.
	 * The list contents are of type {@link test1.Address}.
	 * It is bidirectional and its opposite is '{@link test1.Address#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Address</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Address</em>' reference list.
	 * @see test1.Test1Package#getLocation_Address()
	 * @see test1.Address#getLocation
	 * @model opposite="location" required="true" ordered="false"
	 * @generated
	 */
	EList<Address> getAddress();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='zip.code attribute follows the pattern of a standard ZIP code'"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setLocation();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setStreetName();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setHouseNo();

} // Location
