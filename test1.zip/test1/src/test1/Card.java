/**
 */
package test1;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Card</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Card#getCardId <em>Card Id</em>}</li>
 *   <li>{@link test1.Card#getCardType <em>Card Type</em>}</li>
 *   <li>{@link test1.Card#getPaymentsInfo <em>Payments Info</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getCard()
 * @model
 * @generated
 */
public interface Card extends EObject {
	/**
	 * Returns the value of the '<em><b>Card Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Card Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card Id</em>' attribute.
	 * @see #setCardId(String)
	 * @see test1.Test1Package#getCard_CardId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getCardId();

	/**
	 * Sets the value of the '{@link test1.Card#getCardId <em>Card Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card Id</em>' attribute.
	 * @see #getCardId()
	 * @generated
	 */
	void setCardId(String value);

	/**
	 * Returns the value of the '<em><b>Card Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Card Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card Type</em>' attribute.
	 * @see #setCardType(String)
	 * @see test1.Test1Package#getCard_CardType()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getCardType();

	/**
	 * Sets the value of the '{@link test1.Card#getCardType <em>Card Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card Type</em>' attribute.
	 * @see #getCardType()
	 * @generated
	 */
	void setCardType(String value);

	/**
	 * Returns the value of the '<em><b>Payments Info</b></em>' reference list.
	 * The list contents are of type {@link test1.PaymentsInfo}.
	 * It is bidirectional and its opposite is '{@link test1.PaymentsInfo#getCard <em>Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Payments Info</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payments Info</em>' reference list.
	 * @see test1.Test1Package#getCard_PaymentsInfo()
	 * @see test1.PaymentsInfo#getCard
	 * @model opposite="card" required="true" ordered="false"
	 * @generated
	 */
	EList<PaymentsInfo> getPaymentsInfo();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='cardType attribute in the Card class is either \'Debit\' or \'Credit\'.'"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setCardId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setCardType();

} // Card
