/**
 */
package test1;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Product</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Product#getProductId <em>Product Id</em>}</li>
 *   <li>{@link test1.Product#getProductName <em>Product Name</em>}</li>
 *   <li>{@link test1.Product#getProductDescripton <em>Product Descripton</em>}</li>
 *   <li>{@link test1.Product#getCategoryId <em>Category Id</em>}</li>
 *   <li>{@link test1.Product#getProductCategory <em>Product Category</em>}</li>
 *   <li>{@link test1.Product#getOrderItemsId <em>Order Items Id</em>}</li>
 *   <li>{@link test1.Product#getOrderItems <em>Order Items</em>}</li>
 *   <li>{@link test1.Product#getCatalog <em>Catalog</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getProduct()
 * @model
 * @generated
 */
public interface Product extends EObject {
	/**
	 * Returns the value of the '<em><b>Product Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Id</em>' attribute.
	 * @see #setProductId(String)
	 * @see test1.Test1Package#getProduct_ProductId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getProductId();

	/**
	 * Sets the value of the '{@link test1.Product#getProductId <em>Product Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Id</em>' attribute.
	 * @see #getProductId()
	 * @generated
	 */
	void setProductId(String value);

	/**
	 * Returns the value of the '<em><b>Product Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Name</em>' attribute.
	 * @see #setProductName(String)
	 * @see test1.Test1Package#getProduct_ProductName()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getProductName();

	/**
	 * Sets the value of the '{@link test1.Product#getProductName <em>Product Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Name</em>' attribute.
	 * @see #getProductName()
	 * @generated
	 */
	void setProductName(String value);

	/**
	 * Returns the value of the '<em><b>Product Descripton</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Descripton</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Descripton</em>' attribute.
	 * @see #setProductDescripton(String)
	 * @see test1.Test1Package#getProduct_ProductDescripton()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getProductDescripton();

	/**
	 * Sets the value of the '{@link test1.Product#getProductDescripton <em>Product Descripton</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Descripton</em>' attribute.
	 * @see #getProductDescripton()
	 * @generated
	 */
	void setProductDescripton(String value);

	/**
	 * Returns the value of the '<em><b>Category Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Category Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Category Id</em>' reference.
	 * @see #setCategoryId(ProductCategory)
	 * @see test1.Test1Package#getProduct_CategoryId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	ProductCategory getCategoryId();

	/**
	 * Sets the value of the '{@link test1.Product#getCategoryId <em>Category Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Category Id</em>' reference.
	 * @see #getCategoryId()
	 * @generated
	 */
	void setCategoryId(ProductCategory value);

	/**
	 * Returns the value of the '<em><b>Product Category</b></em>' reference list.
	 * The list contents are of type {@link test1.ProductCategory}.
	 * It is bidirectional and its opposite is '{@link test1.ProductCategory#getProduct <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Category</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Category</em>' reference list.
	 * @see test1.Test1Package#getProduct_ProductCategory()
	 * @see test1.ProductCategory#getProduct
	 * @model opposite="product" required="true" ordered="false"
	 * @generated
	 */
	EList<ProductCategory> getProductCategory();

	/**
	 * Returns the value of the '<em><b>Order Items Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Items Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Items Id</em>' reference.
	 * @see #setOrderItemsId(OrderItems)
	 * @see test1.Test1Package#getProduct_OrderItemsId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	OrderItems getOrderItemsId();

	/**
	 * Sets the value of the '{@link test1.Product#getOrderItemsId <em>Order Items Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Items Id</em>' reference.
	 * @see #getOrderItemsId()
	 * @generated
	 */
	void setOrderItemsId(OrderItems value);

	/**
	 * Returns the value of the '<em><b>Order Items</b></em>' containment reference.
	 * It is bidirectional and its opposite is '{@link test1.OrderItems#getProduct <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Items</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Items</em>' containment reference.
	 * @see #setOrderItems(OrderItems)
	 * @see test1.Test1Package#getProduct_OrderItems()
	 * @see test1.OrderItems#getProduct
	 * @model opposite="product" containment="true" required="true" ordered="false"
	 * @generated
	 */
	OrderItems getOrderItems();

	/**
	 * Sets the value of the '{@link test1.Product#getOrderItems <em>Order Items</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Items</em>' containment reference.
	 * @see #getOrderItems()
	 * @generated
	 */
	void setOrderItems(OrderItems value);

	/**
	 * Returns the value of the '<em><b>Catalog</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Catalog#getProduct <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Catalog</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Catalog</em>' reference.
	 * @see #setCatalog(Catalog)
	 * @see test1.Test1Package#getProduct_Catalog()
	 * @see test1.Catalog#getProduct
	 * @model opposite="product" ordered="false"
	 * @generated
	 */
	Catalog getCatalog();

	/**
	 * Sets the value of the '{@link test1.Product#getCatalog <em>Catalog</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Catalog</em>' reference.
	 * @see #getCatalog()
	 * @generated
	 */
	void setCatalog(Catalog value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/uml2/1.1.0/GenModel body='Each product id is unique'"
	 * @generated
	 */
	boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setProductId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setProductName();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setProductDescription();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 * @generated
	 */
	void getProductDescription();

} // Product
