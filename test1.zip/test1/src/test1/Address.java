/**
 */
package test1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Address</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Address#getAddressType <em>Address Type</em>}</li>
 *   <li>{@link test1.Address#getLocationId <em>Location Id</em>}</li>
 *   <li>{@link test1.Address#getLocation <em>Location</em>}</li>
 *   <li>{@link test1.Address#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.Address#getUserDetails <em>User Details</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getAddress()
 * @model
 * @generated
 */
public interface Address extends EObject {
	/**
	 * Returns the value of the '<em><b>Address Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Address Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Address Type</em>' attribute.
	 * @see #setAddressType(String)
	 * @see test1.Test1Package#getAddress_AddressType()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getAddressType();

	/**
	 * Sets the value of the '{@link test1.Address#getAddressType <em>Address Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Address Type</em>' attribute.
	 * @see #getAddressType()
	 * @generated
	 */
	void setAddressType(String value);

	/**
	 * Returns the value of the '<em><b>Location Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Location Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location Id</em>' reference.
	 * @see #setLocationId(Location)
	 * @see test1.Test1Package#getAddress_LocationId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Location getLocationId();

	/**
	 * Sets the value of the '{@link test1.Address#getLocationId <em>Location Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location Id</em>' reference.
	 * @see #getLocationId()
	 * @generated
	 */
	void setLocationId(Location value);

	/**
	 * Returns the value of the '<em><b>Location</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Location#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Location</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' reference.
	 * @see #setLocation(Location)
	 * @see test1.Test1Package#getAddress_Location()
	 * @see test1.Location#getAddress
	 * @model opposite="address" required="true" ordered="false"
	 * @generated
	 */
	Location getLocation();

	/**
	 * Sets the value of the '{@link test1.Address#getLocation <em>Location</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' reference.
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(Location value);

	/**
	 * Returns the value of the '<em><b>User Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Id</em>' reference.
	 * @see #setUserId(UserDetails)
	 * @see test1.Test1Package#getAddress_UserId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	UserDetails getUserId();

	/**
	 * Sets the value of the '{@link test1.Address#getUserId <em>User Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Id</em>' reference.
	 * @see #getUserId()
	 * @generated
	 */
	void setUserId(UserDetails value);

	/**
	 * Returns the value of the '<em><b>User Details</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.UserDetails#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Details</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Details</em>' reference.
	 * @see #setUserDetails(UserDetails)
	 * @see test1.Test1Package#getAddress_UserDetails()
	 * @see test1.UserDetails#getAddress
	 * @model opposite="address" required="true" ordered="false"
	 * @generated
	 */
	UserDetails getUserDetails();

	/**
	 * Sets the value of the '{@link test1.Address#getUserDetails <em>User Details</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Details</em>' reference.
	 * @see #getUserDetails()
	 * @generated
	 */
	void setUserDetails(UserDetails value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setAddressType();

} // Address
