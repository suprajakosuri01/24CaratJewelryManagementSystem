/**
 */
package test1;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Order</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Order#getOrderId <em>Order Id</em>}</li>
 *   <li>{@link test1.Order#getOrderPrice <em>Order Price</em>}</li>
 *   <li>{@link test1.Order#getInstructions <em>Instructions</em>}</li>
 *   <li>{@link test1.Order#getDiscountedPrice <em>Discounted Price</em>}</li>
 *   <li>{@link test1.Order#getSourceLocationId <em>Source Location Id</em>}</li>
 *   <li>{@link test1.Order#getDestinationId <em>Destination Id</em>}</li>
 *   <li>{@link test1.Order#getTax <em>Tax</em>}</li>
 *   <li>{@link test1.Order#getDelivery <em>Delivery</em>}</li>
 *   <li>{@link test1.Order#getStatusId <em>Status Id</em>}</li>
 *   <li>{@link test1.Order#getStatus <em>Status</em>}</li>
 *   <li>{@link test1.Order#getAgentId <em>Agent Id</em>}</li>
 *   <li>{@link test1.Order#getPaymentId <em>Payment Id</em>}</li>
 *   <li>{@link test1.Order#getPromotionId <em>Promotion Id</em>}</li>
 *   <li>{@link test1.Order#getDiscounts <em>Discounts</em>}</li>
 *   <li>{@link test1.Order#getCustomerId <em>Customer Id</em>}</li>
 *   <li>{@link test1.Order#getTransactions <em>Transactions</em>}</li>
 *   <li>{@link test1.Order#getPaymentsInfo <em>Payments Info</em>}</li>
 *   <li>{@link test1.Order#getCatalog <em>Catalog</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getOrder()
 * @model
 * @generated
 */
public interface Order extends EObject {
	/**
	 * Returns the value of the '<em><b>Order Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Id</em>' attribute.
	 * @see #setOrderId(String)
	 * @see test1.Test1Package#getOrder_OrderId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getOrderId();

	/**
	 * Sets the value of the '{@link test1.Order#getOrderId <em>Order Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Id</em>' attribute.
	 * @see #getOrderId()
	 * @generated
	 */
	void setOrderId(String value);

	/**
	 * Returns the value of the '<em><b>Order Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Price</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Price</em>' attribute.
	 * @see #setOrderPrice(float)
	 * @see test1.Test1Package#getOrder_OrderPrice()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	float getOrderPrice();

	/**
	 * Sets the value of the '{@link test1.Order#getOrderPrice <em>Order Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Price</em>' attribute.
	 * @see #getOrderPrice()
	 * @generated
	 */
	void setOrderPrice(float value);

	/**
	 * Returns the value of the '<em><b>Instructions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instructions</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instructions</em>' attribute.
	 * @see #setInstructions(String)
	 * @see test1.Test1Package#getOrder_Instructions()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getInstructions();

	/**
	 * Sets the value of the '{@link test1.Order#getInstructions <em>Instructions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instructions</em>' attribute.
	 * @see #getInstructions()
	 * @generated
	 */
	void setInstructions(String value);

	/**
	 * Returns the value of the '<em><b>Discounted Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Discounted Price</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Discounted Price</em>' attribute.
	 * @see #setDiscountedPrice(float)
	 * @see test1.Test1Package#getOrder_DiscountedPrice()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	float getDiscountedPrice();

	/**
	 * Sets the value of the '{@link test1.Order#getDiscountedPrice <em>Discounted Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Discounted Price</em>' attribute.
	 * @see #getDiscountedPrice()
	 * @generated
	 */
	void setDiscountedPrice(float value);

	/**
	 * Returns the value of the '<em><b>Source Location Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source Location Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source Location Id</em>' attribute.
	 * @see #setSourceLocationId(String)
	 * @see test1.Test1Package#getOrder_SourceLocationId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getSourceLocationId();

	/**
	 * Sets the value of the '{@link test1.Order#getSourceLocationId <em>Source Location Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source Location Id</em>' attribute.
	 * @see #getSourceLocationId()
	 * @generated
	 */
	void setSourceLocationId(String value);

	/**
	 * Returns the value of the '<em><b>Destination Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destination Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destination Id</em>' attribute.
	 * @see #setDestinationId(String)
	 * @see test1.Test1Package#getOrder_DestinationId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getDestinationId();

	/**
	 * Sets the value of the '{@link test1.Order#getDestinationId <em>Destination Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destination Id</em>' attribute.
	 * @see #getDestinationId()
	 * @generated
	 */
	void setDestinationId(String value);

	/**
	 * Returns the value of the '<em><b>Tax</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tax</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tax</em>' attribute.
	 * @see #setTax(float)
	 * @see test1.Test1Package#getOrder_Tax()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	float getTax();

	/**
	 * Sets the value of the '{@link test1.Order#getTax <em>Tax</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tax</em>' attribute.
	 * @see #getTax()
	 * @generated
	 */
	void setTax(float value);

	/**
	 * Returns the value of the '<em><b>Delivery</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delivery</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delivery</em>' attribute.
	 * @see #setDelivery(float)
	 * @see test1.Test1Package#getOrder_Delivery()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	float getDelivery();

	/**
	 * Sets the value of the '{@link test1.Order#getDelivery <em>Delivery</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delivery</em>' attribute.
	 * @see #getDelivery()
	 * @generated
	 */
	void setDelivery(float value);

	/**
	 * Returns the value of the '<em><b>Status Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Status Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status Id</em>' reference.
	 * @see #setStatusId(Status)
	 * @see test1.Test1Package#getOrder_StatusId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Status getStatusId();

	/**
	 * Sets the value of the '{@link test1.Order#getStatusId <em>Status Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status Id</em>' reference.
	 * @see #getStatusId()
	 * @generated
	 */
	void setStatusId(Status value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' containment reference.
	 * It is bidirectional and its opposite is '{@link test1.Status#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Status</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' containment reference.
	 * @see #setStatus(Status)
	 * @see test1.Test1Package#getOrder_Status()
	 * @see test1.Status#getOrder
	 * @model opposite="order" containment="true" required="true" ordered="false"
	 * @generated
	 */
	Status getStatus();

	/**
	 * Sets the value of the '{@link test1.Order#getStatus <em>Status</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' containment reference.
	 * @see #getStatus()
	 * @generated
	 */
	void setStatus(Status value);

	/**
	 * Returns the value of the '<em><b>Agent Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agent Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agent Id</em>' reference.
	 * @see #setAgentId(DeliveryAgent)
	 * @see test1.Test1Package#getOrder_AgentId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	DeliveryAgent getAgentId();

	/**
	 * Sets the value of the '{@link test1.Order#getAgentId <em>Agent Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agent Id</em>' reference.
	 * @see #getAgentId()
	 * @generated
	 */
	void setAgentId(DeliveryAgent value);

	/**
	 * Returns the value of the '<em><b>Payment Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Payment Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payment Id</em>' reference.
	 * @see #setPaymentId(PaymentsInfo)
	 * @see test1.Test1Package#getOrder_PaymentId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	PaymentsInfo getPaymentId();

	/**
	 * Sets the value of the '{@link test1.Order#getPaymentId <em>Payment Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payment Id</em>' reference.
	 * @see #getPaymentId()
	 * @generated
	 */
	void setPaymentId(PaymentsInfo value);

	/**
	 * Returns the value of the '<em><b>Promotion Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Promotion Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Promotion Id</em>' reference.
	 * @see #setPromotionId(Discounts)
	 * @see test1.Test1Package#getOrder_PromotionId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Discounts getPromotionId();

	/**
	 * Sets the value of the '{@link test1.Order#getPromotionId <em>Promotion Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Promotion Id</em>' reference.
	 * @see #getPromotionId()
	 * @generated
	 */
	void setPromotionId(Discounts value);

	/**
	 * Returns the value of the '<em><b>Discounts</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Discounts#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Discounts</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Discounts</em>' reference.
	 * @see #setDiscounts(Discounts)
	 * @see test1.Test1Package#getOrder_Discounts()
	 * @see test1.Discounts#getOrder
	 * @model opposite="order" required="true" ordered="false"
	 * @generated
	 */
	Discounts getDiscounts();

	/**
	 * Sets the value of the '{@link test1.Order#getDiscounts <em>Discounts</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Discounts</em>' reference.
	 * @see #getDiscounts()
	 * @generated
	 */
	void setDiscounts(Discounts value);

	/**
	 * Returns the value of the '<em><b>Customer Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Customer Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer Id</em>' reference.
	 * @see #setCustomerId(Customer)
	 * @see test1.Test1Package#getOrder_CustomerId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Customer getCustomerId();

	/**
	 * Sets the value of the '{@link test1.Order#getCustomerId <em>Customer Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Customer Id</em>' reference.
	 * @see #getCustomerId()
	 * @generated
	 */
	void setCustomerId(Customer value);

	/**
	 * Returns the value of the '<em><b>Transactions</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Transactions#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transactions</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transactions</em>' reference.
	 * @see #setTransactions(Transactions)
	 * @see test1.Test1Package#getOrder_Transactions()
	 * @see test1.Transactions#getOrder
	 * @model opposite="order" required="true" ordered="false"
	 * @generated
	 */
	Transactions getTransactions();

	/**
	 * Sets the value of the '{@link test1.Order#getTransactions <em>Transactions</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transactions</em>' reference.
	 * @see #getTransactions()
	 * @generated
	 */
	void setTransactions(Transactions value);

	/**
	 * Returns the value of the '<em><b>Payments Info</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.PaymentsInfo#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Payments Info</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payments Info</em>' reference.
	 * @see #setPaymentsInfo(PaymentsInfo)
	 * @see test1.Test1Package#getOrder_PaymentsInfo()
	 * @see test1.PaymentsInfo#getOrder
	 * @model opposite="order" ordered="false"
	 * @generated
	 */
	PaymentsInfo getPaymentsInfo();

	/**
	 * Sets the value of the '{@link test1.Order#getPaymentsInfo <em>Payments Info</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payments Info</em>' reference.
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	void setPaymentsInfo(PaymentsInfo value);

	/**
	 * Returns the value of the '<em><b>Catalog</b></em>' reference list.
	 * The list contents are of type {@link test1.Catalog}.
	 * It is bidirectional and its opposite is '{@link test1.Catalog#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Catalog</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Catalog</em>' reference list.
	 * @see test1.Test1Package#getOrder_Catalog()
	 * @see test1.Catalog#getOrder
	 * @model opposite="order" required="true" ordered="false"
	 * @generated
	 */
	EList<Catalog> getCatalog();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setOrderId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setOrderPrice();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setInstructions();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setDiscountedPrice();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setSourceLocationId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setTax();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setDeliveryFee();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setOderId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 * @generated
	 */
	void getDeliveryFee();

} // Order
