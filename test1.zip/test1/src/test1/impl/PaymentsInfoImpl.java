/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;
import java.util.Map;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.emf.ecore.util.EObjectValidator;
import org.eclipse.emf.ecore.util.EObjectWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.ParserException;

import org.eclipse.ocl.ecore.Constraint;
import org.eclipse.ocl.ecore.OCL;

import test1.Card;
import test1.Order;
import test1.PaymentsInfo;
import test1.Test1Package;
import test1.Transactions;
import test1.UserDetails;

import test1.util.Test1Validator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Payments Info</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getPaymentId <em>Payment Id</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getCardNo <em>Card No</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getExpiryDate <em>Expiry Date</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getCardHolderName <em>Card Holder Name</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getCvv <em>Cvv</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getCardId <em>Card Id</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getTransactions <em>Transactions</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getOrder <em>Order</em>}</li>
 *   <li>{@link test1.impl.PaymentsInfoImpl#getCard <em>Card</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PaymentsInfoImpl extends MinimalEObjectImpl.Container implements PaymentsInfo {
	/**
	 * The default value of the '{@link #getPaymentId() <em>Payment Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentId()
	 * @generated
	 * @ordered
	 */
	protected static final String PAYMENT_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPaymentId() <em>Payment Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentId()
	 * @generated
	 * @ordered
	 */
	protected String paymentId = PAYMENT_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getCardNo() <em>Card No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardNo()
	 * @generated
	 * @ordered
	 */
	protected static final int CARD_NO_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCardNo() <em>Card No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardNo()
	 * @generated
	 * @ordered
	 */
	protected int cardNo = CARD_NO_EDEFAULT;

	/**
	 * The default value of the '{@link #getExpiryDate() <em>Expiry Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExpiryDate()
	 * @generated
	 * @ordered
	 */
	protected static final String EXPIRY_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getExpiryDate() <em>Expiry Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExpiryDate()
	 * @generated
	 * @ordered
	 */
	protected String expiryDate = EXPIRY_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCardHolderName() <em>Card Holder Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardHolderName()
	 * @generated
	 * @ordered
	 */
	protected static final String CARD_HOLDER_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCardHolderName() <em>Card Holder Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardHolderName()
	 * @generated
	 * @ordered
	 */
	protected String cardHolderName = CARD_HOLDER_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getCvv() <em>Cvv</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCvv()
	 * @generated
	 * @ordered
	 */
	protected static final int CVV_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCvv() <em>Cvv</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCvv()
	 * @generated
	 * @ordered
	 */
	protected int cvv = CVV_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCardId() <em>Card Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardId()
	 * @generated
	 * @ordered
	 */
	protected Card cardId;

	/**
	 * The cached value of the '{@link #getUserId() <em>User Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserId()
	 * @generated
	 * @ordered
	 */
	protected UserDetails userId;

	/**
	 * The cached value of the '{@link #getOrder() <em>Order</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrder()
	 * @generated
	 * @ordered
	 */
	protected Order order;

	/**
	 * The cached value of the '{@link #getCard() <em>Card</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCard()
	 * @generated
	 * @ordered
	 */
	protected Card card;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PaymentsInfoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.PAYMENTS_INFO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPaymentId() {
		return paymentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPaymentId(String newPaymentId) {
		String oldPaymentId = paymentId;
		paymentId = newPaymentId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__PAYMENT_ID, oldPaymentId, paymentId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCardNo() {
		return cardNo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardNo(int newCardNo) {
		int oldCardNo = cardNo;
		cardNo = newCardNo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__CARD_NO, oldCardNo, cardNo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getExpiryDate() {
		return expiryDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExpiryDate(String newExpiryDate) {
		String oldExpiryDate = expiryDate;
		expiryDate = newExpiryDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__EXPIRY_DATE, oldExpiryDate, expiryDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCardHolderName() {
		return cardHolderName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardHolderName(String newCardHolderName) {
		String oldCardHolderName = cardHolderName;
		cardHolderName = newCardHolderName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__CARD_HOLDER_NAME, oldCardHolderName, cardHolderName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCvv() {
		return cvv;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCvv(int newCvv) {
		int oldCvv = cvv;
		cvv = newCvv;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__CVV, oldCvv, cvv));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Card getCardId() {
		if (cardId != null && cardId.eIsProxy()) {
			InternalEObject oldCardId = (InternalEObject)cardId;
			cardId = (Card)eResolveProxy(oldCardId);
			if (cardId != oldCardId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.PAYMENTS_INFO__CARD_ID, oldCardId, cardId));
			}
		}
		return cardId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Card basicGetCardId() {
		return cardId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardId(Card newCardId) {
		Card oldCardId = cardId;
		cardId = newCardId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__CARD_ID, oldCardId, cardId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails getUserId() {
		if (userId != null && userId.eIsProxy()) {
			InternalEObject oldUserId = (InternalEObject)userId;
			userId = (UserDetails)eResolveProxy(oldUserId);
			if (userId != oldUserId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.PAYMENTS_INFO__USER_ID, oldUserId, userId));
			}
		}
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails basicGetUserId() {
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserId(UserDetails newUserId) {
		UserDetails oldUserId = userId;
		userId = newUserId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__USER_ID, oldUserId, userId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Transactions> getTransactions() {
		if (transactions == null) {
			transactions = new EObjectWithInverseEList<Transactions>(Transactions.class, this, Test1Package.PAYMENTS_INFO__TRANSACTIONS, Test1Package.TRANSACTIONS__PAYMENTS_INFO);
		}
		return transactions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order getOrder() {
		if (order != null && order.eIsProxy()) {
			InternalEObject oldOrder = (InternalEObject)order;
			order = (Order)eResolveProxy(oldOrder);
			if (order != oldOrder) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.PAYMENTS_INFO__ORDER, oldOrder, order));
			}
		}
		return order;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order basicGetOrder() {
		return order;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOrder(Order newOrder, NotificationChain msgs) {
		Order oldOrder = order;
		order = newOrder;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__ORDER, oldOrder, newOrder);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrder(Order newOrder) {
		if (newOrder != order) {
			NotificationChain msgs = null;
			if (order != null)
				msgs = ((InternalEObject)order).eInverseRemove(this, Test1Package.ORDER__PAYMENTS_INFO, Order.class, msgs);
			if (newOrder != null)
				msgs = ((InternalEObject)newOrder).eInverseAdd(this, Test1Package.ORDER__PAYMENTS_INFO, Order.class, msgs);
			msgs = basicSetOrder(newOrder, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__ORDER, newOrder, newOrder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Card getCard() {
		if (card != null && card.eIsProxy()) {
			InternalEObject oldCard = (InternalEObject)card;
			card = (Card)eResolveProxy(oldCard);
			if (card != oldCard) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.PAYMENTS_INFO__CARD, oldCard, card));
			}
		}
		return card;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Card basicGetCard() {
		return card;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCard(Card newCard, NotificationChain msgs) {
		Card oldCard = card;
		card = newCard;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__CARD, oldCard, newCard);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCard(Card newCard) {
		if (newCard != card) {
			NotificationChain msgs = null;
			if (card != null)
				msgs = ((InternalEObject)card).eInverseRemove(this, Test1Package.CARD__PAYMENTS_INFO, Card.class, msgs);
			if (newCard != null)
				msgs = ((InternalEObject)newCard).eInverseAdd(this, Test1Package.CARD__PAYMENTS_INFO, Card.class, msgs);
			msgs = basicSetCard(newCard, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PAYMENTS_INFO__CARD, newCard, newCard));
	}

	/**
	 * The cached OCL expression body for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static final String CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP = "cardNo attribute in the PaymentsInfo class is a positive integer.";

	/**
	 * The cached OCL invariant for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' invariant operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static Constraint CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV == null) {
			OCL.Helper helper = EOCL_ENV.createOCLHelper();
			helper.setContext(Test1Package.Literals.PAYMENTS_INFO);
			try {
				CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV = helper.createInvariant(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP);
			}
			catch (ParserException pe) {
				throw new UnsupportedOperationException(pe.getLocalizedMessage());
			}
		}
		if (!EOCL_ENV.createQuery(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV).check(this)) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 Test1Validator.DIAGNOSTIC_SOURCE,
						 Test1Validator.PAYMENTS_INFO__CONSTRAINT1,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "constraint1", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardNo() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExpiryDate() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardHolderName() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCvv() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.PAYMENTS_INFO__TRANSACTIONS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getTransactions()).basicAdd(otherEnd, msgs);
			case Test1Package.PAYMENTS_INFO__ORDER:
				if (order != null)
					msgs = ((InternalEObject)order).eInverseRemove(this, Test1Package.ORDER__PAYMENTS_INFO, Order.class, msgs);
				return basicSetOrder((Order)otherEnd, msgs);
			case Test1Package.PAYMENTS_INFO__CARD:
				if (card != null)
					msgs = ((InternalEObject)card).eInverseRemove(this, Test1Package.CARD__PAYMENTS_INFO, Card.class, msgs);
				return basicSetCard((Card)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.PAYMENTS_INFO__TRANSACTIONS:
				return ((InternalEList<?>)getTransactions()).basicRemove(otherEnd, msgs);
			case Test1Package.PAYMENTS_INFO__ORDER:
				return basicSetOrder(null, msgs);
			case Test1Package.PAYMENTS_INFO__CARD:
				return basicSetCard(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case Test1Package.PAYMENTS_INFO__TRANSACTIONS:
				return eInternalContainer().eInverseRemove(this, Test1Package.TRANSACTIONS__PAYMENTS_INFO, Transactions.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.PAYMENTS_INFO__PAYMENT_ID:
				return getPaymentId();
			case Test1Package.PAYMENTS_INFO__CARD_NO:
				return getCardNo();
			case Test1Package.PAYMENTS_INFO__EXPIRY_DATE:
				return getExpiryDate();
			case Test1Package.PAYMENTS_INFO__CARD_HOLDER_NAME:
				return getCardHolderName();
			case Test1Package.PAYMENTS_INFO__CVV:
				return getCvv();
			case Test1Package.PAYMENTS_INFO__CARD_ID:
				if (resolve) return getCardId();
				return basicGetCardId();
			case Test1Package.PAYMENTS_INFO__USER_ID:
				if (resolve) return getUserId();
				return basicGetUserId();
			case Test1Package.PAYMENTS_INFO__TRANSACTIONS:
				return getTransactions();
			case Test1Package.PAYMENTS_INFO__ORDER:
				if (resolve) return getOrder();
				return basicGetOrder();
			case Test1Package.PAYMENTS_INFO__CARD:
				if (resolve) return getCard();
				return basicGetCard();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.PAYMENTS_INFO__PAYMENT_ID:
				setPaymentId((String)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__CARD_NO:
				setCardNo((Integer)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__EXPIRY_DATE:
				setExpiryDate((String)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__CARD_HOLDER_NAME:
				setCardHolderName((String)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__CVV:
				setCvv((Integer)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__CARD_ID:
				setCardId((Card)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__USER_ID:
				setUserId((UserDetails)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__TRANSACTIONS:
				getTransactions().clear();
				getTransactions().addAll((Collection<? extends Transactions>)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__ORDER:
				setOrder((Order)newValue);
				return;
			case Test1Package.PAYMENTS_INFO__CARD:
				setCard((Card)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.PAYMENTS_INFO__PAYMENT_ID:
				setPaymentId(PAYMENT_ID_EDEFAULT);
				return;
			case Test1Package.PAYMENTS_INFO__CARD_NO:
				setCardNo(CARD_NO_EDEFAULT);
				return;
			case Test1Package.PAYMENTS_INFO__EXPIRY_DATE:
				setExpiryDate(EXPIRY_DATE_EDEFAULT);
				return;
			case Test1Package.PAYMENTS_INFO__CARD_HOLDER_NAME:
				setCardHolderName(CARD_HOLDER_NAME_EDEFAULT);
				return;
			case Test1Package.PAYMENTS_INFO__CVV:
				setCvv(CVV_EDEFAULT);
				return;
			case Test1Package.PAYMENTS_INFO__CARD_ID:
				setCardId((Card)null);
				return;
			case Test1Package.PAYMENTS_INFO__USER_ID:
				setUserId((UserDetails)null);
				return;
			case Test1Package.PAYMENTS_INFO__TRANSACTIONS:
				getTransactions().clear();
				return;
			case Test1Package.PAYMENTS_INFO__ORDER:
				setOrder((Order)null);
				return;
			case Test1Package.PAYMENTS_INFO__CARD:
				setCard((Card)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.PAYMENTS_INFO__PAYMENT_ID:
				return PAYMENT_ID_EDEFAULT == null ? paymentId != null : !PAYMENT_ID_EDEFAULT.equals(paymentId);
			case Test1Package.PAYMENTS_INFO__CARD_NO:
				return cardNo != CARD_NO_EDEFAULT;
			case Test1Package.PAYMENTS_INFO__EXPIRY_DATE:
				return EXPIRY_DATE_EDEFAULT == null ? expiryDate != null : !EXPIRY_DATE_EDEFAULT.equals(expiryDate);
			case Test1Package.PAYMENTS_INFO__CARD_HOLDER_NAME:
				return CARD_HOLDER_NAME_EDEFAULT == null ? cardHolderName != null : !CARD_HOLDER_NAME_EDEFAULT.equals(cardHolderName);
			case Test1Package.PAYMENTS_INFO__CVV:
				return cvv != CVV_EDEFAULT;
			case Test1Package.PAYMENTS_INFO__CARD_ID:
				return cardId != null;
			case Test1Package.PAYMENTS_INFO__USER_ID:
				return userId != null;
			case Test1Package.PAYMENTS_INFO__TRANSACTIONS:
				return !getTransactions().isEmpty();
			case Test1Package.PAYMENTS_INFO__ORDER:
				return order != null;
			case Test1Package.PAYMENTS_INFO__CARD:
				return card != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.PAYMENTS_INFO___CONSTRAINT1__DIAGNOSTICCHAIN_MAP:
				return constraint1((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case Test1Package.PAYMENTS_INFO___SET_CARD_NO:
				setCardNo();
				return null;
			case Test1Package.PAYMENTS_INFO___SET_EXPIRY_DATE:
				setExpiryDate();
				return null;
			case Test1Package.PAYMENTS_INFO___SET_CARD_HOLDER_NAME:
				setCardHolderName();
				return null;
			case Test1Package.PAYMENTS_INFO___SET_CVV:
				setCvv();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (paymentId: ");
		result.append(paymentId);
		result.append(", cardNo: ");
		result.append(cardNo);
		result.append(", expiryDate: ");
		result.append(expiryDate);
		result.append(", cardHolderName: ");
		result.append(cardHolderName);
		result.append(", cvv: ");
		result.append(cvv);
		result.append(')');
		return result.toString();
	}

	/**
	 * The cached environment for evaluating OCL expressions.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected static final OCL EOCL_ENV = OCL.newInstance();

} //PaymentsInfoImpl
