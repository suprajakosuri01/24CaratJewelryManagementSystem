/**
 */
package test1.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import test1.Test1Package;
import test1.test1Date;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>test1 Date</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class test1DateImpl extends MinimalEObjectImpl.Container implements test1Date {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected test1DateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.TEST1_DATE;
	}

} //test1DateImpl
