/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;
import java.util.Map;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.emf.ecore.util.EObjectValidator;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.ParserException;

import org.eclipse.ocl.ecore.Constraint;
import org.eclipse.ocl.ecore.OCL;

import test1.Address;
import test1.Location;
import test1.Test1Package;
import test1.Zipcode;

import test1.util.Test1Validator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Location</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.LocationImpl#getLocationId <em>Location Id</em>}</li>
 *   <li>{@link test1.impl.LocationImpl#getStreetName <em>Street Name</em>}</li>
 *   <li>{@link test1.impl.LocationImpl#getHouseNo <em>House No</em>}</li>
 *   <li>{@link test1.impl.LocationImpl#getZip <em>Zip</em>}</li>
 *   <li>{@link test1.impl.LocationImpl#getZipcode <em>Zipcode</em>}</li>
 *   <li>{@link test1.impl.LocationImpl#getAddress <em>Address</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LocationImpl extends MinimalEObjectImpl.Container implements Location {
	/**
	 * The default value of the '{@link #getLocationId() <em>Location Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocationId()
	 * @generated
	 * @ordered
	 */
	protected static final String LOCATION_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLocationId() <em>Location Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocationId()
	 * @generated
	 * @ordered
	 */
	protected String locationId = LOCATION_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getStreetName() <em>Street Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreetName()
	 * @generated
	 * @ordered
	 */
	protected static final String STREET_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStreetName() <em>Street Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreetName()
	 * @generated
	 * @ordered
	 */
	protected String streetName = STREET_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getHouseNo() <em>House No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHouseNo()
	 * @generated
	 * @ordered
	 */
	protected static final String HOUSE_NO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHouseNo() <em>House No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHouseNo()
	 * @generated
	 * @ordered
	 */
	protected String houseNo = HOUSE_NO_EDEFAULT;

	/**
	 * The cached value of the '{@link #getZip() <em>Zip</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getZip()
	 * @generated
	 * @ordered
	 */
	protected Zipcode zip;

	/**
	 * The cached value of the '{@link #getZipcode() <em>Zipcode</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getZipcode()
	 * @generated
	 * @ordered
	 */
	protected Zipcode zipcode;

	/**
	 * The cached value of the '{@link #getAddress() <em>Address</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddress()
	 * @generated
	 * @ordered
	 */
	protected EList<Address> address;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LocationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.LOCATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLocationId() {
		return locationId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocationId(String newLocationId) {
		String oldLocationId = locationId;
		locationId = newLocationId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.LOCATION__LOCATION_ID, oldLocationId, locationId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStreetName(String newStreetName) {
		String oldStreetName = streetName;
		streetName = newStreetName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.LOCATION__STREET_NAME, oldStreetName, streetName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHouseNo() {
		return houseNo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHouseNo(String newHouseNo) {
		String oldHouseNo = houseNo;
		houseNo = newHouseNo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.LOCATION__HOUSE_NO, oldHouseNo, houseNo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zipcode getZip() {
		if (zip != null && zip.eIsProxy()) {
			InternalEObject oldZip = (InternalEObject)zip;
			zip = (Zipcode)eResolveProxy(oldZip);
			if (zip != oldZip) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.LOCATION__ZIP, oldZip, zip));
			}
		}
		return zip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zipcode basicGetZip() {
		return zip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setZip(Zipcode newZip) {
		Zipcode oldZip = zip;
		zip = newZip;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.LOCATION__ZIP, oldZip, zip));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zipcode getZipcode() {
		if (zipcode != null && zipcode.eIsProxy()) {
			InternalEObject oldZipcode = (InternalEObject)zipcode;
			zipcode = (Zipcode)eResolveProxy(oldZipcode);
			if (zipcode != oldZipcode) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.LOCATION__ZIPCODE, oldZipcode, zipcode));
			}
		}
		return zipcode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zipcode basicGetZipcode() {
		return zipcode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetZipcode(Zipcode newZipcode, NotificationChain msgs) {
		Zipcode oldZipcode = zipcode;
		zipcode = newZipcode;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.LOCATION__ZIPCODE, oldZipcode, newZipcode);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setZipcode(Zipcode newZipcode) {
		if (newZipcode != zipcode) {
			NotificationChain msgs = null;
			if (zipcode != null)
				msgs = ((InternalEObject)zipcode).eInverseRemove(this, Test1Package.ZIPCODE__LOCATION, Zipcode.class, msgs);
			if (newZipcode != null)
				msgs = ((InternalEObject)newZipcode).eInverseAdd(this, Test1Package.ZIPCODE__LOCATION, Zipcode.class, msgs);
			msgs = basicSetZipcode(newZipcode, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.LOCATION__ZIPCODE, newZipcode, newZipcode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Address> getAddress() {
		if (address == null) {
			address = new EObjectWithInverseResolvingEList<Address>(Address.class, this, Test1Package.LOCATION__ADDRESS, Test1Package.ADDRESS__LOCATION);
		}
		return address;
	}

	/**
	 * The cached OCL expression body for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static final String CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP = "zip.code attribute follows the pattern of a standard ZIP code";

	/**
	 * The cached OCL invariant for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' invariant operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static Constraint CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV == null) {
			OCL.Helper helper = EOCL_ENV.createOCLHelper();
			helper.setContext(Test1Package.Literals.LOCATION);
			try {
				CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV = helper.createInvariant(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP);
			}
			catch (ParserException pe) {
				throw new UnsupportedOperationException(pe.getLocalizedMessage());
			}
		}
		if (!EOCL_ENV.createQuery(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV).check(this)) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 Test1Validator.DIAGNOSTIC_SOURCE,
						 Test1Validator.LOCATION__CONSTRAINT1,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "constraint1", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStreetName() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHouseNo() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.LOCATION__ZIPCODE:
				if (zipcode != null)
					msgs = ((InternalEObject)zipcode).eInverseRemove(this, Test1Package.ZIPCODE__LOCATION, Zipcode.class, msgs);
				return basicSetZipcode((Zipcode)otherEnd, msgs);
			case Test1Package.LOCATION__ADDRESS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getAddress()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.LOCATION__ZIPCODE:
				return basicSetZipcode(null, msgs);
			case Test1Package.LOCATION__ADDRESS:
				return ((InternalEList<?>)getAddress()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.LOCATION__LOCATION_ID:
				return getLocationId();
			case Test1Package.LOCATION__STREET_NAME:
				return getStreetName();
			case Test1Package.LOCATION__HOUSE_NO:
				return getHouseNo();
			case Test1Package.LOCATION__ZIP:
				if (resolve) return getZip();
				return basicGetZip();
			case Test1Package.LOCATION__ZIPCODE:
				if (resolve) return getZipcode();
				return basicGetZipcode();
			case Test1Package.LOCATION__ADDRESS:
				return getAddress();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.LOCATION__LOCATION_ID:
				setLocationId((String)newValue);
				return;
			case Test1Package.LOCATION__STREET_NAME:
				setStreetName((String)newValue);
				return;
			case Test1Package.LOCATION__HOUSE_NO:
				setHouseNo((String)newValue);
				return;
			case Test1Package.LOCATION__ZIP:
				setZip((Zipcode)newValue);
				return;
			case Test1Package.LOCATION__ZIPCODE:
				setZipcode((Zipcode)newValue);
				return;
			case Test1Package.LOCATION__ADDRESS:
				getAddress().clear();
				getAddress().addAll((Collection<? extends Address>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.LOCATION__LOCATION_ID:
				setLocationId(LOCATION_ID_EDEFAULT);
				return;
			case Test1Package.LOCATION__STREET_NAME:
				setStreetName(STREET_NAME_EDEFAULT);
				return;
			case Test1Package.LOCATION__HOUSE_NO:
				setHouseNo(HOUSE_NO_EDEFAULT);
				return;
			case Test1Package.LOCATION__ZIP:
				setZip((Zipcode)null);
				return;
			case Test1Package.LOCATION__ZIPCODE:
				setZipcode((Zipcode)null);
				return;
			case Test1Package.LOCATION__ADDRESS:
				getAddress().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.LOCATION__LOCATION_ID:
				return LOCATION_ID_EDEFAULT == null ? locationId != null : !LOCATION_ID_EDEFAULT.equals(locationId);
			case Test1Package.LOCATION__STREET_NAME:
				return STREET_NAME_EDEFAULT == null ? streetName != null : !STREET_NAME_EDEFAULT.equals(streetName);
			case Test1Package.LOCATION__HOUSE_NO:
				return HOUSE_NO_EDEFAULT == null ? houseNo != null : !HOUSE_NO_EDEFAULT.equals(houseNo);
			case Test1Package.LOCATION__ZIP:
				return zip != null;
			case Test1Package.LOCATION__ZIPCODE:
				return zipcode != null;
			case Test1Package.LOCATION__ADDRESS:
				return address != null && !address.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.LOCATION___CONSTRAINT1__DIAGNOSTICCHAIN_MAP:
				return constraint1((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case Test1Package.LOCATION___SET_LOCATION:
				setLocation();
				return null;
			case Test1Package.LOCATION___SET_STREET_NAME:
				setStreetName();
				return null;
			case Test1Package.LOCATION___SET_HOUSE_NO:
				setHouseNo();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (locationId: ");
		result.append(locationId);
		result.append(", streetName: ");
		result.append(streetName);
		result.append(", houseNo: ");
		result.append(houseNo);
		result.append(')');
		return result.toString();
	}

	/**
	 * The cached environment for evaluating OCL expressions.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected static final OCL EOCL_ENV = OCL.newInstance();

} //LocationImpl
