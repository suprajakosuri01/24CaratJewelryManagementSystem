/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import test1.Date;
import test1.Order;
import test1.PaymentsInfo;
import test1.Status;
import test1.Test1Package;
import test1.Transactions;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transactions</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.TransactionsImpl#getTransactionId <em>Transaction Id</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getTotalPrice <em>Total Price</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getTransactionDate <em>Transaction Date</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getTransactionStatus <em>Transaction Status</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getOrderId <em>Order Id</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getStatus <em>Status</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getOrder <em>Order</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getPaymentId <em>Payment Id</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getStatusId <em>Status Id</em>}</li>
 *   <li>{@link test1.impl.TransactionsImpl#getPaymentsInfo <em>Payments Info</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TransactionsImpl extends MinimalEObjectImpl.Container implements Transactions {
	/**
	 * The default value of the '{@link #getTransactionId() <em>Transaction Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionId()
	 * @generated
	 * @ordered
	 */
	protected static final String TRANSACTION_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransactionId() <em>Transaction Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionId()
	 * @generated
	 * @ordered
	 */
	protected String transactionId = TRANSACTION_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getTotalPrice() <em>Total Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalPrice()
	 * @generated
	 * @ordered
	 */
	protected static final float TOTAL_PRICE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getTotalPrice() <em>Total Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalPrice()
	 * @generated
	 * @ordered
	 */
	protected float totalPrice = TOTAL_PRICE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTransactionDate() <em>Transaction Date</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionDate()
	 * @generated
	 * @ordered
	 */
	protected Date transactionDate;

	/**
	 * The default value of the '{@link #getTransactionStatus() <em>Transaction Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionStatus()
	 * @generated
	 * @ordered
	 */
	protected static final String TRANSACTION_STATUS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransactionStatus() <em>Transaction Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionStatus()
	 * @generated
	 * @ordered
	 */
	protected String transactionStatus = TRANSACTION_STATUS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOrderId() <em>Order Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderId()
	 * @generated
	 * @ordered
	 */
	protected Order orderId;

	/**
	 * The cached value of the '{@link #getStatus() <em>Status</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStatus()
	 * @generated
	 * @ordered
	 */
	protected Status status;

	/**
	 * The cached value of the '{@link #getOrder() <em>Order</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrder()
	 * @generated
	 * @ordered
	 */
	protected Order order;

	/**
	 * The cached value of the '{@link #getPaymentId() <em>Payment Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentId()
	 * @generated
	 * @ordered
	 */
	protected PaymentsInfo paymentId;

	/**
	 * The cached value of the '{@link #getStatusId() <em>Status Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStatusId()
	 * @generated
	 * @ordered
	 */
	protected Status statusId;

	/**
	 * The cached value of the '{@link #getPaymentsInfo() <em>Payments Info</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentsInfo()
	 * @generated
	 * @ordered
	 */
	protected PaymentsInfo paymentsInfo;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransactionsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.TRANSACTIONS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransactionId(String newTransactionId) {
		String oldTransactionId = transactionId;
		transactionId = newTransactionId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__TRANSACTION_ID, oldTransactionId, transactionId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getTotalPrice() {
		return totalPrice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalPrice(float newTotalPrice) {
		float oldTotalPrice = totalPrice;
		totalPrice = newTotalPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__TOTAL_PRICE, oldTotalPrice, totalPrice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getTransactionDate() {
		return transactionDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTransactionDate(Date newTransactionDate, NotificationChain msgs) {
		Date oldTransactionDate = transactionDate;
		transactionDate = newTransactionDate;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__TRANSACTION_DATE, oldTransactionDate, newTransactionDate);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransactionDate(Date newTransactionDate) {
		if (newTransactionDate != transactionDate) {
			NotificationChain msgs = null;
			if (transactionDate != null)
				msgs = ((InternalEObject)transactionDate).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Test1Package.TRANSACTIONS__TRANSACTION_DATE, null, msgs);
			if (newTransactionDate != null)
				msgs = ((InternalEObject)newTransactionDate).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Test1Package.TRANSACTIONS__TRANSACTION_DATE, null, msgs);
			msgs = basicSetTransactionDate(newTransactionDate, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__TRANSACTION_DATE, newTransactionDate, newTransactionDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransactionStatus(String newTransactionStatus) {
		String oldTransactionStatus = transactionStatus;
		transactionStatus = newTransactionStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__TRANSACTION_STATUS, oldTransactionStatus, transactionStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order getOrderId() {
		if (orderId != null && orderId.eIsProxy()) {
			InternalEObject oldOrderId = (InternalEObject)orderId;
			orderId = (Order)eResolveProxy(oldOrderId);
			if (orderId != oldOrderId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.TRANSACTIONS__ORDER_ID, oldOrderId, orderId));
			}
		}
		return orderId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order basicGetOrderId() {
		return orderId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderId(Order newOrderId) {
		Order oldOrderId = orderId;
		orderId = newOrderId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__ORDER_ID, oldOrderId, orderId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Status getStatus() {
		if (status != null && status.eIsProxy()) {
			InternalEObject oldStatus = (InternalEObject)status;
			status = (Status)eResolveProxy(oldStatus);
			if (status != oldStatus) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.TRANSACTIONS__STATUS, oldStatus, status));
			}
		}
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Status basicGetStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStatus(Status newStatus, NotificationChain msgs) {
		Status oldStatus = status;
		status = newStatus;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__STATUS, oldStatus, newStatus);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStatus(Status newStatus) {
		if (newStatus != status) {
			NotificationChain msgs = null;
			if (status != null)
				msgs = ((InternalEObject)status).eInverseRemove(this, Test1Package.STATUS__TRANSACTIONS, Status.class, msgs);
			if (newStatus != null)
				msgs = ((InternalEObject)newStatus).eInverseAdd(this, Test1Package.STATUS__TRANSACTIONS, Status.class, msgs);
			msgs = basicSetStatus(newStatus, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__STATUS, newStatus, newStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order getOrder() {
		if (order != null && order.eIsProxy()) {
			InternalEObject oldOrder = (InternalEObject)order;
			order = (Order)eResolveProxy(oldOrder);
			if (order != oldOrder) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.TRANSACTIONS__ORDER, oldOrder, order));
			}
		}
		return order;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order basicGetOrder() {
		return order;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOrder(Order newOrder, NotificationChain msgs) {
		Order oldOrder = order;
		order = newOrder;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__ORDER, oldOrder, newOrder);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrder(Order newOrder) {
		if (newOrder != order) {
			NotificationChain msgs = null;
			if (order != null)
				msgs = ((InternalEObject)order).eInverseRemove(this, Test1Package.ORDER__TRANSACTIONS, Order.class, msgs);
			if (newOrder != null)
				msgs = ((InternalEObject)newOrder).eInverseAdd(this, Test1Package.ORDER__TRANSACTIONS, Order.class, msgs);
			msgs = basicSetOrder(newOrder, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__ORDER, newOrder, newOrder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentsInfo getPaymentId() {
		if (paymentId != null && paymentId.eIsProxy()) {
			InternalEObject oldPaymentId = (InternalEObject)paymentId;
			paymentId = (PaymentsInfo)eResolveProxy(oldPaymentId);
			if (paymentId != oldPaymentId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.TRANSACTIONS__PAYMENT_ID, oldPaymentId, paymentId));
			}
		}
		return paymentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentsInfo basicGetPaymentId() {
		return paymentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPaymentId(PaymentsInfo newPaymentId) {
		PaymentsInfo oldPaymentId = paymentId;
		paymentId = newPaymentId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__PAYMENT_ID, oldPaymentId, paymentId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Status getStatusId() {
		if (statusId != null && statusId.eIsProxy()) {
			InternalEObject oldStatusId = (InternalEObject)statusId;
			statusId = (Status)eResolveProxy(oldStatusId);
			if (statusId != oldStatusId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.TRANSACTIONS__STATUS_ID, oldStatusId, statusId));
			}
		}
		return statusId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Status basicGetStatusId() {
		return statusId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStatusId(Status newStatusId) {
		Status oldStatusId = statusId;
		statusId = newStatusId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__STATUS_ID, oldStatusId, statusId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentsInfo getPaymentsInfo() {
		return paymentsInfo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPaymentsInfo(PaymentsInfo newPaymentsInfo, NotificationChain msgs) {
		PaymentsInfo oldPaymentsInfo = paymentsInfo;
		paymentsInfo = newPaymentsInfo;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__PAYMENTS_INFO, oldPaymentsInfo, newPaymentsInfo);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPaymentsInfo(PaymentsInfo newPaymentsInfo) {
		if (newPaymentsInfo != paymentsInfo) {
			NotificationChain msgs = null;
			if (paymentsInfo != null)
				msgs = ((InternalEObject)paymentsInfo).eInverseRemove(this, Test1Package.PAYMENTS_INFO__TRANSACTIONS, PaymentsInfo.class, msgs);
			if (newPaymentsInfo != null)
				msgs = ((InternalEObject)newPaymentsInfo).eInverseAdd(this, Test1Package.PAYMENTS_INFO__TRANSACTIONS, PaymentsInfo.class, msgs);
			msgs = basicSetPaymentsInfo(newPaymentsInfo, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.TRANSACTIONS__PAYMENTS_INFO, newPaymentsInfo, newPaymentsInfo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalPrice() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransactionDate() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransactionStatus() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.TRANSACTIONS__STATUS:
				if (status != null)
					msgs = ((InternalEObject)status).eInverseRemove(this, Test1Package.STATUS__TRANSACTIONS, Status.class, msgs);
				return basicSetStatus((Status)otherEnd, msgs);
			case Test1Package.TRANSACTIONS__ORDER:
				if (order != null)
					msgs = ((InternalEObject)order).eInverseRemove(this, Test1Package.ORDER__TRANSACTIONS, Order.class, msgs);
				return basicSetOrder((Order)otherEnd, msgs);
			case Test1Package.TRANSACTIONS__PAYMENTS_INFO:
				if (paymentsInfo != null)
					msgs = ((InternalEObject)paymentsInfo).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Test1Package.TRANSACTIONS__PAYMENTS_INFO, null, msgs);
				return basicSetPaymentsInfo((PaymentsInfo)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.TRANSACTIONS__TRANSACTION_DATE:
				return basicSetTransactionDate(null, msgs);
			case Test1Package.TRANSACTIONS__STATUS:
				return basicSetStatus(null, msgs);
			case Test1Package.TRANSACTIONS__ORDER:
				return basicSetOrder(null, msgs);
			case Test1Package.TRANSACTIONS__PAYMENTS_INFO:
				return basicSetPaymentsInfo(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.TRANSACTIONS__TRANSACTION_ID:
				return getTransactionId();
			case Test1Package.TRANSACTIONS__TOTAL_PRICE:
				return getTotalPrice();
			case Test1Package.TRANSACTIONS__TRANSACTION_DATE:
				return getTransactionDate();
			case Test1Package.TRANSACTIONS__TRANSACTION_STATUS:
				return getTransactionStatus();
			case Test1Package.TRANSACTIONS__ORDER_ID:
				if (resolve) return getOrderId();
				return basicGetOrderId();
			case Test1Package.TRANSACTIONS__STATUS:
				if (resolve) return getStatus();
				return basicGetStatus();
			case Test1Package.TRANSACTIONS__ORDER:
				if (resolve) return getOrder();
				return basicGetOrder();
			case Test1Package.TRANSACTIONS__PAYMENT_ID:
				if (resolve) return getPaymentId();
				return basicGetPaymentId();
			case Test1Package.TRANSACTIONS__STATUS_ID:
				if (resolve) return getStatusId();
				return basicGetStatusId();
			case Test1Package.TRANSACTIONS__PAYMENTS_INFO:
				return getPaymentsInfo();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.TRANSACTIONS__TRANSACTION_ID:
				setTransactionId((String)newValue);
				return;
			case Test1Package.TRANSACTIONS__TOTAL_PRICE:
				setTotalPrice((Float)newValue);
				return;
			case Test1Package.TRANSACTIONS__TRANSACTION_DATE:
				setTransactionDate((Date)newValue);
				return;
			case Test1Package.TRANSACTIONS__TRANSACTION_STATUS:
				setTransactionStatus((String)newValue);
				return;
			case Test1Package.TRANSACTIONS__ORDER_ID:
				setOrderId((Order)newValue);
				return;
			case Test1Package.TRANSACTIONS__STATUS:
				setStatus((Status)newValue);
				return;
			case Test1Package.TRANSACTIONS__ORDER:
				setOrder((Order)newValue);
				return;
			case Test1Package.TRANSACTIONS__PAYMENT_ID:
				setPaymentId((PaymentsInfo)newValue);
				return;
			case Test1Package.TRANSACTIONS__STATUS_ID:
				setStatusId((Status)newValue);
				return;
			case Test1Package.TRANSACTIONS__PAYMENTS_INFO:
				setPaymentsInfo((PaymentsInfo)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.TRANSACTIONS__TRANSACTION_ID:
				setTransactionId(TRANSACTION_ID_EDEFAULT);
				return;
			case Test1Package.TRANSACTIONS__TOTAL_PRICE:
				setTotalPrice(TOTAL_PRICE_EDEFAULT);
				return;
			case Test1Package.TRANSACTIONS__TRANSACTION_DATE:
				setTransactionDate((Date)null);
				return;
			case Test1Package.TRANSACTIONS__TRANSACTION_STATUS:
				setTransactionStatus(TRANSACTION_STATUS_EDEFAULT);
				return;
			case Test1Package.TRANSACTIONS__ORDER_ID:
				setOrderId((Order)null);
				return;
			case Test1Package.TRANSACTIONS__STATUS:
				setStatus((Status)null);
				return;
			case Test1Package.TRANSACTIONS__ORDER:
				setOrder((Order)null);
				return;
			case Test1Package.TRANSACTIONS__PAYMENT_ID:
				setPaymentId((PaymentsInfo)null);
				return;
			case Test1Package.TRANSACTIONS__STATUS_ID:
				setStatusId((Status)null);
				return;
			case Test1Package.TRANSACTIONS__PAYMENTS_INFO:
				setPaymentsInfo((PaymentsInfo)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.TRANSACTIONS__TRANSACTION_ID:
				return TRANSACTION_ID_EDEFAULT == null ? transactionId != null : !TRANSACTION_ID_EDEFAULT.equals(transactionId);
			case Test1Package.TRANSACTIONS__TOTAL_PRICE:
				return totalPrice != TOTAL_PRICE_EDEFAULT;
			case Test1Package.TRANSACTIONS__TRANSACTION_DATE:
				return transactionDate != null;
			case Test1Package.TRANSACTIONS__TRANSACTION_STATUS:
				return TRANSACTION_STATUS_EDEFAULT == null ? transactionStatus != null : !TRANSACTION_STATUS_EDEFAULT.equals(transactionStatus);
			case Test1Package.TRANSACTIONS__ORDER_ID:
				return orderId != null;
			case Test1Package.TRANSACTIONS__STATUS:
				return status != null;
			case Test1Package.TRANSACTIONS__ORDER:
				return order != null;
			case Test1Package.TRANSACTIONS__PAYMENT_ID:
				return paymentId != null;
			case Test1Package.TRANSACTIONS__STATUS_ID:
				return statusId != null;
			case Test1Package.TRANSACTIONS__PAYMENTS_INFO:
				return paymentsInfo != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.TRANSACTIONS___SET_TOTAL_PRICE:
				setTotalPrice();
				return null;
			case Test1Package.TRANSACTIONS___SET_TRANSACTION_DATE:
				setTransactionDate();
				return null;
			case Test1Package.TRANSACTIONS___SET_TRANSACTION_STATUS:
				setTransactionStatus();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (transactionId: ");
		result.append(transactionId);
		result.append(", totalPrice: ");
		result.append(totalPrice);
		result.append(", transactionStatus: ");
		result.append(transactionStatus);
		result.append(')');
		return result.toString();
	}

} //TransactionsImpl
