/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import test1.Address;
import test1.Location;
import test1.Test1Package;
import test1.UserDetails;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Address</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.AddressImpl#getAddressType <em>Address Type</em>}</li>
 *   <li>{@link test1.impl.AddressImpl#getLocationId <em>Location Id</em>}</li>
 *   <li>{@link test1.impl.AddressImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link test1.impl.AddressImpl#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.impl.AddressImpl#getUserDetails <em>User Details</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AddressImpl extends MinimalEObjectImpl.Container implements Address {
	/**
	 * The default value of the '{@link #getAddressType() <em>Address Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddressType()
	 * @generated
	 * @ordered
	 */
	protected static final String ADDRESS_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAddressType() <em>Address Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddressType()
	 * @generated
	 * @ordered
	 */
	protected String addressType = ADDRESS_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLocationId() <em>Location Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocationId()
	 * @generated
	 * @ordered
	 */
	protected Location locationId;

	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected Location location;

	/**
	 * The cached value of the '{@link #getUserId() <em>User Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserId()
	 * @generated
	 * @ordered
	 */
	protected UserDetails userId;

	/**
	 * The cached value of the '{@link #getUserDetails() <em>User Details</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserDetails()
	 * @generated
	 * @ordered
	 */
	protected UserDetails userDetails;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AddressImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.ADDRESS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAddressType() {
		return addressType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAddressType(String newAddressType) {
		String oldAddressType = addressType;
		addressType = newAddressType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ADDRESS__ADDRESS_TYPE, oldAddressType, addressType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Location getLocationId() {
		if (locationId != null && locationId.eIsProxy()) {
			InternalEObject oldLocationId = (InternalEObject)locationId;
			locationId = (Location)eResolveProxy(oldLocationId);
			if (locationId != oldLocationId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ADDRESS__LOCATION_ID, oldLocationId, locationId));
			}
		}
		return locationId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Location basicGetLocationId() {
		return locationId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocationId(Location newLocationId) {
		Location oldLocationId = locationId;
		locationId = newLocationId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ADDRESS__LOCATION_ID, oldLocationId, locationId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Location getLocation() {
		if (location != null && location.eIsProxy()) {
			InternalEObject oldLocation = (InternalEObject)location;
			location = (Location)eResolveProxy(oldLocation);
			if (location != oldLocation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ADDRESS__LOCATION, oldLocation, location));
			}
		}
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Location basicGetLocation() {
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLocation(Location newLocation, NotificationChain msgs) {
		Location oldLocation = location;
		location = newLocation;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.ADDRESS__LOCATION, oldLocation, newLocation);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation(Location newLocation) {
		if (newLocation != location) {
			NotificationChain msgs = null;
			if (location != null)
				msgs = ((InternalEObject)location).eInverseRemove(this, Test1Package.LOCATION__ADDRESS, Location.class, msgs);
			if (newLocation != null)
				msgs = ((InternalEObject)newLocation).eInverseAdd(this, Test1Package.LOCATION__ADDRESS, Location.class, msgs);
			msgs = basicSetLocation(newLocation, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ADDRESS__LOCATION, newLocation, newLocation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails getUserId() {
		if (userId != null && userId.eIsProxy()) {
			InternalEObject oldUserId = (InternalEObject)userId;
			userId = (UserDetails)eResolveProxy(oldUserId);
			if (userId != oldUserId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ADDRESS__USER_ID, oldUserId, userId));
			}
		}
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails basicGetUserId() {
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserId(UserDetails newUserId) {
		UserDetails oldUserId = userId;
		userId = newUserId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ADDRESS__USER_ID, oldUserId, userId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails getUserDetails() {
		if (userDetails != null && userDetails.eIsProxy()) {
			InternalEObject oldUserDetails = (InternalEObject)userDetails;
			userDetails = (UserDetails)eResolveProxy(oldUserDetails);
			if (userDetails != oldUserDetails) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ADDRESS__USER_DETAILS, oldUserDetails, userDetails));
			}
		}
		return userDetails;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails basicGetUserDetails() {
		return userDetails;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetUserDetails(UserDetails newUserDetails, NotificationChain msgs) {
		UserDetails oldUserDetails = userDetails;
		userDetails = newUserDetails;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.ADDRESS__USER_DETAILS, oldUserDetails, newUserDetails);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserDetails(UserDetails newUserDetails) {
		if (newUserDetails != userDetails) {
			NotificationChain msgs = null;
			if (userDetails != null)
				msgs = ((InternalEObject)userDetails).eInverseRemove(this, Test1Package.USER_DETAILS__ADDRESS, UserDetails.class, msgs);
			if (newUserDetails != null)
				msgs = ((InternalEObject)newUserDetails).eInverseAdd(this, Test1Package.USER_DETAILS__ADDRESS, UserDetails.class, msgs);
			msgs = basicSetUserDetails(newUserDetails, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ADDRESS__USER_DETAILS, newUserDetails, newUserDetails));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAddressType() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.ADDRESS__LOCATION:
				if (location != null)
					msgs = ((InternalEObject)location).eInverseRemove(this, Test1Package.LOCATION__ADDRESS, Location.class, msgs);
				return basicSetLocation((Location)otherEnd, msgs);
			case Test1Package.ADDRESS__USER_DETAILS:
				if (userDetails != null)
					msgs = ((InternalEObject)userDetails).eInverseRemove(this, Test1Package.USER_DETAILS__ADDRESS, UserDetails.class, msgs);
				return basicSetUserDetails((UserDetails)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.ADDRESS__LOCATION:
				return basicSetLocation(null, msgs);
			case Test1Package.ADDRESS__USER_DETAILS:
				return basicSetUserDetails(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.ADDRESS__ADDRESS_TYPE:
				return getAddressType();
			case Test1Package.ADDRESS__LOCATION_ID:
				if (resolve) return getLocationId();
				return basicGetLocationId();
			case Test1Package.ADDRESS__LOCATION:
				if (resolve) return getLocation();
				return basicGetLocation();
			case Test1Package.ADDRESS__USER_ID:
				if (resolve) return getUserId();
				return basicGetUserId();
			case Test1Package.ADDRESS__USER_DETAILS:
				if (resolve) return getUserDetails();
				return basicGetUserDetails();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.ADDRESS__ADDRESS_TYPE:
				setAddressType((String)newValue);
				return;
			case Test1Package.ADDRESS__LOCATION_ID:
				setLocationId((Location)newValue);
				return;
			case Test1Package.ADDRESS__LOCATION:
				setLocation((Location)newValue);
				return;
			case Test1Package.ADDRESS__USER_ID:
				setUserId((UserDetails)newValue);
				return;
			case Test1Package.ADDRESS__USER_DETAILS:
				setUserDetails((UserDetails)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.ADDRESS__ADDRESS_TYPE:
				setAddressType(ADDRESS_TYPE_EDEFAULT);
				return;
			case Test1Package.ADDRESS__LOCATION_ID:
				setLocationId((Location)null);
				return;
			case Test1Package.ADDRESS__LOCATION:
				setLocation((Location)null);
				return;
			case Test1Package.ADDRESS__USER_ID:
				setUserId((UserDetails)null);
				return;
			case Test1Package.ADDRESS__USER_DETAILS:
				setUserDetails((UserDetails)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.ADDRESS__ADDRESS_TYPE:
				return ADDRESS_TYPE_EDEFAULT == null ? addressType != null : !ADDRESS_TYPE_EDEFAULT.equals(addressType);
			case Test1Package.ADDRESS__LOCATION_ID:
				return locationId != null;
			case Test1Package.ADDRESS__LOCATION:
				return location != null;
			case Test1Package.ADDRESS__USER_ID:
				return userId != null;
			case Test1Package.ADDRESS__USER_DETAILS:
				return userDetails != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.ADDRESS___SET_ADDRESS_TYPE:
				setAddressType();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (addressType: ");
		result.append(addressType);
		result.append(')');
		return result.toString();
	}

} //AddressImpl
