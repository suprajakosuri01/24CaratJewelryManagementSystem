/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import test1.Catalog;
import test1.Customer;
import test1.DeliveryAgent;
import test1.Discounts;
import test1.Order;
import test1.PaymentsInfo;
import test1.Status;
import test1.Test1Package;
import test1.Transactions;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Order</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.OrderImpl#getOrderId <em>Order Id</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getOrderPrice <em>Order Price</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getInstructions <em>Instructions</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getDiscountedPrice <em>Discounted Price</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getSourceLocationId <em>Source Location Id</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getDestinationId <em>Destination Id</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getTax <em>Tax</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getDelivery <em>Delivery</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getStatusId <em>Status Id</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getStatus <em>Status</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getAgentId <em>Agent Id</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getPaymentId <em>Payment Id</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getPromotionId <em>Promotion Id</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getDiscounts <em>Discounts</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getCustomerId <em>Customer Id</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getTransactions <em>Transactions</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getPaymentsInfo <em>Payments Info</em>}</li>
 *   <li>{@link test1.impl.OrderImpl#getCatalog <em>Catalog</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OrderImpl extends MinimalEObjectImpl.Container implements Order {
	/**
	 * The default value of the '{@link #getOrderId() <em>Order Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderId()
	 * @generated
	 * @ordered
	 */
	protected static final String ORDER_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOrderId() <em>Order Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderId()
	 * @generated
	 * @ordered
	 */
	protected String orderId = ORDER_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getOrderPrice() <em>Order Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderPrice()
	 * @generated
	 * @ordered
	 */
	protected static final float ORDER_PRICE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getOrderPrice() <em>Order Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderPrice()
	 * @generated
	 * @ordered
	 */
	protected float orderPrice = ORDER_PRICE_EDEFAULT;

	/**
	 * The default value of the '{@link #getInstructions() <em>Instructions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInstructions()
	 * @generated
	 * @ordered
	 */
	protected static final String INSTRUCTIONS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInstructions() <em>Instructions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInstructions()
	 * @generated
	 * @ordered
	 */
	protected String instructions = INSTRUCTIONS_EDEFAULT;

	/**
	 * The default value of the '{@link #getDiscountedPrice() <em>Discounted Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiscountedPrice()
	 * @generated
	 * @ordered
	 */
	protected static final float DISCOUNTED_PRICE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getDiscountedPrice() <em>Discounted Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiscountedPrice()
	 * @generated
	 * @ordered
	 */
	protected float discountedPrice = DISCOUNTED_PRICE_EDEFAULT;

	/**
	 * The default value of the '{@link #getSourceLocationId() <em>Source Location Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceLocationId()
	 * @generated
	 * @ordered
	 */
	protected static final String SOURCE_LOCATION_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSourceLocationId() <em>Source Location Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceLocationId()
	 * @generated
	 * @ordered
	 */
	protected String sourceLocationId = SOURCE_LOCATION_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getDestinationId() <em>Destination Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestinationId()
	 * @generated
	 * @ordered
	 */
	protected static final String DESTINATION_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDestinationId() <em>Destination Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestinationId()
	 * @generated
	 * @ordered
	 */
	protected String destinationId = DESTINATION_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getTax() <em>Tax</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTax()
	 * @generated
	 * @ordered
	 */
	protected static final float TAX_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getTax() <em>Tax</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTax()
	 * @generated
	 * @ordered
	 */
	protected float tax = TAX_EDEFAULT;

	/**
	 * The default value of the '{@link #getDelivery() <em>Delivery</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelivery()
	 * @generated
	 * @ordered
	 */
	protected static final float DELIVERY_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getDelivery() <em>Delivery</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelivery()
	 * @generated
	 * @ordered
	 */
	protected float delivery = DELIVERY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStatusId() <em>Status Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStatusId()
	 * @generated
	 * @ordered
	 */
	protected Status statusId;

	/**
	 * The cached value of the '{@link #getStatus() <em>Status</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStatus()
	 * @generated
	 * @ordered
	 */
	protected Status status;

	/**
	 * The cached value of the '{@link #getAgentId() <em>Agent Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgentId()
	 * @generated
	 * @ordered
	 */
	protected DeliveryAgent agentId;

	/**
	 * The cached value of the '{@link #getPaymentId() <em>Payment Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentId()
	 * @generated
	 * @ordered
	 */
	protected PaymentsInfo paymentId;

	/**
	 * The cached value of the '{@link #getPromotionId() <em>Promotion Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPromotionId()
	 * @generated
	 * @ordered
	 */
	protected Discounts promotionId;

	/**
	 * The cached value of the '{@link #getDiscounts() <em>Discounts</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiscounts()
	 * @generated
	 * @ordered
	 */
	protected Discounts discounts;

	/**
	 * The cached value of the '{@link #getCustomerId() <em>Customer Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomerId()
	 * @generated
	 * @ordered
	 */
	protected Customer customerId;

	/**
	 * The cached value of the '{@link #getTransactions() <em>Transactions</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactions()
	 * @generated
	 * @ordered
	 */
	protected Transactions transactions;

	/**
	 * The cached value of the '{@link #getPaymentsInfo() <em>Payments Info</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentsInfo()
	 * @generated
	 * @ordered
	 */
	protected PaymentsInfo paymentsInfo;

	/**
	 * The cached value of the '{@link #getCatalog() <em>Catalog</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCatalog()
	 * @generated
	 * @ordered
	 */
	protected EList<Catalog> catalog;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OrderImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.ORDER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderId(String newOrderId) {
		String oldOrderId = orderId;
		orderId = newOrderId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__ORDER_ID, oldOrderId, orderId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getOrderPrice() {
		return orderPrice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderPrice(float newOrderPrice) {
		float oldOrderPrice = orderPrice;
		orderPrice = newOrderPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__ORDER_PRICE, oldOrderPrice, orderPrice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInstructions() {
		return instructions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInstructions(String newInstructions) {
		String oldInstructions = instructions;
		instructions = newInstructions;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__INSTRUCTIONS, oldInstructions, instructions));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getDiscountedPrice() {
		return discountedPrice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDiscountedPrice(float newDiscountedPrice) {
		float oldDiscountedPrice = discountedPrice;
		discountedPrice = newDiscountedPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__DISCOUNTED_PRICE, oldDiscountedPrice, discountedPrice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSourceLocationId() {
		return sourceLocationId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceLocationId(String newSourceLocationId) {
		String oldSourceLocationId = sourceLocationId;
		sourceLocationId = newSourceLocationId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__SOURCE_LOCATION_ID, oldSourceLocationId, sourceLocationId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDestinationId() {
		return destinationId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDestinationId(String newDestinationId) {
		String oldDestinationId = destinationId;
		destinationId = newDestinationId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__DESTINATION_ID, oldDestinationId, destinationId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getTax() {
		return tax;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTax(float newTax) {
		float oldTax = tax;
		tax = newTax;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__TAX, oldTax, tax));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getDelivery() {
		return delivery;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDelivery(float newDelivery) {
		float oldDelivery = delivery;
		delivery = newDelivery;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__DELIVERY, oldDelivery, delivery));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Status getStatusId() {
		if (statusId != null && statusId.eIsProxy()) {
			InternalEObject oldStatusId = (InternalEObject)statusId;
			statusId = (Status)eResolveProxy(oldStatusId);
			if (statusId != oldStatusId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER__STATUS_ID, oldStatusId, statusId));
			}
		}
		return statusId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Status basicGetStatusId() {
		return statusId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStatusId(Status newStatusId) {
		Status oldStatusId = statusId;
		statusId = newStatusId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__STATUS_ID, oldStatusId, statusId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStatus(Status newStatus, NotificationChain msgs) {
		Status oldStatus = status;
		status = newStatus;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__STATUS, oldStatus, newStatus);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStatus(Status newStatus) {
		if (newStatus != status) {
			NotificationChain msgs = null;
			if (status != null)
				msgs = ((InternalEObject)status).eInverseRemove(this, Test1Package.STATUS__ORDER, Status.class, msgs);
			if (newStatus != null)
				msgs = ((InternalEObject)newStatus).eInverseAdd(this, Test1Package.STATUS__ORDER, Status.class, msgs);
			msgs = basicSetStatus(newStatus, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__STATUS, newStatus, newStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeliveryAgent getAgentId() {
		if (agentId != null && agentId.eIsProxy()) {
			InternalEObject oldAgentId = (InternalEObject)agentId;
			agentId = (DeliveryAgent)eResolveProxy(oldAgentId);
			if (agentId != oldAgentId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER__AGENT_ID, oldAgentId, agentId));
			}
		}
		return agentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeliveryAgent basicGetAgentId() {
		return agentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAgentId(DeliveryAgent newAgentId) {
		DeliveryAgent oldAgentId = agentId;
		agentId = newAgentId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__AGENT_ID, oldAgentId, agentId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentsInfo getPaymentId() {
		if (paymentId != null && paymentId.eIsProxy()) {
			InternalEObject oldPaymentId = (InternalEObject)paymentId;
			paymentId = (PaymentsInfo)eResolveProxy(oldPaymentId);
			if (paymentId != oldPaymentId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER__PAYMENT_ID, oldPaymentId, paymentId));
			}
		}
		return paymentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentsInfo basicGetPaymentId() {
		return paymentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPaymentId(PaymentsInfo newPaymentId) {
		PaymentsInfo oldPaymentId = paymentId;
		paymentId = newPaymentId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__PAYMENT_ID, oldPaymentId, paymentId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Discounts getPromotionId() {
		if (promotionId != null && promotionId.eIsProxy()) {
			InternalEObject oldPromotionId = (InternalEObject)promotionId;
			promotionId = (Discounts)eResolveProxy(oldPromotionId);
			if (promotionId != oldPromotionId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER__PROMOTION_ID, oldPromotionId, promotionId));
			}
		}
		return promotionId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Discounts basicGetPromotionId() {
		return promotionId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPromotionId(Discounts newPromotionId) {
		Discounts oldPromotionId = promotionId;
		promotionId = newPromotionId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__PROMOTION_ID, oldPromotionId, promotionId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Discounts getDiscounts() {
		if (discounts != null && discounts.eIsProxy()) {
			InternalEObject oldDiscounts = (InternalEObject)discounts;
			discounts = (Discounts)eResolveProxy(oldDiscounts);
			if (discounts != oldDiscounts) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER__DISCOUNTS, oldDiscounts, discounts));
			}
		}
		return discounts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Discounts basicGetDiscounts() {
		return discounts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDiscounts(Discounts newDiscounts, NotificationChain msgs) {
		Discounts oldDiscounts = discounts;
		discounts = newDiscounts;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__DISCOUNTS, oldDiscounts, newDiscounts);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDiscounts(Discounts newDiscounts) {
		if (newDiscounts != discounts) {
			NotificationChain msgs = null;
			if (discounts != null)
				msgs = ((InternalEObject)discounts).eInverseRemove(this, Test1Package.DISCOUNTS__ORDER, Discounts.class, msgs);
			if (newDiscounts != null)
				msgs = ((InternalEObject)newDiscounts).eInverseAdd(this, Test1Package.DISCOUNTS__ORDER, Discounts.class, msgs);
			msgs = basicSetDiscounts(newDiscounts, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__DISCOUNTS, newDiscounts, newDiscounts));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer getCustomerId() {
		if (customerId != null && customerId.eIsProxy()) {
			InternalEObject oldCustomerId = (InternalEObject)customerId;
			customerId = (Customer)eResolveProxy(oldCustomerId);
			if (customerId != oldCustomerId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER__CUSTOMER_ID, oldCustomerId, customerId));
			}
		}
		return customerId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer basicGetCustomerId() {
		return customerId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustomerId(Customer newCustomerId) {
		Customer oldCustomerId = customerId;
		customerId = newCustomerId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__CUSTOMER_ID, oldCustomerId, customerId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transactions getTransactions() {
		if (transactions != null && transactions.eIsProxy()) {
			InternalEObject oldTransactions = (InternalEObject)transactions;
			transactions = (Transactions)eResolveProxy(oldTransactions);
			if (transactions != oldTransactions) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER__TRANSACTIONS, oldTransactions, transactions));
			}
		}
		return transactions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transactions basicGetTransactions() {
		return transactions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTransactions(Transactions newTransactions, NotificationChain msgs) {
		Transactions oldTransactions = transactions;
		transactions = newTransactions;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__TRANSACTIONS, oldTransactions, newTransactions);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransactions(Transactions newTransactions) {
		if (newTransactions != transactions) {
			NotificationChain msgs = null;
			if (transactions != null)
				msgs = ((InternalEObject)transactions).eInverseRemove(this, Test1Package.TRANSACTIONS__ORDER, Transactions.class, msgs);
			if (newTransactions != null)
				msgs = ((InternalEObject)newTransactions).eInverseAdd(this, Test1Package.TRANSACTIONS__ORDER, Transactions.class, msgs);
			msgs = basicSetTransactions(newTransactions, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__TRANSACTIONS, newTransactions, newTransactions));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentsInfo getPaymentsInfo() {
		if (paymentsInfo != null && paymentsInfo.eIsProxy()) {
			InternalEObject oldPaymentsInfo = (InternalEObject)paymentsInfo;
			paymentsInfo = (PaymentsInfo)eResolveProxy(oldPaymentsInfo);
			if (paymentsInfo != oldPaymentsInfo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER__PAYMENTS_INFO, oldPaymentsInfo, paymentsInfo));
			}
		}
		return paymentsInfo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentsInfo basicGetPaymentsInfo() {
		return paymentsInfo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPaymentsInfo(PaymentsInfo newPaymentsInfo, NotificationChain msgs) {
		PaymentsInfo oldPaymentsInfo = paymentsInfo;
		paymentsInfo = newPaymentsInfo;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__PAYMENTS_INFO, oldPaymentsInfo, newPaymentsInfo);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPaymentsInfo(PaymentsInfo newPaymentsInfo) {
		if (newPaymentsInfo != paymentsInfo) {
			NotificationChain msgs = null;
			if (paymentsInfo != null)
				msgs = ((InternalEObject)paymentsInfo).eInverseRemove(this, Test1Package.PAYMENTS_INFO__ORDER, PaymentsInfo.class, msgs);
			if (newPaymentsInfo != null)
				msgs = ((InternalEObject)newPaymentsInfo).eInverseAdd(this, Test1Package.PAYMENTS_INFO__ORDER, PaymentsInfo.class, msgs);
			msgs = basicSetPaymentsInfo(newPaymentsInfo, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER__PAYMENTS_INFO, newPaymentsInfo, newPaymentsInfo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Catalog> getCatalog() {
		if (catalog == null) {
			catalog = new EObjectWithInverseResolvingEList<Catalog>(Catalog.class, this, Test1Package.ORDER__CATALOG, Test1Package.CATALOG__ORDER);
		}
		return catalog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderPrice() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInstructions() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDiscountedPrice() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceLocationId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTax() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeliveryFee() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOderId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void getDeliveryFee() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.ORDER__STATUS:
				if (status != null)
					msgs = ((InternalEObject)status).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Test1Package.ORDER__STATUS, null, msgs);
				return basicSetStatus((Status)otherEnd, msgs);
			case Test1Package.ORDER__DISCOUNTS:
				if (discounts != null)
					msgs = ((InternalEObject)discounts).eInverseRemove(this, Test1Package.DISCOUNTS__ORDER, Discounts.class, msgs);
				return basicSetDiscounts((Discounts)otherEnd, msgs);
			case Test1Package.ORDER__TRANSACTIONS:
				if (transactions != null)
					msgs = ((InternalEObject)transactions).eInverseRemove(this, Test1Package.TRANSACTIONS__ORDER, Transactions.class, msgs);
				return basicSetTransactions((Transactions)otherEnd, msgs);
			case Test1Package.ORDER__PAYMENTS_INFO:
				if (paymentsInfo != null)
					msgs = ((InternalEObject)paymentsInfo).eInverseRemove(this, Test1Package.PAYMENTS_INFO__ORDER, PaymentsInfo.class, msgs);
				return basicSetPaymentsInfo((PaymentsInfo)otherEnd, msgs);
			case Test1Package.ORDER__CATALOG:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getCatalog()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.ORDER__STATUS:
				return basicSetStatus(null, msgs);
			case Test1Package.ORDER__DISCOUNTS:
				return basicSetDiscounts(null, msgs);
			case Test1Package.ORDER__TRANSACTIONS:
				return basicSetTransactions(null, msgs);
			case Test1Package.ORDER__PAYMENTS_INFO:
				return basicSetPaymentsInfo(null, msgs);
			case Test1Package.ORDER__CATALOG:
				return ((InternalEList<?>)getCatalog()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.ORDER__ORDER_ID:
				return getOrderId();
			case Test1Package.ORDER__ORDER_PRICE:
				return getOrderPrice();
			case Test1Package.ORDER__INSTRUCTIONS:
				return getInstructions();
			case Test1Package.ORDER__DISCOUNTED_PRICE:
				return getDiscountedPrice();
			case Test1Package.ORDER__SOURCE_LOCATION_ID:
				return getSourceLocationId();
			case Test1Package.ORDER__DESTINATION_ID:
				return getDestinationId();
			case Test1Package.ORDER__TAX:
				return getTax();
			case Test1Package.ORDER__DELIVERY:
				return getDelivery();
			case Test1Package.ORDER__STATUS_ID:
				if (resolve) return getStatusId();
				return basicGetStatusId();
			case Test1Package.ORDER__STATUS:
				return getStatus();
			case Test1Package.ORDER__AGENT_ID:
				if (resolve) return getAgentId();
				return basicGetAgentId();
			case Test1Package.ORDER__PAYMENT_ID:
				if (resolve) return getPaymentId();
				return basicGetPaymentId();
			case Test1Package.ORDER__PROMOTION_ID:
				if (resolve) return getPromotionId();
				return basicGetPromotionId();
			case Test1Package.ORDER__DISCOUNTS:
				if (resolve) return getDiscounts();
				return basicGetDiscounts();
			case Test1Package.ORDER__CUSTOMER_ID:
				if (resolve) return getCustomerId();
				return basicGetCustomerId();
			case Test1Package.ORDER__TRANSACTIONS:
				if (resolve) return getTransactions();
				return basicGetTransactions();
			case Test1Package.ORDER__PAYMENTS_INFO:
				if (resolve) return getPaymentsInfo();
				return basicGetPaymentsInfo();
			case Test1Package.ORDER__CATALOG:
				return getCatalog();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.ORDER__ORDER_ID:
				setOrderId((String)newValue);
				return;
			case Test1Package.ORDER__ORDER_PRICE:
				setOrderPrice((Float)newValue);
				return;
			case Test1Package.ORDER__INSTRUCTIONS:
				setInstructions((String)newValue);
				return;
			case Test1Package.ORDER__DISCOUNTED_PRICE:
				setDiscountedPrice((Float)newValue);
				return;
			case Test1Package.ORDER__SOURCE_LOCATION_ID:
				setSourceLocationId((String)newValue);
				return;
			case Test1Package.ORDER__DESTINATION_ID:
				setDestinationId((String)newValue);
				return;
			case Test1Package.ORDER__TAX:
				setTax((Float)newValue);
				return;
			case Test1Package.ORDER__DELIVERY:
				setDelivery((Float)newValue);
				return;
			case Test1Package.ORDER__STATUS_ID:
				setStatusId((Status)newValue);
				return;
			case Test1Package.ORDER__STATUS:
				setStatus((Status)newValue);
				return;
			case Test1Package.ORDER__AGENT_ID:
				setAgentId((DeliveryAgent)newValue);
				return;
			case Test1Package.ORDER__PAYMENT_ID:
				setPaymentId((PaymentsInfo)newValue);
				return;
			case Test1Package.ORDER__PROMOTION_ID:
				setPromotionId((Discounts)newValue);
				return;
			case Test1Package.ORDER__DISCOUNTS:
				setDiscounts((Discounts)newValue);
				return;
			case Test1Package.ORDER__CUSTOMER_ID:
				setCustomerId((Customer)newValue);
				return;
			case Test1Package.ORDER__TRANSACTIONS:
				setTransactions((Transactions)newValue);
				return;
			case Test1Package.ORDER__PAYMENTS_INFO:
				setPaymentsInfo((PaymentsInfo)newValue);
				return;
			case Test1Package.ORDER__CATALOG:
				getCatalog().clear();
				getCatalog().addAll((Collection<? extends Catalog>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.ORDER__ORDER_ID:
				setOrderId(ORDER_ID_EDEFAULT);
				return;
			case Test1Package.ORDER__ORDER_PRICE:
				setOrderPrice(ORDER_PRICE_EDEFAULT);
				return;
			case Test1Package.ORDER__INSTRUCTIONS:
				setInstructions(INSTRUCTIONS_EDEFAULT);
				return;
			case Test1Package.ORDER__DISCOUNTED_PRICE:
				setDiscountedPrice(DISCOUNTED_PRICE_EDEFAULT);
				return;
			case Test1Package.ORDER__SOURCE_LOCATION_ID:
				setSourceLocationId(SOURCE_LOCATION_ID_EDEFAULT);
				return;
			case Test1Package.ORDER__DESTINATION_ID:
				setDestinationId(DESTINATION_ID_EDEFAULT);
				return;
			case Test1Package.ORDER__TAX:
				setTax(TAX_EDEFAULT);
				return;
			case Test1Package.ORDER__DELIVERY:
				setDelivery(DELIVERY_EDEFAULT);
				return;
			case Test1Package.ORDER__STATUS_ID:
				setStatusId((Status)null);
				return;
			case Test1Package.ORDER__STATUS:
				setStatus((Status)null);
				return;
			case Test1Package.ORDER__AGENT_ID:
				setAgentId((DeliveryAgent)null);
				return;
			case Test1Package.ORDER__PAYMENT_ID:
				setPaymentId((PaymentsInfo)null);
				return;
			case Test1Package.ORDER__PROMOTION_ID:
				setPromotionId((Discounts)null);
				return;
			case Test1Package.ORDER__DISCOUNTS:
				setDiscounts((Discounts)null);
				return;
			case Test1Package.ORDER__CUSTOMER_ID:
				setCustomerId((Customer)null);
				return;
			case Test1Package.ORDER__TRANSACTIONS:
				setTransactions((Transactions)null);
				return;
			case Test1Package.ORDER__PAYMENTS_INFO:
				setPaymentsInfo((PaymentsInfo)null);
				return;
			case Test1Package.ORDER__CATALOG:
				getCatalog().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.ORDER__ORDER_ID:
				return ORDER_ID_EDEFAULT == null ? orderId != null : !ORDER_ID_EDEFAULT.equals(orderId);
			case Test1Package.ORDER__ORDER_PRICE:
				return orderPrice != ORDER_PRICE_EDEFAULT;
			case Test1Package.ORDER__INSTRUCTIONS:
				return INSTRUCTIONS_EDEFAULT == null ? instructions != null : !INSTRUCTIONS_EDEFAULT.equals(instructions);
			case Test1Package.ORDER__DISCOUNTED_PRICE:
				return discountedPrice != DISCOUNTED_PRICE_EDEFAULT;
			case Test1Package.ORDER__SOURCE_LOCATION_ID:
				return SOURCE_LOCATION_ID_EDEFAULT == null ? sourceLocationId != null : !SOURCE_LOCATION_ID_EDEFAULT.equals(sourceLocationId);
			case Test1Package.ORDER__DESTINATION_ID:
				return DESTINATION_ID_EDEFAULT == null ? destinationId != null : !DESTINATION_ID_EDEFAULT.equals(destinationId);
			case Test1Package.ORDER__TAX:
				return tax != TAX_EDEFAULT;
			case Test1Package.ORDER__DELIVERY:
				return delivery != DELIVERY_EDEFAULT;
			case Test1Package.ORDER__STATUS_ID:
				return statusId != null;
			case Test1Package.ORDER__STATUS:
				return status != null;
			case Test1Package.ORDER__AGENT_ID:
				return agentId != null;
			case Test1Package.ORDER__PAYMENT_ID:
				return paymentId != null;
			case Test1Package.ORDER__PROMOTION_ID:
				return promotionId != null;
			case Test1Package.ORDER__DISCOUNTS:
				return discounts != null;
			case Test1Package.ORDER__CUSTOMER_ID:
				return customerId != null;
			case Test1Package.ORDER__TRANSACTIONS:
				return transactions != null;
			case Test1Package.ORDER__PAYMENTS_INFO:
				return paymentsInfo != null;
			case Test1Package.ORDER__CATALOG:
				return catalog != null && !catalog.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.ORDER___SET_ORDER_ID:
				setOrderId();
				return null;
			case Test1Package.ORDER___SET_ORDER_PRICE:
				setOrderPrice();
				return null;
			case Test1Package.ORDER___SET_INSTRUCTIONS:
				setInstructions();
				return null;
			case Test1Package.ORDER___SET_DISCOUNTED_PRICE:
				setDiscountedPrice();
				return null;
			case Test1Package.ORDER___SET_SOURCE_LOCATION_ID:
				setSourceLocationId();
				return null;
			case Test1Package.ORDER___SET_TAX:
				setTax();
				return null;
			case Test1Package.ORDER___SET_DELIVERY_FEE:
				setDeliveryFee();
				return null;
			case Test1Package.ORDER___SET_ODER_ID:
				setOderId();
				return null;
			case Test1Package.ORDER___GET_DELIVERY_FEE:
				getDeliveryFee();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (orderId: ");
		result.append(orderId);
		result.append(", orderPrice: ");
		result.append(orderPrice);
		result.append(", instructions: ");
		result.append(instructions);
		result.append(", discountedPrice: ");
		result.append(discountedPrice);
		result.append(", sourceLocationId: ");
		result.append(sourceLocationId);
		result.append(", destinationId: ");
		result.append(destinationId);
		result.append(", tax: ");
		result.append(tax);
		result.append(", delivery: ");
		result.append(delivery);
		result.append(')');
		return result.toString();
	}

} //OrderImpl
