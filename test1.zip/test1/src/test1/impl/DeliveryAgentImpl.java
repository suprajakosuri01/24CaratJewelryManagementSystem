/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Map;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.emf.ecore.util.EObjectValidator;

import org.eclipse.ocl.ParserException;

import org.eclipse.ocl.ecore.Constraint;
import org.eclipse.ocl.ecore.OCL;

import test1.DeliveryAgent;
import test1.Test1Package;
import test1.UserDetails;

import test1.util.Test1Validator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Delivery Agent</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.DeliveryAgentImpl#getAgentId <em>Agent Id</em>}</li>
 *   <li>{@link test1.impl.DeliveryAgentImpl#getContactNo <em>Contact No</em>}</li>
 *   <li>{@link test1.impl.DeliveryAgentImpl#getSsn <em>Ssn</em>}</li>
 *   <li>{@link test1.impl.DeliveryAgentImpl#getDrivingLicenseNo <em>Driving License No</em>}</li>
 *   <li>{@link test1.impl.DeliveryAgentImpl#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.impl.DeliveryAgentImpl#getUserDetails <em>User Details</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DeliveryAgentImpl extends PersonImpl implements DeliveryAgent {
	/**
	 * The default value of the '{@link #getAgentId() <em>Agent Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgentId()
	 * @generated
	 * @ordered
	 */
	protected static final String AGENT_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAgentId() <em>Agent Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgentId()
	 * @generated
	 * @ordered
	 */
	protected String agentId = AGENT_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getContactNo() <em>Contact No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContactNo()
	 * @generated
	 * @ordered
	 */
	protected static final int CONTACT_NO_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getContactNo() <em>Contact No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContactNo()
	 * @generated
	 * @ordered
	 */
	protected int contactNo = CONTACT_NO_EDEFAULT;

	/**
	 * The default value of the '{@link #getSsn() <em>Ssn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSsn()
	 * @generated
	 * @ordered
	 */
	protected static final int SSN_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSsn() <em>Ssn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSsn()
	 * @generated
	 * @ordered
	 */
	protected int ssn = SSN_EDEFAULT;

	/**
	 * The default value of the '{@link #getDrivingLicenseNo() <em>Driving License No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrivingLicenseNo()
	 * @generated
	 * @ordered
	 */
	protected static final String DRIVING_LICENSE_NO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDrivingLicenseNo() <em>Driving License No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrivingLicenseNo()
	 * @generated
	 * @ordered
	 */
	protected String drivingLicenseNo = DRIVING_LICENSE_NO_EDEFAULT;

	/**
	 * The cached value of the '{@link #getUserId() <em>User Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserId()
	 * @generated
	 * @ordered
	 */
	protected UserDetails userId;

	/**
	 * The cached value of the '{@link #getUserDetails() <em>User Details</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserDetails()
	 * @generated
	 * @ordered
	 */
	protected UserDetails userDetails;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DeliveryAgentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.DELIVERY_AGENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAgentId() {
		return agentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAgentId(String newAgentId) {
		String oldAgentId = agentId;
		agentId = newAgentId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DELIVERY_AGENT__AGENT_ID, oldAgentId, agentId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getContactNo() {
		return contactNo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContactNo(int newContactNo) {
		int oldContactNo = contactNo;
		contactNo = newContactNo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DELIVERY_AGENT__CONTACT_NO, oldContactNo, contactNo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSsn() {
		return ssn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSsn(int newSsn) {
		int oldSsn = ssn;
		ssn = newSsn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DELIVERY_AGENT__SSN, oldSsn, ssn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDrivingLicenseNo() {
		return drivingLicenseNo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDrivingLicenseNo(String newDrivingLicenseNo) {
		String oldDrivingLicenseNo = drivingLicenseNo;
		drivingLicenseNo = newDrivingLicenseNo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DELIVERY_AGENT__DRIVING_LICENSE_NO, oldDrivingLicenseNo, drivingLicenseNo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails getUserId() {
		if (userId != null && userId.eIsProxy()) {
			InternalEObject oldUserId = (InternalEObject)userId;
			userId = (UserDetails)eResolveProxy(oldUserId);
			if (userId != oldUserId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.DELIVERY_AGENT__USER_ID, oldUserId, userId));
			}
		}
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails basicGetUserId() {
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserId(UserDetails newUserId) {
		UserDetails oldUserId = userId;
		userId = newUserId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DELIVERY_AGENT__USER_ID, oldUserId, userId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails getUserDetails() {
		return userDetails;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetUserDetails(UserDetails newUserDetails, NotificationChain msgs) {
		UserDetails oldUserDetails = userDetails;
		userDetails = newUserDetails;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.DELIVERY_AGENT__USER_DETAILS, oldUserDetails, newUserDetails);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserDetails(UserDetails newUserDetails) {
		if (newUserDetails != userDetails) {
			NotificationChain msgs = null;
			if (userDetails != null)
				msgs = ((InternalEObject)userDetails).eInverseRemove(this, Test1Package.USER_DETAILS__DELIVERY_AGENT, UserDetails.class, msgs);
			if (newUserDetails != null)
				msgs = ((InternalEObject)newUserDetails).eInverseAdd(this, Test1Package.USER_DETAILS__DELIVERY_AGENT, UserDetails.class, msgs);
			msgs = basicSetUserDetails(newUserDetails, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DELIVERY_AGENT__USER_DETAILS, newUserDetails, newUserDetails));
	}

	/**
	 * The cached OCL expression body for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static final String CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP = "ssn attribute in the DeliveryAgent class is not null and has a length of 9.";

	/**
	 * The cached OCL invariant for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' invariant operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static Constraint CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV == null) {
			OCL.Helper helper = EOCL_ENV.createOCLHelper();
			helper.setContext(Test1Package.Literals.DELIVERY_AGENT);
			try {
				CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV = helper.createInvariant(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP);
			}
			catch (ParserException pe) {
				throw new UnsupportedOperationException(pe.getLocalizedMessage());
			}
		}
		if (!EOCL_ENV.createQuery(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV).check(this)) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 Test1Validator.DIAGNOSTIC_SOURCE,
						 Test1Validator.DELIVERY_AGENT__CONSTRAINT1,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "constraint1", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAgentId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContactNo() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSsn() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDrivingLicenseNo() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.DELIVERY_AGENT__USER_DETAILS:
				if (userDetails != null)
					msgs = ((InternalEObject)userDetails).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Test1Package.DELIVERY_AGENT__USER_DETAILS, null, msgs);
				return basicSetUserDetails((UserDetails)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.DELIVERY_AGENT__USER_DETAILS:
				return basicSetUserDetails(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.DELIVERY_AGENT__AGENT_ID:
				return getAgentId();
			case Test1Package.DELIVERY_AGENT__CONTACT_NO:
				return getContactNo();
			case Test1Package.DELIVERY_AGENT__SSN:
				return getSsn();
			case Test1Package.DELIVERY_AGENT__DRIVING_LICENSE_NO:
				return getDrivingLicenseNo();
			case Test1Package.DELIVERY_AGENT__USER_ID:
				if (resolve) return getUserId();
				return basicGetUserId();
			case Test1Package.DELIVERY_AGENT__USER_DETAILS:
				return getUserDetails();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.DELIVERY_AGENT__AGENT_ID:
				setAgentId((String)newValue);
				return;
			case Test1Package.DELIVERY_AGENT__CONTACT_NO:
				setContactNo((Integer)newValue);
				return;
			case Test1Package.DELIVERY_AGENT__SSN:
				setSsn((Integer)newValue);
				return;
			case Test1Package.DELIVERY_AGENT__DRIVING_LICENSE_NO:
				setDrivingLicenseNo((String)newValue);
				return;
			case Test1Package.DELIVERY_AGENT__USER_ID:
				setUserId((UserDetails)newValue);
				return;
			case Test1Package.DELIVERY_AGENT__USER_DETAILS:
				setUserDetails((UserDetails)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.DELIVERY_AGENT__AGENT_ID:
				setAgentId(AGENT_ID_EDEFAULT);
				return;
			case Test1Package.DELIVERY_AGENT__CONTACT_NO:
				setContactNo(CONTACT_NO_EDEFAULT);
				return;
			case Test1Package.DELIVERY_AGENT__SSN:
				setSsn(SSN_EDEFAULT);
				return;
			case Test1Package.DELIVERY_AGENT__DRIVING_LICENSE_NO:
				setDrivingLicenseNo(DRIVING_LICENSE_NO_EDEFAULT);
				return;
			case Test1Package.DELIVERY_AGENT__USER_ID:
				setUserId((UserDetails)null);
				return;
			case Test1Package.DELIVERY_AGENT__USER_DETAILS:
				setUserDetails((UserDetails)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.DELIVERY_AGENT__AGENT_ID:
				return AGENT_ID_EDEFAULT == null ? agentId != null : !AGENT_ID_EDEFAULT.equals(agentId);
			case Test1Package.DELIVERY_AGENT__CONTACT_NO:
				return contactNo != CONTACT_NO_EDEFAULT;
			case Test1Package.DELIVERY_AGENT__SSN:
				return ssn != SSN_EDEFAULT;
			case Test1Package.DELIVERY_AGENT__DRIVING_LICENSE_NO:
				return DRIVING_LICENSE_NO_EDEFAULT == null ? drivingLicenseNo != null : !DRIVING_LICENSE_NO_EDEFAULT.equals(drivingLicenseNo);
			case Test1Package.DELIVERY_AGENT__USER_ID:
				return userId != null;
			case Test1Package.DELIVERY_AGENT__USER_DETAILS:
				return userDetails != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.DELIVERY_AGENT___CONSTRAINT1__DIAGNOSTICCHAIN_MAP:
				return constraint1((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case Test1Package.DELIVERY_AGENT___SET_AGENT_ID:
				setAgentId();
				return null;
			case Test1Package.DELIVERY_AGENT___SET_CONTACT_NO:
				setContactNo();
				return null;
			case Test1Package.DELIVERY_AGENT___SET_SSN:
				setSsn();
				return null;
			case Test1Package.DELIVERY_AGENT___SET_DRIVING_LICENSE_NO:
				setDrivingLicenseNo();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (agentId: ");
		result.append(agentId);
		result.append(", contactNo: ");
		result.append(contactNo);
		result.append(", ssn: ");
		result.append(ssn);
		result.append(", drivingLicenseNo: ");
		result.append(drivingLicenseNo);
		result.append(')');
		return result.toString();
	}

	/**
	 * The cached environment for evaluating OCL expressions.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected static final OCL EOCL_ENV = OCL.newInstance();

} //DeliveryAgentImpl
