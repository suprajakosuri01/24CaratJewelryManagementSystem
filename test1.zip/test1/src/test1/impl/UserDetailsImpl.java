/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;
import java.util.Map;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.emf.ecore.util.EObjectValidator;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.ParserException;

import org.eclipse.ocl.ecore.Constraint;
import org.eclipse.ocl.ecore.OCL;

import test1.Address;
import test1.Customer;
import test1.DeliveryAgent;
import test1.Test1Package;
import test1.UserDetails;

import test1.util.Test1Validator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>User Details</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.UserDetailsImpl#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.impl.UserDetailsImpl#getUsername <em>Username</em>}</li>
 *   <li>{@link test1.impl.UserDetailsImpl#getPassword <em>Password</em>}</li>
 *   <li>{@link test1.impl.UserDetailsImpl#getDeliveryAgent <em>Delivery Agent</em>}</li>
 *   <li>{@link test1.impl.UserDetailsImpl#getCustomer <em>Customer</em>}</li>
 *   <li>{@link test1.impl.UserDetailsImpl#getAddress <em>Address</em>}</li>
 * </ul>
 *
 * @generated
 */
public class UserDetailsImpl extends MinimalEObjectImpl.Container implements UserDetails {
	/**
	 * The default value of the '{@link #getUserId() <em>User Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserId()
	 * @generated
	 * @ordered
	 */
	protected static final String USER_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUserId() <em>User Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserId()
	 * @generated
	 * @ordered
	 */
	protected String userId = USER_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getUsername() <em>Username</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsername()
	 * @generated
	 * @ordered
	 */
	protected static final String USERNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUsername() <em>Username</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsername()
	 * @generated
	 * @ordered
	 */
	protected String username = USERNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPassword() <em>Password</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassword()
	 * @generated
	 * @ordered
	 */
	protected static final String PASSWORD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPassword() <em>Password</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassword()
	 * @generated
	 * @ordered
	 */
	protected String password = PASSWORD_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAddress() <em>Address</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddress()
	 * @generated
	 * @ordered
	 */
	protected EList<Address> address;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UserDetailsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.USER_DETAILS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserId(String newUserId) {
		String oldUserId = userId;
		userId = newUserId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.USER_DETAILS__USER_ID, oldUserId, userId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUsername(String newUsername) {
		String oldUsername = username;
		username = newUsername;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.USER_DETAILS__USERNAME, oldUsername, username));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPassword(String newPassword) {
		String oldPassword = password;
		password = newPassword;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.USER_DETAILS__PASSWORD, oldPassword, password));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeliveryAgent getDeliveryAgent() {
		if (eContainerFeatureID() != Test1Package.USER_DETAILS__DELIVERY_AGENT) return null;
		return (DeliveryAgent)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDeliveryAgent(DeliveryAgent newDeliveryAgent, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newDeliveryAgent, Test1Package.USER_DETAILS__DELIVERY_AGENT, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeliveryAgent(DeliveryAgent newDeliveryAgent) {
		if (newDeliveryAgent != eInternalContainer() || (eContainerFeatureID() != Test1Package.USER_DETAILS__DELIVERY_AGENT && newDeliveryAgent != null)) {
			if (EcoreUtil.isAncestor(this, newDeliveryAgent))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newDeliveryAgent != null)
				msgs = ((InternalEObject)newDeliveryAgent).eInverseAdd(this, Test1Package.DELIVERY_AGENT__USER_DETAILS, DeliveryAgent.class, msgs);
			msgs = basicSetDeliveryAgent(newDeliveryAgent, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.USER_DETAILS__DELIVERY_AGENT, newDeliveryAgent, newDeliveryAgent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer getCustomer() {
		if (eContainerFeatureID() != Test1Package.USER_DETAILS__CUSTOMER) return null;
		return (Customer)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCustomer(Customer newCustomer, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newCustomer, Test1Package.USER_DETAILS__CUSTOMER, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustomer(Customer newCustomer) {
		if (newCustomer != eInternalContainer() || (eContainerFeatureID() != Test1Package.USER_DETAILS__CUSTOMER && newCustomer != null)) {
			if (EcoreUtil.isAncestor(this, newCustomer))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newCustomer != null)
				msgs = ((InternalEObject)newCustomer).eInverseAdd(this, Test1Package.CUSTOMER__USER_DETAILS, Customer.class, msgs);
			msgs = basicSetCustomer(newCustomer, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.USER_DETAILS__CUSTOMER, newCustomer, newCustomer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Address> getAddress() {
		if (address == null) {
			address = new EObjectWithInverseResolvingEList<Address>(Address.class, this, Test1Package.USER_DETAILS__ADDRESS, Test1Package.ADDRESS__USER_DETAILS);
		}
		return address;
	}

	/**
	 * The cached OCL expression body for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static final String CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP = "username attribute contains only alphanumeric characters";

	/**
	 * The cached OCL invariant for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' invariant operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static Constraint CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV == null) {
			OCL.Helper helper = EOCL_ENV.createOCLHelper();
			helper.setContext(Test1Package.Literals.USER_DETAILS);
			try {
				CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV = helper.createInvariant(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP);
			}
			catch (ParserException pe) {
				throw new UnsupportedOperationException(pe.getLocalizedMessage());
			}
		}
		if (!EOCL_ENV.createQuery(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV).check(this)) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 Test1Validator.DIAGNOSTIC_SOURCE,
						 Test1Validator.USER_DETAILS__CONSTRAINT1,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "constraint1", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUsername() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPassword() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.USER_DETAILS__DELIVERY_AGENT:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetDeliveryAgent((DeliveryAgent)otherEnd, msgs);
			case Test1Package.USER_DETAILS__CUSTOMER:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetCustomer((Customer)otherEnd, msgs);
			case Test1Package.USER_DETAILS__ADDRESS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getAddress()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.USER_DETAILS__DELIVERY_AGENT:
				return basicSetDeliveryAgent(null, msgs);
			case Test1Package.USER_DETAILS__CUSTOMER:
				return basicSetCustomer(null, msgs);
			case Test1Package.USER_DETAILS__ADDRESS:
				return ((InternalEList<?>)getAddress()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case Test1Package.USER_DETAILS__DELIVERY_AGENT:
				return eInternalContainer().eInverseRemove(this, Test1Package.DELIVERY_AGENT__USER_DETAILS, DeliveryAgent.class, msgs);
			case Test1Package.USER_DETAILS__CUSTOMER:
				return eInternalContainer().eInverseRemove(this, Test1Package.CUSTOMER__USER_DETAILS, Customer.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.USER_DETAILS__USER_ID:
				return getUserId();
			case Test1Package.USER_DETAILS__USERNAME:
				return getUsername();
			case Test1Package.USER_DETAILS__PASSWORD:
				return getPassword();
			case Test1Package.USER_DETAILS__DELIVERY_AGENT:
				return getDeliveryAgent();
			case Test1Package.USER_DETAILS__CUSTOMER:
				return getCustomer();
			case Test1Package.USER_DETAILS__ADDRESS:
				return getAddress();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.USER_DETAILS__USER_ID:
				setUserId((String)newValue);
				return;
			case Test1Package.USER_DETAILS__USERNAME:
				setUsername((String)newValue);
				return;
			case Test1Package.USER_DETAILS__PASSWORD:
				setPassword((String)newValue);
				return;
			case Test1Package.USER_DETAILS__DELIVERY_AGENT:
				setDeliveryAgent((DeliveryAgent)newValue);
				return;
			case Test1Package.USER_DETAILS__CUSTOMER:
				setCustomer((Customer)newValue);
				return;
			case Test1Package.USER_DETAILS__ADDRESS:
				getAddress().clear();
				getAddress().addAll((Collection<? extends Address>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.USER_DETAILS__USER_ID:
				setUserId(USER_ID_EDEFAULT);
				return;
			case Test1Package.USER_DETAILS__USERNAME:
				setUsername(USERNAME_EDEFAULT);
				return;
			case Test1Package.USER_DETAILS__PASSWORD:
				setPassword(PASSWORD_EDEFAULT);
				return;
			case Test1Package.USER_DETAILS__DELIVERY_AGENT:
				setDeliveryAgent((DeliveryAgent)null);
				return;
			case Test1Package.USER_DETAILS__CUSTOMER:
				setCustomer((Customer)null);
				return;
			case Test1Package.USER_DETAILS__ADDRESS:
				getAddress().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.USER_DETAILS__USER_ID:
				return USER_ID_EDEFAULT == null ? userId != null : !USER_ID_EDEFAULT.equals(userId);
			case Test1Package.USER_DETAILS__USERNAME:
				return USERNAME_EDEFAULT == null ? username != null : !USERNAME_EDEFAULT.equals(username);
			case Test1Package.USER_DETAILS__PASSWORD:
				return PASSWORD_EDEFAULT == null ? password != null : !PASSWORD_EDEFAULT.equals(password);
			case Test1Package.USER_DETAILS__DELIVERY_AGENT:
				return getDeliveryAgent() != null;
			case Test1Package.USER_DETAILS__CUSTOMER:
				return getCustomer() != null;
			case Test1Package.USER_DETAILS__ADDRESS:
				return address != null && !address.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.USER_DETAILS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP:
				return constraint1((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case Test1Package.USER_DETAILS___SET_USER_ID:
				setUserId();
				return null;
			case Test1Package.USER_DETAILS___SET_USERNAME:
				setUsername();
				return null;
			case Test1Package.USER_DETAILS___SET_PASSWORD:
				setPassword();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (userId: ");
		result.append(userId);
		result.append(", username: ");
		result.append(username);
		result.append(", password: ");
		result.append(password);
		result.append(')');
		return result.toString();
	}

	/**
	 * The cached environment for evaluating OCL expressions.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected static final OCL EOCL_ENV = OCL.newInstance();

} //UserDetailsImpl
