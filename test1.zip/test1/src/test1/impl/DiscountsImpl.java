/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import test1.Discounts;
import test1.Order;
import test1.Test1Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Discounts</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.DiscountsImpl#getPromotionId <em>Promotion Id</em>}</li>
 *   <li>{@link test1.impl.DiscountsImpl#getPromotionName <em>Promotion Name</em>}</li>
 *   <li>{@link test1.impl.DiscountsImpl#getPromotionCode <em>Promotion Code</em>}</li>
 *   <li>{@link test1.impl.DiscountsImpl#getOrder <em>Order</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DiscountsImpl extends MinimalEObjectImpl.Container implements Discounts {
	/**
	 * The default value of the '{@link #getPromotionId() <em>Promotion Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPromotionId()
	 * @generated
	 * @ordered
	 */
	protected static final String PROMOTION_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPromotionId() <em>Promotion Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPromotionId()
	 * @generated
	 * @ordered
	 */
	protected String promotionId = PROMOTION_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getPromotionName() <em>Promotion Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPromotionName()
	 * @generated
	 * @ordered
	 */
	protected static final String PROMOTION_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPromotionName() <em>Promotion Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPromotionName()
	 * @generated
	 * @ordered
	 */
	protected String promotionName = PROMOTION_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPromotionCode() <em>Promotion Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPromotionCode()
	 * @generated
	 * @ordered
	 */
	protected static final String PROMOTION_CODE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPromotionCode() <em>Promotion Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPromotionCode()
	 * @generated
	 * @ordered
	 */
	protected String promotionCode = PROMOTION_CODE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOrder() <em>Order</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrder()
	 * @generated
	 * @ordered
	 */
	protected Order order;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiscountsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.DISCOUNTS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPromotionId() {
		return promotionId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPromotionId(String newPromotionId) {
		String oldPromotionId = promotionId;
		promotionId = newPromotionId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DISCOUNTS__PROMOTION_ID, oldPromotionId, promotionId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPromotionName() {
		return promotionName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPromotionName(String newPromotionName) {
		String oldPromotionName = promotionName;
		promotionName = newPromotionName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DISCOUNTS__PROMOTION_NAME, oldPromotionName, promotionName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPromotionCode() {
		return promotionCode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPromotionCode(String newPromotionCode) {
		String oldPromotionCode = promotionCode;
		promotionCode = newPromotionCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DISCOUNTS__PROMOTION_CODE, oldPromotionCode, promotionCode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order getOrder() {
		if (order != null && order.eIsProxy()) {
			InternalEObject oldOrder = (InternalEObject)order;
			order = (Order)eResolveProxy(oldOrder);
			if (order != oldOrder) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.DISCOUNTS__ORDER, oldOrder, order));
			}
		}
		return order;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order basicGetOrder() {
		return order;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOrder(Order newOrder, NotificationChain msgs) {
		Order oldOrder = order;
		order = newOrder;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.DISCOUNTS__ORDER, oldOrder, newOrder);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrder(Order newOrder) {
		if (newOrder != order) {
			NotificationChain msgs = null;
			if (order != null)
				msgs = ((InternalEObject)order).eInverseRemove(this, Test1Package.ORDER__DISCOUNTS, Order.class, msgs);
			if (newOrder != null)
				msgs = ((InternalEObject)newOrder).eInverseAdd(this, Test1Package.ORDER__DISCOUNTS, Order.class, msgs);
			msgs = basicSetOrder(newOrder, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.DISCOUNTS__ORDER, newOrder, newOrder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPromotionId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPromotionName() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPromotionCode() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.DISCOUNTS__ORDER:
				if (order != null)
					msgs = ((InternalEObject)order).eInverseRemove(this, Test1Package.ORDER__DISCOUNTS, Order.class, msgs);
				return basicSetOrder((Order)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.DISCOUNTS__ORDER:
				return basicSetOrder(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.DISCOUNTS__PROMOTION_ID:
				return getPromotionId();
			case Test1Package.DISCOUNTS__PROMOTION_NAME:
				return getPromotionName();
			case Test1Package.DISCOUNTS__PROMOTION_CODE:
				return getPromotionCode();
			case Test1Package.DISCOUNTS__ORDER:
				if (resolve) return getOrder();
				return basicGetOrder();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.DISCOUNTS__PROMOTION_ID:
				setPromotionId((String)newValue);
				return;
			case Test1Package.DISCOUNTS__PROMOTION_NAME:
				setPromotionName((String)newValue);
				return;
			case Test1Package.DISCOUNTS__PROMOTION_CODE:
				setPromotionCode((String)newValue);
				return;
			case Test1Package.DISCOUNTS__ORDER:
				setOrder((Order)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.DISCOUNTS__PROMOTION_ID:
				setPromotionId(PROMOTION_ID_EDEFAULT);
				return;
			case Test1Package.DISCOUNTS__PROMOTION_NAME:
				setPromotionName(PROMOTION_NAME_EDEFAULT);
				return;
			case Test1Package.DISCOUNTS__PROMOTION_CODE:
				setPromotionCode(PROMOTION_CODE_EDEFAULT);
				return;
			case Test1Package.DISCOUNTS__ORDER:
				setOrder((Order)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.DISCOUNTS__PROMOTION_ID:
				return PROMOTION_ID_EDEFAULT == null ? promotionId != null : !PROMOTION_ID_EDEFAULT.equals(promotionId);
			case Test1Package.DISCOUNTS__PROMOTION_NAME:
				return PROMOTION_NAME_EDEFAULT == null ? promotionName != null : !PROMOTION_NAME_EDEFAULT.equals(promotionName);
			case Test1Package.DISCOUNTS__PROMOTION_CODE:
				return PROMOTION_CODE_EDEFAULT == null ? promotionCode != null : !PROMOTION_CODE_EDEFAULT.equals(promotionCode);
			case Test1Package.DISCOUNTS__ORDER:
				return order != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.DISCOUNTS___SET_PROMOTION_ID:
				setPromotionId();
				return null;
			case Test1Package.DISCOUNTS___SET_PROMOTION_NAME:
				setPromotionName();
				return null;
			case Test1Package.DISCOUNTS___SET_PROMOTION_CODE:
				setPromotionCode();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (promotionId: ");
		result.append(promotionId);
		result.append(", promotionName: ");
		result.append(promotionName);
		result.append(", promotionCode: ");
		result.append(promotionCode);
		result.append(')');
		return result.toString();
	}

} //DiscountsImpl
