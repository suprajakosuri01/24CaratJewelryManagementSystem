/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;
import java.util.Map;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.emf.ecore.util.EObjectValidator;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.ParserException;

import org.eclipse.ocl.ecore.Constraint;
import org.eclipse.ocl.ecore.OCL;

import test1.Catalog;
import test1.OrderItems;
import test1.Product;
import test1.ProductCategory;
import test1.Test1Package;

import test1.util.Test1Validator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Product</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.ProductImpl#getProductId <em>Product Id</em>}</li>
 *   <li>{@link test1.impl.ProductImpl#getProductName <em>Product Name</em>}</li>
 *   <li>{@link test1.impl.ProductImpl#getProductDescripton <em>Product Descripton</em>}</li>
 *   <li>{@link test1.impl.ProductImpl#getCategoryId <em>Category Id</em>}</li>
 *   <li>{@link test1.impl.ProductImpl#getProductCategory <em>Product Category</em>}</li>
 *   <li>{@link test1.impl.ProductImpl#getOrderItemsId <em>Order Items Id</em>}</li>
 *   <li>{@link test1.impl.ProductImpl#getOrderItems <em>Order Items</em>}</li>
 *   <li>{@link test1.impl.ProductImpl#getCatalog <em>Catalog</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ProductImpl extends MinimalEObjectImpl.Container implements Product {
	/**
	 * The default value of the '{@link #getProductId() <em>Product Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductId()
	 * @generated
	 * @ordered
	 */
	protected static final String PRODUCT_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProductId() <em>Product Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductId()
	 * @generated
	 * @ordered
	 */
	protected String productId = PRODUCT_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getProductName() <em>Product Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductName()
	 * @generated
	 * @ordered
	 */
	protected static final String PRODUCT_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProductName() <em>Product Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductName()
	 * @generated
	 * @ordered
	 */
	protected String productName = PRODUCT_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getProductDescripton() <em>Product Descripton</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductDescripton()
	 * @generated
	 * @ordered
	 */
	protected static final String PRODUCT_DESCRIPTON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProductDescripton() <em>Product Descripton</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductDescripton()
	 * @generated
	 * @ordered
	 */
	protected String productDescripton = PRODUCT_DESCRIPTON_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCategoryId() <em>Category Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCategoryId()
	 * @generated
	 * @ordered
	 */
	protected ProductCategory categoryId;

	/**
	 * The cached value of the '{@link #getProductCategory() <em>Product Category</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductCategory()
	 * @generated
	 * @ordered
	 */
	protected EList<ProductCategory> productCategory;

	/**
	 * The cached value of the '{@link #getOrderItemsId() <em>Order Items Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderItemsId()
	 * @generated
	 * @ordered
	 */
	protected OrderItems orderItemsId;

	/**
	 * The cached value of the '{@link #getOrderItems() <em>Order Items</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderItems()
	 * @generated
	 * @ordered
	 */
	protected OrderItems orderItems;

	/**
	 * The cached value of the '{@link #getCatalog() <em>Catalog</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCatalog()
	 * @generated
	 * @ordered
	 */
	protected Catalog catalog;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProductImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.PRODUCT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductId(String newProductId) {
		String oldProductId = productId;
		productId = newProductId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__PRODUCT_ID, oldProductId, productId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductName(String newProductName) {
		String oldProductName = productName;
		productName = newProductName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__PRODUCT_NAME, oldProductName, productName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProductDescripton() {
		return productDescripton;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductDescripton(String newProductDescripton) {
		String oldProductDescripton = productDescripton;
		productDescripton = newProductDescripton;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__PRODUCT_DESCRIPTON, oldProductDescripton, productDescripton));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProductCategory getCategoryId() {
		if (categoryId != null && categoryId.eIsProxy()) {
			InternalEObject oldCategoryId = (InternalEObject)categoryId;
			categoryId = (ProductCategory)eResolveProxy(oldCategoryId);
			if (categoryId != oldCategoryId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.PRODUCT__CATEGORY_ID, oldCategoryId, categoryId));
			}
		}
		return categoryId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProductCategory basicGetCategoryId() {
		return categoryId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCategoryId(ProductCategory newCategoryId) {
		ProductCategory oldCategoryId = categoryId;
		categoryId = newCategoryId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__CATEGORY_ID, oldCategoryId, categoryId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ProductCategory> getProductCategory() {
		if (productCategory == null) {
			productCategory = new EObjectWithInverseResolvingEList<ProductCategory>(ProductCategory.class, this, Test1Package.PRODUCT__PRODUCT_CATEGORY, Test1Package.PRODUCT_CATEGORY__PRODUCT);
		}
		return productCategory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OrderItems getOrderItemsId() {
		if (orderItemsId != null && orderItemsId.eIsProxy()) {
			InternalEObject oldOrderItemsId = (InternalEObject)orderItemsId;
			orderItemsId = (OrderItems)eResolveProxy(oldOrderItemsId);
			if (orderItemsId != oldOrderItemsId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.PRODUCT__ORDER_ITEMS_ID, oldOrderItemsId, orderItemsId));
			}
		}
		return orderItemsId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OrderItems basicGetOrderItemsId() {
		return orderItemsId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderItemsId(OrderItems newOrderItemsId) {
		OrderItems oldOrderItemsId = orderItemsId;
		orderItemsId = newOrderItemsId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__ORDER_ITEMS_ID, oldOrderItemsId, orderItemsId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OrderItems getOrderItems() {
		return orderItems;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOrderItems(OrderItems newOrderItems, NotificationChain msgs) {
		OrderItems oldOrderItems = orderItems;
		orderItems = newOrderItems;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__ORDER_ITEMS, oldOrderItems, newOrderItems);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderItems(OrderItems newOrderItems) {
		if (newOrderItems != orderItems) {
			NotificationChain msgs = null;
			if (orderItems != null)
				msgs = ((InternalEObject)orderItems).eInverseRemove(this, Test1Package.ORDER_ITEMS__PRODUCT, OrderItems.class, msgs);
			if (newOrderItems != null)
				msgs = ((InternalEObject)newOrderItems).eInverseAdd(this, Test1Package.ORDER_ITEMS__PRODUCT, OrderItems.class, msgs);
			msgs = basicSetOrderItems(newOrderItems, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__ORDER_ITEMS, newOrderItems, newOrderItems));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Catalog getCatalog() {
		if (catalog != null && catalog.eIsProxy()) {
			InternalEObject oldCatalog = (InternalEObject)catalog;
			catalog = (Catalog)eResolveProxy(oldCatalog);
			if (catalog != oldCatalog) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.PRODUCT__CATALOG, oldCatalog, catalog));
			}
		}
		return catalog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Catalog basicGetCatalog() {
		return catalog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCatalog(Catalog newCatalog, NotificationChain msgs) {
		Catalog oldCatalog = catalog;
		catalog = newCatalog;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__CATALOG, oldCatalog, newCatalog);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCatalog(Catalog newCatalog) {
		if (newCatalog != catalog) {
			NotificationChain msgs = null;
			if (catalog != null)
				msgs = ((InternalEObject)catalog).eInverseRemove(this, Test1Package.CATALOG__PRODUCT, Catalog.class, msgs);
			if (newCatalog != null)
				msgs = ((InternalEObject)newCatalog).eInverseAdd(this, Test1Package.CATALOG__PRODUCT, Catalog.class, msgs);
			msgs = basicSetCatalog(newCatalog, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.PRODUCT__CATALOG, newCatalog, newCatalog));
	}

	/**
	 * The cached OCL expression body for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static final String CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP = "Each product id is unique";

	/**
	 * The cached OCL invariant for the '{@link #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' invariant operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 * @ordered
	 */
	protected static Constraint CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean constraint1(DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV == null) {
			OCL.Helper helper = EOCL_ENV.createOCLHelper();
			helper.setContext(Test1Package.Literals.PRODUCT);
			try {
				CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV = helper.createInvariant(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_EXP);
			}
			catch (ParserException pe) {
				throw new UnsupportedOperationException(pe.getLocalizedMessage());
			}
		}
		if (!EOCL_ENV.createQuery(CONSTRAINT1__DIAGNOSTIC_CHAIN_MAP__EOCL_INV).check(this)) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 Test1Validator.DIAGNOSTIC_SOURCE,
						 Test1Validator.PRODUCT__CONSTRAINT1,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "constraint1", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductName() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductDescription() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void getProductDescription() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.PRODUCT__PRODUCT_CATEGORY:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getProductCategory()).basicAdd(otherEnd, msgs);
			case Test1Package.PRODUCT__ORDER_ITEMS:
				if (orderItems != null)
					msgs = ((InternalEObject)orderItems).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Test1Package.PRODUCT__ORDER_ITEMS, null, msgs);
				return basicSetOrderItems((OrderItems)otherEnd, msgs);
			case Test1Package.PRODUCT__CATALOG:
				if (catalog != null)
					msgs = ((InternalEObject)catalog).eInverseRemove(this, Test1Package.CATALOG__PRODUCT, Catalog.class, msgs);
				return basicSetCatalog((Catalog)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.PRODUCT__PRODUCT_CATEGORY:
				return ((InternalEList<?>)getProductCategory()).basicRemove(otherEnd, msgs);
			case Test1Package.PRODUCT__ORDER_ITEMS:
				return basicSetOrderItems(null, msgs);
			case Test1Package.PRODUCT__CATALOG:
				return basicSetCatalog(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.PRODUCT__PRODUCT_ID:
				return getProductId();
			case Test1Package.PRODUCT__PRODUCT_NAME:
				return getProductName();
			case Test1Package.PRODUCT__PRODUCT_DESCRIPTON:
				return getProductDescripton();
			case Test1Package.PRODUCT__CATEGORY_ID:
				if (resolve) return getCategoryId();
				return basicGetCategoryId();
			case Test1Package.PRODUCT__PRODUCT_CATEGORY:
				return getProductCategory();
			case Test1Package.PRODUCT__ORDER_ITEMS_ID:
				if (resolve) return getOrderItemsId();
				return basicGetOrderItemsId();
			case Test1Package.PRODUCT__ORDER_ITEMS:
				return getOrderItems();
			case Test1Package.PRODUCT__CATALOG:
				if (resolve) return getCatalog();
				return basicGetCatalog();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.PRODUCT__PRODUCT_ID:
				setProductId((String)newValue);
				return;
			case Test1Package.PRODUCT__PRODUCT_NAME:
				setProductName((String)newValue);
				return;
			case Test1Package.PRODUCT__PRODUCT_DESCRIPTON:
				setProductDescripton((String)newValue);
				return;
			case Test1Package.PRODUCT__CATEGORY_ID:
				setCategoryId((ProductCategory)newValue);
				return;
			case Test1Package.PRODUCT__PRODUCT_CATEGORY:
				getProductCategory().clear();
				getProductCategory().addAll((Collection<? extends ProductCategory>)newValue);
				return;
			case Test1Package.PRODUCT__ORDER_ITEMS_ID:
				setOrderItemsId((OrderItems)newValue);
				return;
			case Test1Package.PRODUCT__ORDER_ITEMS:
				setOrderItems((OrderItems)newValue);
				return;
			case Test1Package.PRODUCT__CATALOG:
				setCatalog((Catalog)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.PRODUCT__PRODUCT_ID:
				setProductId(PRODUCT_ID_EDEFAULT);
				return;
			case Test1Package.PRODUCT__PRODUCT_NAME:
				setProductName(PRODUCT_NAME_EDEFAULT);
				return;
			case Test1Package.PRODUCT__PRODUCT_DESCRIPTON:
				setProductDescripton(PRODUCT_DESCRIPTON_EDEFAULT);
				return;
			case Test1Package.PRODUCT__CATEGORY_ID:
				setCategoryId((ProductCategory)null);
				return;
			case Test1Package.PRODUCT__PRODUCT_CATEGORY:
				getProductCategory().clear();
				return;
			case Test1Package.PRODUCT__ORDER_ITEMS_ID:
				setOrderItemsId((OrderItems)null);
				return;
			case Test1Package.PRODUCT__ORDER_ITEMS:
				setOrderItems((OrderItems)null);
				return;
			case Test1Package.PRODUCT__CATALOG:
				setCatalog((Catalog)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.PRODUCT__PRODUCT_ID:
				return PRODUCT_ID_EDEFAULT == null ? productId != null : !PRODUCT_ID_EDEFAULT.equals(productId);
			case Test1Package.PRODUCT__PRODUCT_NAME:
				return PRODUCT_NAME_EDEFAULT == null ? productName != null : !PRODUCT_NAME_EDEFAULT.equals(productName);
			case Test1Package.PRODUCT__PRODUCT_DESCRIPTON:
				return PRODUCT_DESCRIPTON_EDEFAULT == null ? productDescripton != null : !PRODUCT_DESCRIPTON_EDEFAULT.equals(productDescripton);
			case Test1Package.PRODUCT__CATEGORY_ID:
				return categoryId != null;
			case Test1Package.PRODUCT__PRODUCT_CATEGORY:
				return productCategory != null && !productCategory.isEmpty();
			case Test1Package.PRODUCT__ORDER_ITEMS_ID:
				return orderItemsId != null;
			case Test1Package.PRODUCT__ORDER_ITEMS:
				return orderItems != null;
			case Test1Package.PRODUCT__CATALOG:
				return catalog != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.PRODUCT___CONSTRAINT1__DIAGNOSTICCHAIN_MAP:
				return constraint1((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case Test1Package.PRODUCT___SET_PRODUCT_ID:
				setProductId();
				return null;
			case Test1Package.PRODUCT___SET_PRODUCT_NAME:
				setProductName();
				return null;
			case Test1Package.PRODUCT___SET_PRODUCT_DESCRIPTION:
				setProductDescription();
				return null;
			case Test1Package.PRODUCT___GET_PRODUCT_DESCRIPTION:
				getProductDescription();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (productId: ");
		result.append(productId);
		result.append(", productName: ");
		result.append(productName);
		result.append(", productDescripton: ");
		result.append(productDescripton);
		result.append(')');
		return result.toString();
	}

	/**
	 * The cached environment for evaluating OCL expressions.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected static final OCL EOCL_ENV = OCL.newInstance();

} //ProductImpl
