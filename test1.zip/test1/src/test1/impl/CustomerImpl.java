/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import test1.Customer;
import test1.Test1Package;
import test1.UserDetails;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.CustomerImpl#getCustomerId <em>Customer Id</em>}</li>
 *   <li>{@link test1.impl.CustomerImpl#getEmailId <em>Email Id</em>}</li>
 *   <li>{@link test1.impl.CustomerImpl#getContactNo <em>Contact No</em>}</li>
 *   <li>{@link test1.impl.CustomerImpl#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.impl.CustomerImpl#getUserDetails <em>User Details</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CustomerImpl extends PersonImpl implements Customer {
	/**
	 * The default value of the '{@link #getCustomerId() <em>Customer Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomerId()
	 * @generated
	 * @ordered
	 */
	protected static final String CUSTOMER_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCustomerId() <em>Customer Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomerId()
	 * @generated
	 * @ordered
	 */
	protected String customerId = CUSTOMER_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getEmailId() <em>Email Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmailId()
	 * @generated
	 * @ordered
	 */
	protected static final String EMAIL_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEmailId() <em>Email Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmailId()
	 * @generated
	 * @ordered
	 */
	protected String emailId = EMAIL_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getContactNo() <em>Contact No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContactNo()
	 * @generated
	 * @ordered
	 */
	protected static final int CONTACT_NO_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getContactNo() <em>Contact No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContactNo()
	 * @generated
	 * @ordered
	 */
	protected int contactNo = CONTACT_NO_EDEFAULT;

	/**
	 * The cached value of the '{@link #getUserId() <em>User Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserId()
	 * @generated
	 * @ordered
	 */
	protected UserDetails userId;

	/**
	 * The cached value of the '{@link #getUserDetails() <em>User Details</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserDetails()
	 * @generated
	 * @ordered
	 */
	protected UserDetails userDetails;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CustomerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.CUSTOMER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustomerId(String newCustomerId) {
		String oldCustomerId = customerId;
		customerId = newCustomerId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.CUSTOMER__CUSTOMER_ID, oldCustomerId, customerId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmailId(String newEmailId) {
		String oldEmailId = emailId;
		emailId = newEmailId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.CUSTOMER__EMAIL_ID, oldEmailId, emailId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getContactNo() {
		return contactNo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContactNo(int newContactNo) {
		int oldContactNo = contactNo;
		contactNo = newContactNo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.CUSTOMER__CONTACT_NO, oldContactNo, contactNo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails getUserId() {
		if (userId != null && userId.eIsProxy()) {
			InternalEObject oldUserId = (InternalEObject)userId;
			userId = (UserDetails)eResolveProxy(oldUserId);
			if (userId != oldUserId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.CUSTOMER__USER_ID, oldUserId, userId));
			}
		}
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails basicGetUserId() {
		return userId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserId(UserDetails newUserId) {
		UserDetails oldUserId = userId;
		userId = newUserId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.CUSTOMER__USER_ID, oldUserId, userId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails getUserDetails() {
		return userDetails;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetUserDetails(UserDetails newUserDetails, NotificationChain msgs) {
		UserDetails oldUserDetails = userDetails;
		userDetails = newUserDetails;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.CUSTOMER__USER_DETAILS, oldUserDetails, newUserDetails);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserDetails(UserDetails newUserDetails) {
		if (newUserDetails != userDetails) {
			NotificationChain msgs = null;
			if (userDetails != null)
				msgs = ((InternalEObject)userDetails).eInverseRemove(this, Test1Package.USER_DETAILS__CUSTOMER, UserDetails.class, msgs);
			if (newUserDetails != null)
				msgs = ((InternalEObject)newUserDetails).eInverseAdd(this, Test1Package.USER_DETAILS__CUSTOMER, UserDetails.class, msgs);
			msgs = basicSetUserDetails(newUserDetails, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.CUSTOMER__USER_DETAILS, newUserDetails, newUserDetails));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUserId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustomerId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmailId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContactNo() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.CUSTOMER__USER_DETAILS:
				if (userDetails != null)
					msgs = ((InternalEObject)userDetails).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Test1Package.CUSTOMER__USER_DETAILS, null, msgs);
				return basicSetUserDetails((UserDetails)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.CUSTOMER__USER_DETAILS:
				return basicSetUserDetails(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.CUSTOMER__CUSTOMER_ID:
				return getCustomerId();
			case Test1Package.CUSTOMER__EMAIL_ID:
				return getEmailId();
			case Test1Package.CUSTOMER__CONTACT_NO:
				return getContactNo();
			case Test1Package.CUSTOMER__USER_ID:
				if (resolve) return getUserId();
				return basicGetUserId();
			case Test1Package.CUSTOMER__USER_DETAILS:
				return getUserDetails();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.CUSTOMER__CUSTOMER_ID:
				setCustomerId((String)newValue);
				return;
			case Test1Package.CUSTOMER__EMAIL_ID:
				setEmailId((String)newValue);
				return;
			case Test1Package.CUSTOMER__CONTACT_NO:
				setContactNo((Integer)newValue);
				return;
			case Test1Package.CUSTOMER__USER_ID:
				setUserId((UserDetails)newValue);
				return;
			case Test1Package.CUSTOMER__USER_DETAILS:
				setUserDetails((UserDetails)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.CUSTOMER__CUSTOMER_ID:
				setCustomerId(CUSTOMER_ID_EDEFAULT);
				return;
			case Test1Package.CUSTOMER__EMAIL_ID:
				setEmailId(EMAIL_ID_EDEFAULT);
				return;
			case Test1Package.CUSTOMER__CONTACT_NO:
				setContactNo(CONTACT_NO_EDEFAULT);
				return;
			case Test1Package.CUSTOMER__USER_ID:
				setUserId((UserDetails)null);
				return;
			case Test1Package.CUSTOMER__USER_DETAILS:
				setUserDetails((UserDetails)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.CUSTOMER__CUSTOMER_ID:
				return CUSTOMER_ID_EDEFAULT == null ? customerId != null : !CUSTOMER_ID_EDEFAULT.equals(customerId);
			case Test1Package.CUSTOMER__EMAIL_ID:
				return EMAIL_ID_EDEFAULT == null ? emailId != null : !EMAIL_ID_EDEFAULT.equals(emailId);
			case Test1Package.CUSTOMER__CONTACT_NO:
				return contactNo != CONTACT_NO_EDEFAULT;
			case Test1Package.CUSTOMER__USER_ID:
				return userId != null;
			case Test1Package.CUSTOMER__USER_DETAILS:
				return userDetails != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.CUSTOMER___SET_USER_ID:
				setUserId();
				return null;
			case Test1Package.CUSTOMER___SET_CUSTOMER_ID:
				setCustomerId();
				return null;
			case Test1Package.CUSTOMER___SET_EMAIL_ID:
				setEmailId();
				return null;
			case Test1Package.CUSTOMER___SET_CONTACT_NO:
				setContactNo();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (customerId: ");
		result.append(customerId);
		result.append(", emailId: ");
		result.append(emailId);
		result.append(", contactNo: ");
		result.append(contactNo);
		result.append(')');
		return result.toString();
	}

} //CustomerImpl
