/**
 */
package test1.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EGenericType;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import test1.Address;
import test1.Card;
import test1.Catalog;
import test1.Customer;
import test1.Date;
import test1.DeliveryAgent;
import test1.Discounts;
import test1.Gender;
import test1.Location;
import test1.Order;
import test1.OrderFeedback;
import test1.OrderItems;
import test1.PaymentsInfo;
import test1.Person;
import test1.PrimitiveTypesDate;
import test1.Product;
import test1.ProductCategory;
import test1.Ratings;
import test1.Status;
import test1.Test1Factory;
import test1.Test1Package;
import test1.Transactions;
import test1.UserDetails;
import test1.Zipcode;
import test1.test1Date;

import test1.util.Test1Validator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Test1PackageImpl extends EPackageImpl implements Test1Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paymentsInfoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass userDetailsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deliveryAgentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass personEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass customerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass addressEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass locationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass zipcodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transactionsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass orderEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass statusEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass discountsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass catalogEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass productEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass productCategoryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass orderItemsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ratingsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass orderFeedbackEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass primitiveTypesDateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass test1DateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass test1DateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass test1DateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass test1DateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass test1DateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum genderEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see test1.Test1Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Test1PackageImpl() {
		super(eNS_URI, Test1Factory.eINSTANCE);
	}
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Test1Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Test1Package init() {
		if (isInited) return (Test1Package)EPackage.Registry.INSTANCE.getEPackage(Test1Package.eNS_URI);

		// Obtain or create and register package
		Object registeredTest1Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		Test1PackageImpl theTest1Package = registeredTest1Package instanceof Test1PackageImpl ? (Test1PackageImpl)registeredTest1Package : new Test1PackageImpl();

		isInited = true;

		// Create package meta-data objects
		theTest1Package.createPackageContents();

		// Initialize created meta-data
		theTest1Package.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theTest1Package,
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return Test1Validator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theTest1Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Test1Package.eNS_URI, theTest1Package);
		return theTest1Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCard() {
		return cardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCard_CardId() {
		return (EAttribute)cardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCard_CardType() {
		return (EAttribute)cardEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCard_PaymentsInfo() {
		return (EReference)cardEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCard__Constraint1__DiagnosticChain_Map() {
		return cardEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCard__SetCardId() {
		return cardEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCard__SetCardType() {
		return cardEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCard__GetCardId() {
		return cardEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCard__GetCardType() {
		return cardEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPaymentsInfo() {
		return paymentsInfoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentsInfo_PaymentId() {
		return (EAttribute)paymentsInfoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentsInfo_CardNo() {
		return (EAttribute)paymentsInfoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentsInfo_ExpiryDate() {
		return (EAttribute)paymentsInfoEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentsInfo_CardHolderName() {
		return (EAttribute)paymentsInfoEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentsInfo_Cvv() {
		return (EAttribute)paymentsInfoEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentsInfo_CardId() {
		return (EReference)paymentsInfoEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentsInfo_UserId() {
		return (EReference)paymentsInfoEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentsInfo_Transactions() {
		return (EReference)paymentsInfoEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentsInfo_Order() {
		return (EReference)paymentsInfoEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentsInfo_Card() {
		return (EReference)paymentsInfoEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPaymentsInfo__Constraint1__DiagnosticChain_Map() {
		return paymentsInfoEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPaymentsInfo__SetCardNo() {
		return paymentsInfoEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPaymentsInfo__SetExpiryDate() {
		return paymentsInfoEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPaymentsInfo__SetCardHolderName() {
		return paymentsInfoEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPaymentsInfo__SetCvv() {
		return paymentsInfoEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPaymentsInfo__GetCardNo() {
		return paymentsInfoEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPaymentsInfo__GetExpiryDate() {
		return paymentsInfoEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPaymentsInfo__GetCardHolderName() {
		return paymentsInfoEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUserDetails() {
		return userDetailsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUserDetails_UserId() {
		return (EAttribute)userDetailsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUserDetails_Username() {
		return (EAttribute)userDetailsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUserDetails_Password() {
		return (EAttribute)userDetailsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getUserDetails_DeliveryAgent() {
		return (EReference)userDetailsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getUserDetails_Customer() {
		return (EReference)userDetailsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getUserDetails_Address() {
		return (EReference)userDetailsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getUserDetails__Constraint1__DiagnosticChain_Map() {
		return userDetailsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getUserDetails__SetUserId() {
		return userDetailsEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getUserDetails__SetUsername() {
		return userDetailsEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getUserDetails__SetPassword() {
		return userDetailsEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getUserDetails__GetUserId() {
		return userDetailsEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getUserDetails__GetUsername() {
		return userDetailsEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDeliveryAgent() {
		return deliveryAgentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeliveryAgent_AgentId() {
		return (EAttribute)deliveryAgentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeliveryAgent_ContactNo() {
		return (EAttribute)deliveryAgentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeliveryAgent_Ssn() {
		return (EAttribute)deliveryAgentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeliveryAgent_DrivingLicenseNo() {
		return (EAttribute)deliveryAgentEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDeliveryAgent_UserId() {
		return (EReference)deliveryAgentEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDeliveryAgent_UserDetails() {
		return (EReference)deliveryAgentEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__Constraint1__DiagnosticChain_Map() {
		return deliveryAgentEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__SetAgentId() {
		return deliveryAgentEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__SetContactNo() {
		return deliveryAgentEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__SetSsn() {
		return deliveryAgentEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__SetDrivingLicenseNo() {
		return deliveryAgentEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__GetAgentId() {
		return deliveryAgentEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__GetContactNo() {
		return deliveryAgentEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__GetSsn() {
		return deliveryAgentEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeliveryAgent__GetDrivingLicenseNo() {
		return deliveryAgentEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPerson() {
		return personEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPerson_FirstName() {
		return (EAttribute)personEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPerson_LastName() {
		return (EAttribute)personEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPerson_Sex() {
		return (EAttribute)personEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPerson_DateOfBirth() {
		return (EReference)personEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPerson_Gender() {
		return (EAttribute)personEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPerson__SetFirstName() {
		return personEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPerson__SetLastName() {
		return personEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPerson__SetDateOfBirth() {
		return personEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPerson__GetFirstName() {
		return personEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPerson__GetLastName() {
		return personEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPerson__GetDateOfBirth() {
		return personEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDate() {
		return dateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCustomer() {
		return customerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCustomer_CustomerId() {
		return (EAttribute)customerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCustomer_EmailId() {
		return (EAttribute)customerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCustomer_ContactNo() {
		return (EAttribute)customerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCustomer_UserId() {
		return (EReference)customerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCustomer_UserDetails() {
		return (EReference)customerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCustomer__SetUserId() {
		return customerEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCustomer__SetCustomerId() {
		return customerEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCustomer__SetEmailId() {
		return customerEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCustomer__SetContactNo() {
		return customerEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCustomer__GetCustomerId() {
		return customerEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCustomer__GetEmailId() {
		return customerEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCustomer__GetContactNo() {
		return customerEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAddress() {
		return addressEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAddress_AddressType() {
		return (EAttribute)addressEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAddress_LocationId() {
		return (EReference)addressEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAddress_Location() {
		return (EReference)addressEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAddress_UserId() {
		return (EReference)addressEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAddress_UserDetails() {
		return (EReference)addressEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAddress__SetAddressType() {
		return addressEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAddress__GetAddressType() {
		return addressEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLocation() {
		return locationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLocation_LocationId() {
		return (EAttribute)locationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLocation_StreetName() {
		return (EAttribute)locationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLocation_HouseNo() {
		return (EAttribute)locationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getLocation_Zip() {
		return (EReference)locationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getLocation_Zipcode() {
		return (EReference)locationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getLocation_Address() {
		return (EReference)locationEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLocation__Constraint1__DiagnosticChain_Map() {
		return locationEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLocation__SetLocation() {
		return locationEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLocation__SetStreetName() {
		return locationEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLocation__SetHouseNo() {
		return locationEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLocation__GetLocationId() {
		return locationEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLocation__GetStreetName() {
		return locationEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLocation__GetHouseNo() {
		return locationEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getZipcode() {
		return zipcodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getZipcode_Zip() {
		return (EAttribute)zipcodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getZipcode_City() {
		return (EAttribute)zipcodeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getZipcode_State() {
		return (EAttribute)zipcodeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getZipcode_Country() {
		return (EAttribute)zipcodeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getZipcode_Location() {
		return (EReference)zipcodeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getZipcode__SetZip() {
		return zipcodeEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getZipcode__SetCity() {
		return zipcodeEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getZipcode__SetStatus() {
		return zipcodeEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getZipcode__SetCountry() {
		return zipcodeEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getZipcode__GetZip() {
		return zipcodeEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getZipcode__GetCity() {
		return zipcodeEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getZipcode__GetState() {
		return zipcodeEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getZipcode__GetCountry() {
		return zipcodeEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransactions() {
		return transactionsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransactions_TransactionId() {
		return (EAttribute)transactionsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransactions_TotalPrice() {
		return (EAttribute)transactionsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransactions_TransactionDate() {
		return (EReference)transactionsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransactions_TransactionStatus() {
		return (EAttribute)transactionsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransactions_OrderId() {
		return (EReference)transactionsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransactions_Status() {
		return (EReference)transactionsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransactions_Order() {
		return (EReference)transactionsEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransactions_PaymentId() {
		return (EReference)transactionsEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransactions_StatusId() {
		return (EReference)transactionsEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransactions_PaymentsInfo() {
		return (EReference)transactionsEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransactions__SetTotalPrice() {
		return transactionsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransactions__SetTransactionDate() {
		return transactionsEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransactions__SetTransactionStatus() {
		return transactionsEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransactions__GetTotalPrice() {
		return transactionsEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransactions__GetTransactionDate() {
		return transactionsEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransactions__GetTransactionStatus() {
		return transactionsEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOrder() {
		return orderEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrder_OrderId() {
		return (EAttribute)orderEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrder_OrderPrice() {
		return (EAttribute)orderEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrder_Instructions() {
		return (EAttribute)orderEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrder_DiscountedPrice() {
		return (EAttribute)orderEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrder_SourceLocationId() {
		return (EAttribute)orderEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrder_DestinationId() {
		return (EAttribute)orderEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrder_Tax() {
		return (EAttribute)orderEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrder_Delivery() {
		return (EAttribute)orderEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_StatusId() {
		return (EReference)orderEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_Status() {
		return (EReference)orderEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_AgentId() {
		return (EReference)orderEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_PaymentId() {
		return (EReference)orderEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_PromotionId() {
		return (EReference)orderEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_Discounts() {
		return (EReference)orderEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_CustomerId() {
		return (EReference)orderEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_Transactions() {
		return (EReference)orderEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_PaymentsInfo() {
		return (EReference)orderEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrder_Catalog() {
		return (EReference)orderEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__SetOrderId() {
		return orderEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__SetOrderPrice() {
		return orderEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__SetInstructions() {
		return orderEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__SetDiscountedPrice() {
		return orderEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__SetSourceLocationId() {
		return orderEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__SetTax() {
		return orderEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__SetDeliveryFee() {
		return orderEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__SetOderId() {
		return orderEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__GetTax() {
		return orderEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrder__GetDeliveryFee() {
		return orderEClass.getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStatus() {
		return statusEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStatus_StatusId() {
		return (EAttribute)statusEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStatus_StatusType() {
		return (EAttribute)statusEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStatus_Transactions() {
		return (EReference)statusEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStatus_Order() {
		return (EReference)statusEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStatus__Constraint1__DiagnosticChain_Map() {
		return statusEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStatus__SetStatusId() {
		return statusEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStatus__SetStatusType() {
		return statusEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStatus__GetStatusId() {
		return statusEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStatus__GetStatusType() {
		return statusEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDiscounts() {
		return discountsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiscounts_PromotionId() {
		return (EAttribute)discountsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiscounts_PromotionName() {
		return (EAttribute)discountsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiscounts_PromotionCode() {
		return (EAttribute)discountsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiscounts_Order() {
		return (EReference)discountsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDiscounts__SetPromotionId() {
		return discountsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDiscounts__SetPromotionName() {
		return discountsEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDiscounts__SetPromotionCode() {
		return discountsEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDiscounts__GetPromotionId() {
		return discountsEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDiscounts__GetPromotionName() {
		return discountsEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDiscounts__GetPromotionCode() {
		return discountsEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCatalog() {
		return catalogEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCatalog_Price() {
		return (EAttribute)catalogEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCatalog_ProductId() {
		return (EReference)catalogEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCatalog_Product() {
		return (EReference)catalogEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCatalog_Order() {
		return (EReference)catalogEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCatalog__Constraint1__DiagnosticChain_Map() {
		return catalogEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCatalog__SetPrice() {
		return catalogEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCatalog__GetPrice() {
		return catalogEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProduct() {
		return productEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProduct_ProductId() {
		return (EAttribute)productEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProduct_ProductName() {
		return (EAttribute)productEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProduct_ProductDescripton() {
		return (EAttribute)productEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProduct_CategoryId() {
		return (EReference)productEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProduct_ProductCategory() {
		return (EReference)productEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProduct_OrderItemsId() {
		return (EReference)productEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProduct_OrderItems() {
		return (EReference)productEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProduct_Catalog() {
		return (EReference)productEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProduct__Constraint1__DiagnosticChain_Map() {
		return productEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProduct__SetProductId() {
		return productEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProduct__SetProductName() {
		return productEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProduct__SetProductDescription() {
		return productEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProduct__GetProductId() {
		return productEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProduct__GetProductName() {
		return productEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProduct__GetProductDescription() {
		return productEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProductCategory() {
		return productCategoryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProductCategory_CategoryId() {
		return (EAttribute)productCategoryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProductCategory_CategoryName() {
		return (EAttribute)productCategoryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProductCategory_Product() {
		return (EReference)productCategoryEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProductCategory__Constraint1__DiagnosticChain_Map() {
		return productCategoryEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProductCategory__SetCategoryId() {
		return productCategoryEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProductCategory__SetCategoryName() {
		return productCategoryEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProductCategory__GetCategoryId() {
		return productCategoryEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProductCategory__GetcategoryName() {
		return productCategoryEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOrderItems() {
		return orderItemsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrderItems_OrderItemsId() {
		return (EAttribute)orderItemsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrderItems_ProductQuantity() {
		return (EAttribute)orderItemsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderItems_ProductId() {
		return (EReference)orderItemsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderItems_OrderId() {
		return (EReference)orderItemsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderItems_Product() {
		return (EReference)orderItemsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderItems__Constraint1__DiagnosticChain_Map() {
		return orderItemsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderItems__SetOrderItemsId() {
		return orderItemsEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderItems__SetProductQuantity() {
		return orderItemsEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderItems__GetOrderItemsId() {
		return orderItemsEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderItems__GetProductQuantity() {
		return orderItemsEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRatings() {
		return ratingsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRatings_RatingId() {
		return (EAttribute)ratingsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRatings_Rating() {
		return (EAttribute)ratingsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRatings_Orderfeedback() {
		return (EReference)ratingsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRatings__Constraint1__DiagnosticChain_Map() {
		return ratingsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRatings__SetRatingId() {
		return ratingsEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRatings__SetRating() {
		return ratingsEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRatings__GetRatingId() {
		return ratingsEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRatings__GetRating() {
		return ratingsEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOrderFeedback() {
		return orderFeedbackEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrderFeedback_ProductFeedback() {
		return (EAttribute)orderFeedbackEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrderFeedback_DeliveryAgentFeedback() {
		return (EAttribute)orderFeedbackEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOrderFeedback_ProductRatingId() {
		return (EAttribute)orderFeedbackEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderFeedback_DeliveryAgentRatingId() {
		return (EReference)orderFeedbackEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderFeedback_RatingId() {
		return (EReference)orderFeedbackEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderFeedback_OrderId() {
		return (EReference)orderFeedbackEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOrderFeedback_Ratings() {
		return (EReference)orderFeedbackEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderFeedback__SetProductFeedback() {
		return orderFeedbackEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderFeedback__SetDeliveryAgentFeedback() {
		return orderFeedbackEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderFeedback__SetProductRatingId() {
		return orderFeedbackEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderFeedback__SetDeliveryAgentRatingId() {
		return orderFeedbackEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderFeedback__GetProductFeedback() {
		return orderFeedbackEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderFeedback__GetDeliveryAgentFeedback() {
		return orderFeedbackEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderFeedback__GetProductRatingId() {
		return orderFeedbackEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOrderFeedback__GetDeliveryAgentRatingId() {
		return orderFeedbackEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPrimitiveTypesDate() {
		return primitiveTypesDateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass gettest1Date() {
		return test1DateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass gettest1Date() {
		return test1DateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass gettest1Date() {
		return test1DateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass gettest1Date() {
		return test1DateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass gettest1Date() {
		return test1DateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getGender() {
		return genderEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Test1Factory getTest1Factory() {
		return (Test1Factory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		cardEClass = createEClass(CARD);
		createEAttribute(cardEClass, CARD__CARD_ID);
		createEAttribute(cardEClass, CARD__CARD_TYPE);
		createEReference(cardEClass, CARD__PAYMENTS_INFO);
		createEOperation(cardEClass, CARD___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(cardEClass, CARD___SET_CARD_ID);
		createEOperation(cardEClass, CARD___SET_CARD_TYPE);
		createEOperation(cardEClass, CARD___GET_CARD_ID);
		createEOperation(cardEClass, CARD___GET_CARD_TYPE);

		paymentsInfoEClass = createEClass(PAYMENTS_INFO);
		createEAttribute(paymentsInfoEClass, PAYMENTS_INFO__PAYMENT_ID);
		createEAttribute(paymentsInfoEClass, PAYMENTS_INFO__CARD_NO);
		createEAttribute(paymentsInfoEClass, PAYMENTS_INFO__EXPIRY_DATE);
		createEAttribute(paymentsInfoEClass, PAYMENTS_INFO__CARD_HOLDER_NAME);
		createEAttribute(paymentsInfoEClass, PAYMENTS_INFO__CVV);
		createEReference(paymentsInfoEClass, PAYMENTS_INFO__CARD_ID);
		createEReference(paymentsInfoEClass, PAYMENTS_INFO__USER_ID);
		createEReference(paymentsInfoEClass, PAYMENTS_INFO__TRANSACTIONS);
		createEReference(paymentsInfoEClass, PAYMENTS_INFO__ORDER);
		createEReference(paymentsInfoEClass, PAYMENTS_INFO__CARD);
		createEOperation(paymentsInfoEClass, PAYMENTS_INFO___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(paymentsInfoEClass, PAYMENTS_INFO___SET_CARD_NO);
		createEOperation(paymentsInfoEClass, PAYMENTS_INFO___SET_EXPIRY_DATE);
		createEOperation(paymentsInfoEClass, PAYMENTS_INFO___SET_CARD_HOLDER_NAME);
		createEOperation(paymentsInfoEClass, PAYMENTS_INFO___SET_CVV);
		createEOperation(paymentsInfoEClass, PAYMENTS_INFO___GET_CARD_NO);
		createEOperation(paymentsInfoEClass, PAYMENTS_INFO___GET_EXPIRY_DATE);
		createEOperation(paymentsInfoEClass, PAYMENTS_INFO___GET_CARD_HOLDER_NAME);

		userDetailsEClass = createEClass(USER_DETAILS);
		createEAttribute(userDetailsEClass, USER_DETAILS__USER_ID);
		createEAttribute(userDetailsEClass, USER_DETAILS__USERNAME);
		createEAttribute(userDetailsEClass, USER_DETAILS__PASSWORD);
		createEReference(userDetailsEClass, USER_DETAILS__DELIVERY_AGENT);
		createEReference(userDetailsEClass, USER_DETAILS__CUSTOMER);
		createEReference(userDetailsEClass, USER_DETAILS__ADDRESS);
		createEOperation(userDetailsEClass, USER_DETAILS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(userDetailsEClass, USER_DETAILS___SET_USER_ID);
		createEOperation(userDetailsEClass, USER_DETAILS___SET_USERNAME);
		createEOperation(userDetailsEClass, USER_DETAILS___SET_PASSWORD);
		createEOperation(userDetailsEClass, USER_DETAILS___GET_USER_ID);
		createEOperation(userDetailsEClass, USER_DETAILS___GET_USERNAME);

		deliveryAgentEClass = createEClass(DELIVERY_AGENT);
		createEAttribute(deliveryAgentEClass, DELIVERY_AGENT__AGENT_ID);
		createEAttribute(deliveryAgentEClass, DELIVERY_AGENT__CONTACT_NO);
		createEAttribute(deliveryAgentEClass, DELIVERY_AGENT__SSN);
		createEAttribute(deliveryAgentEClass, DELIVERY_AGENT__DRIVING_LICENSE_NO);
		createEReference(deliveryAgentEClass, DELIVERY_AGENT__USER_ID);
		createEReference(deliveryAgentEClass, DELIVERY_AGENT__USER_DETAILS);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___SET_AGENT_ID);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___SET_CONTACT_NO);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___SET_SSN);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___SET_DRIVING_LICENSE_NO);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___GET_AGENT_ID);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___GET_CONTACT_NO);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___GET_SSN);
		createEOperation(deliveryAgentEClass, DELIVERY_AGENT___GET_DRIVING_LICENSE_NO);

		personEClass = createEClass(PERSON);
		createEAttribute(personEClass, PERSON__FIRST_NAME);
		createEAttribute(personEClass, PERSON__LAST_NAME);
		createEAttribute(personEClass, PERSON__SEX);
		createEReference(personEClass, PERSON__DATE_OF_BIRTH);
		createEAttribute(personEClass, PERSON__GENDER);
		createEOperation(personEClass, PERSON___SET_FIRST_NAME);
		createEOperation(personEClass, PERSON___SET_LAST_NAME);
		createEOperation(personEClass, PERSON___SET_DATE_OF_BIRTH);
		createEOperation(personEClass, PERSON___GET_FIRST_NAME);
		createEOperation(personEClass, PERSON___GET_LAST_NAME);
		createEOperation(personEClass, PERSON___GET_DATE_OF_BIRTH);

		dateEClass = createEClass(DATE);

		customerEClass = createEClass(CUSTOMER);
		createEAttribute(customerEClass, CUSTOMER__CUSTOMER_ID);
		createEAttribute(customerEClass, CUSTOMER__EMAIL_ID);
		createEAttribute(customerEClass, CUSTOMER__CONTACT_NO);
		createEReference(customerEClass, CUSTOMER__USER_ID);
		createEReference(customerEClass, CUSTOMER__USER_DETAILS);
		createEOperation(customerEClass, CUSTOMER___SET_USER_ID);
		createEOperation(customerEClass, CUSTOMER___SET_CUSTOMER_ID);
		createEOperation(customerEClass, CUSTOMER___SET_EMAIL_ID);
		createEOperation(customerEClass, CUSTOMER___SET_CONTACT_NO);
		createEOperation(customerEClass, CUSTOMER___GET_CUSTOMER_ID);
		createEOperation(customerEClass, CUSTOMER___GET_EMAIL_ID);
		createEOperation(customerEClass, CUSTOMER___GET_CONTACT_NO);

		addressEClass = createEClass(ADDRESS);
		createEAttribute(addressEClass, ADDRESS__ADDRESS_TYPE);
		createEReference(addressEClass, ADDRESS__LOCATION_ID);
		createEReference(addressEClass, ADDRESS__LOCATION);
		createEReference(addressEClass, ADDRESS__USER_ID);
		createEReference(addressEClass, ADDRESS__USER_DETAILS);
		createEOperation(addressEClass, ADDRESS___SET_ADDRESS_TYPE);
		createEOperation(addressEClass, ADDRESS___GET_ADDRESS_TYPE);

		locationEClass = createEClass(LOCATION);
		createEAttribute(locationEClass, LOCATION__LOCATION_ID);
		createEAttribute(locationEClass, LOCATION__STREET_NAME);
		createEAttribute(locationEClass, LOCATION__HOUSE_NO);
		createEReference(locationEClass, LOCATION__ZIP);
		createEReference(locationEClass, LOCATION__ZIPCODE);
		createEReference(locationEClass, LOCATION__ADDRESS);
		createEOperation(locationEClass, LOCATION___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(locationEClass, LOCATION___SET_LOCATION);
		createEOperation(locationEClass, LOCATION___SET_STREET_NAME);
		createEOperation(locationEClass, LOCATION___SET_HOUSE_NO);
		createEOperation(locationEClass, LOCATION___GET_LOCATION_ID);
		createEOperation(locationEClass, LOCATION___GET_STREET_NAME);
		createEOperation(locationEClass, LOCATION___GET_HOUSE_NO);

		zipcodeEClass = createEClass(ZIPCODE);
		createEAttribute(zipcodeEClass, ZIPCODE__ZIP);
		createEAttribute(zipcodeEClass, ZIPCODE__CITY);
		createEAttribute(zipcodeEClass, ZIPCODE__STATE);
		createEAttribute(zipcodeEClass, ZIPCODE__COUNTRY);
		createEReference(zipcodeEClass, ZIPCODE__LOCATION);
		createEOperation(zipcodeEClass, ZIPCODE___SET_ZIP);
		createEOperation(zipcodeEClass, ZIPCODE___SET_CITY);
		createEOperation(zipcodeEClass, ZIPCODE___SET_STATUS);
		createEOperation(zipcodeEClass, ZIPCODE___SET_COUNTRY);
		createEOperation(zipcodeEClass, ZIPCODE___GET_ZIP);
		createEOperation(zipcodeEClass, ZIPCODE___GET_CITY);
		createEOperation(zipcodeEClass, ZIPCODE___GET_STATE);
		createEOperation(zipcodeEClass, ZIPCODE___GET_COUNTRY);

		transactionsEClass = createEClass(TRANSACTIONS);
		createEAttribute(transactionsEClass, TRANSACTIONS__TRANSACTION_ID);
		createEAttribute(transactionsEClass, TRANSACTIONS__TOTAL_PRICE);
		createEReference(transactionsEClass, TRANSACTIONS__TRANSACTION_DATE);
		createEAttribute(transactionsEClass, TRANSACTIONS__TRANSACTION_STATUS);
		createEReference(transactionsEClass, TRANSACTIONS__ORDER_ID);
		createEReference(transactionsEClass, TRANSACTIONS__STATUS);
		createEReference(transactionsEClass, TRANSACTIONS__ORDER);
		createEReference(transactionsEClass, TRANSACTIONS__PAYMENT_ID);
		createEReference(transactionsEClass, TRANSACTIONS__STATUS_ID);
		createEReference(transactionsEClass, TRANSACTIONS__PAYMENTS_INFO);
		createEOperation(transactionsEClass, TRANSACTIONS___SET_TOTAL_PRICE);
		createEOperation(transactionsEClass, TRANSACTIONS___SET_TRANSACTION_DATE);
		createEOperation(transactionsEClass, TRANSACTIONS___SET_TRANSACTION_STATUS);
		createEOperation(transactionsEClass, TRANSACTIONS___GET_TOTAL_PRICE);
		createEOperation(transactionsEClass, TRANSACTIONS___GET_TRANSACTION_DATE);
		createEOperation(transactionsEClass, TRANSACTIONS___GET_TRANSACTION_STATUS);

		orderEClass = createEClass(ORDER);
		createEAttribute(orderEClass, ORDER__ORDER_ID);
		createEAttribute(orderEClass, ORDER__ORDER_PRICE);
		createEAttribute(orderEClass, ORDER__INSTRUCTIONS);
		createEAttribute(orderEClass, ORDER__DISCOUNTED_PRICE);
		createEAttribute(orderEClass, ORDER__SOURCE_LOCATION_ID);
		createEAttribute(orderEClass, ORDER__DESTINATION_ID);
		createEAttribute(orderEClass, ORDER__TAX);
		createEAttribute(orderEClass, ORDER__DELIVERY);
		createEReference(orderEClass, ORDER__STATUS_ID);
		createEReference(orderEClass, ORDER__STATUS);
		createEReference(orderEClass, ORDER__AGENT_ID);
		createEReference(orderEClass, ORDER__PAYMENT_ID);
		createEReference(orderEClass, ORDER__PROMOTION_ID);
		createEReference(orderEClass, ORDER__DISCOUNTS);
		createEReference(orderEClass, ORDER__CUSTOMER_ID);
		createEReference(orderEClass, ORDER__TRANSACTIONS);
		createEReference(orderEClass, ORDER__PAYMENTS_INFO);
		createEReference(orderEClass, ORDER__CATALOG);
		createEOperation(orderEClass, ORDER___SET_ORDER_ID);
		createEOperation(orderEClass, ORDER___SET_ORDER_PRICE);
		createEOperation(orderEClass, ORDER___SET_INSTRUCTIONS);
		createEOperation(orderEClass, ORDER___SET_DISCOUNTED_PRICE);
		createEOperation(orderEClass, ORDER___SET_SOURCE_LOCATION_ID);
		createEOperation(orderEClass, ORDER___SET_TAX);
		createEOperation(orderEClass, ORDER___SET_DELIVERY_FEE);
		createEOperation(orderEClass, ORDER___SET_ODER_ID);
		createEOperation(orderEClass, ORDER___GET_TAX);
		createEOperation(orderEClass, ORDER___GET_DELIVERY_FEE);

		statusEClass = createEClass(STATUS);
		createEAttribute(statusEClass, STATUS__STATUS_ID);
		createEAttribute(statusEClass, STATUS__STATUS_TYPE);
		createEReference(statusEClass, STATUS__TRANSACTIONS);
		createEReference(statusEClass, STATUS__ORDER);
		createEOperation(statusEClass, STATUS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(statusEClass, STATUS___SET_STATUS_ID);
		createEOperation(statusEClass, STATUS___SET_STATUS_TYPE);
		createEOperation(statusEClass, STATUS___GET_STATUS_ID);
		createEOperation(statusEClass, STATUS___GET_STATUS_TYPE);

		discountsEClass = createEClass(DISCOUNTS);
		createEAttribute(discountsEClass, DISCOUNTS__PROMOTION_ID);
		createEAttribute(discountsEClass, DISCOUNTS__PROMOTION_NAME);
		createEAttribute(discountsEClass, DISCOUNTS__PROMOTION_CODE);
		createEReference(discountsEClass, DISCOUNTS__ORDER);
		createEOperation(discountsEClass, DISCOUNTS___SET_PROMOTION_ID);
		createEOperation(discountsEClass, DISCOUNTS___SET_PROMOTION_NAME);
		createEOperation(discountsEClass, DISCOUNTS___SET_PROMOTION_CODE);
		createEOperation(discountsEClass, DISCOUNTS___GET_PROMOTION_ID);
		createEOperation(discountsEClass, DISCOUNTS___GET_PROMOTION_NAME);
		createEOperation(discountsEClass, DISCOUNTS___GET_PROMOTION_CODE);

		catalogEClass = createEClass(CATALOG);
		createEAttribute(catalogEClass, CATALOG__PRICE);
		createEReference(catalogEClass, CATALOG__PRODUCT_ID);
		createEReference(catalogEClass, CATALOG__PRODUCT);
		createEReference(catalogEClass, CATALOG__ORDER);
		createEOperation(catalogEClass, CATALOG___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(catalogEClass, CATALOG___SET_PRICE);
		createEOperation(catalogEClass, CATALOG___GET_PRICE);

		productEClass = createEClass(PRODUCT);
		createEAttribute(productEClass, PRODUCT__PRODUCT_ID);
		createEAttribute(productEClass, PRODUCT__PRODUCT_NAME);
		createEAttribute(productEClass, PRODUCT__PRODUCT_DESCRIPTON);
		createEReference(productEClass, PRODUCT__CATEGORY_ID);
		createEReference(productEClass, PRODUCT__PRODUCT_CATEGORY);
		createEReference(productEClass, PRODUCT__ORDER_ITEMS_ID);
		createEReference(productEClass, PRODUCT__ORDER_ITEMS);
		createEReference(productEClass, PRODUCT__CATALOG);
		createEOperation(productEClass, PRODUCT___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(productEClass, PRODUCT___SET_PRODUCT_ID);
		createEOperation(productEClass, PRODUCT___SET_PRODUCT_NAME);
		createEOperation(productEClass, PRODUCT___SET_PRODUCT_DESCRIPTION);
		createEOperation(productEClass, PRODUCT___GET_PRODUCT_ID);
		createEOperation(productEClass, PRODUCT___GET_PRODUCT_NAME);
		createEOperation(productEClass, PRODUCT___GET_PRODUCT_DESCRIPTION);

		productCategoryEClass = createEClass(PRODUCT_CATEGORY);
		createEAttribute(productCategoryEClass, PRODUCT_CATEGORY__CATEGORY_ID);
		createEAttribute(productCategoryEClass, PRODUCT_CATEGORY__CATEGORY_NAME);
		createEReference(productCategoryEClass, PRODUCT_CATEGORY__PRODUCT);
		createEOperation(productCategoryEClass, PRODUCT_CATEGORY___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(productCategoryEClass, PRODUCT_CATEGORY___SET_CATEGORY_ID);
		createEOperation(productCategoryEClass, PRODUCT_CATEGORY___SET_CATEGORY_NAME);
		createEOperation(productCategoryEClass, PRODUCT_CATEGORY___GET_CATEGORY_ID);
		createEOperation(productCategoryEClass, PRODUCT_CATEGORY___GETCATEGORY_NAME);

		orderItemsEClass = createEClass(ORDER_ITEMS);
		createEAttribute(orderItemsEClass, ORDER_ITEMS__ORDER_ITEMS_ID);
		createEAttribute(orderItemsEClass, ORDER_ITEMS__PRODUCT_QUANTITY);
		createEReference(orderItemsEClass, ORDER_ITEMS__PRODUCT_ID);
		createEReference(orderItemsEClass, ORDER_ITEMS__ORDER_ID);
		createEReference(orderItemsEClass, ORDER_ITEMS__PRODUCT);
		createEOperation(orderItemsEClass, ORDER_ITEMS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(orderItemsEClass, ORDER_ITEMS___SET_ORDER_ITEMS_ID);
		createEOperation(orderItemsEClass, ORDER_ITEMS___SET_PRODUCT_QUANTITY);
		createEOperation(orderItemsEClass, ORDER_ITEMS___GET_ORDER_ITEMS_ID);
		createEOperation(orderItemsEClass, ORDER_ITEMS___GET_PRODUCT_QUANTITY);

		ratingsEClass = createEClass(RATINGS);
		createEAttribute(ratingsEClass, RATINGS__RATING_ID);
		createEAttribute(ratingsEClass, RATINGS__RATING);
		createEReference(ratingsEClass, RATINGS__ORDERFEEDBACK);
		createEOperation(ratingsEClass, RATINGS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP);
		createEOperation(ratingsEClass, RATINGS___SET_RATING_ID);
		createEOperation(ratingsEClass, RATINGS___SET_RATING);
		createEOperation(ratingsEClass, RATINGS___GET_RATING_ID);
		createEOperation(ratingsEClass, RATINGS___GET_RATING);

		orderFeedbackEClass = createEClass(ORDER_FEEDBACK);
		createEAttribute(orderFeedbackEClass, ORDER_FEEDBACK__PRODUCT_FEEDBACK);
		createEAttribute(orderFeedbackEClass, ORDER_FEEDBACK__DELIVERY_AGENT_FEEDBACK);
		createEAttribute(orderFeedbackEClass, ORDER_FEEDBACK__PRODUCT_RATING_ID);
		createEReference(orderFeedbackEClass, ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID);
		createEReference(orderFeedbackEClass, ORDER_FEEDBACK__RATING_ID);
		createEReference(orderFeedbackEClass, ORDER_FEEDBACK__ORDER_ID);
		createEReference(orderFeedbackEClass, ORDER_FEEDBACK__RATINGS);
		createEOperation(orderFeedbackEClass, ORDER_FEEDBACK___SET_PRODUCT_FEEDBACK);
		createEOperation(orderFeedbackEClass, ORDER_FEEDBACK___SET_DELIVERY_AGENT_FEEDBACK);
		createEOperation(orderFeedbackEClass, ORDER_FEEDBACK___SET_PRODUCT_RATING_ID);
		createEOperation(orderFeedbackEClass, ORDER_FEEDBACK___SET_DELIVERY_AGENT_RATING_ID);
		createEOperation(orderFeedbackEClass, ORDER_FEEDBACK___GET_PRODUCT_FEEDBACK);
		createEOperation(orderFeedbackEClass, ORDER_FEEDBACK___GET_DELIVERY_AGENT_FEEDBACK);
		createEOperation(orderFeedbackEClass, ORDER_FEEDBACK___GET_PRODUCT_RATING_ID);
		createEOperation(orderFeedbackEClass, ORDER_FEEDBACK___GET_DELIVERY_AGENT_RATING_ID);

		primitiveTypesDateEClass = createEClass(PRIMITIVE_TYPES_DATE);

		test1DateEClass = createEClass(TEST1_DATE);

		test1DateEClass = createEClass(TEST1_DATE);

		// Create enums
		genderEEnum = createEEnum(GENDER);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		deliveryAgentEClass.getESuperTypes().add(this.getPerson());
		customerEClass.getESuperTypes().add(this.getPerson());

		// Initialize classes, features, and operations; add parameters
		initEClass(cardEClass, Card.class, "Card", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCard_CardId(), ecorePackage.getEString(), "cardId", null, 1, 1, Card.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getCard_CardType(), ecorePackage.getEString(), "cardType", null, 1, 1, Card.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCard_PaymentsInfo(), this.getPaymentsInfo(), this.getPaymentsInfo_Card(), "paymentsInfo", null, 1, -1, Card.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		EOperation op = initEOperation(getCard__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		EGenericType g1 = createEGenericType(ecorePackage.getEMap());
		EGenericType g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCard__SetCardId(), null, "setCardId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCard__SetCardType(), null, "setCardType", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCard__GetCardId(), null, "getCardId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCard__GetCardType(), null, "getCardType", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(paymentsInfoEClass, PaymentsInfo.class, "PaymentsInfo", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPaymentsInfo_PaymentId(), ecorePackage.getEString(), "paymentId", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPaymentsInfo_CardNo(), ecorePackage.getEInt(), "cardNo", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPaymentsInfo_ExpiryDate(), ecorePackage.getEString(), "expiryDate", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPaymentsInfo_CardHolderName(), ecorePackage.getEString(), "cardHolderName", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPaymentsInfo_Cvv(), ecorePackage.getEInt(), "cvv", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPaymentsInfo_CardId(), this.getCard(), null, "cardId", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPaymentsInfo_UserId(), this.getUserDetails(), null, "userId", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPaymentsInfo_Transactions(), this.getTransactions(), this.getTransactions_PaymentsInfo(), "transactions", null, 1, -1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPaymentsInfo_Order(), this.getOrder(), this.getOrder_PaymentsInfo(), "order", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPaymentsInfo_Card(), this.getCard(), this.getCard_PaymentsInfo(), "card", null, 1, 1, PaymentsInfo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getPaymentsInfo__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPaymentsInfo__SetCardNo(), null, "setCardNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPaymentsInfo__SetExpiryDate(), null, "setExpiryDate", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPaymentsInfo__SetCardHolderName(), null, "setCardHolderName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPaymentsInfo__SetCvv(), null, "setCvv", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPaymentsInfo__GetCardNo(), null, "getCardNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPaymentsInfo__GetExpiryDate(), null, "getExpiryDate", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPaymentsInfo__GetCardHolderName(), null, "getCardHolderName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(userDetailsEClass, UserDetails.class, "UserDetails", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getUserDetails_UserId(), ecorePackage.getEString(), "userId", null, 1, 1, UserDetails.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getUserDetails_Username(), ecorePackage.getEString(), "username", null, 1, 1, UserDetails.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getUserDetails_Password(), ecorePackage.getEString(), "password", null, 1, 1, UserDetails.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getUserDetails_DeliveryAgent(), this.getDeliveryAgent(), this.getDeliveryAgent_UserDetails(), "deliveryAgent", null, 1, 1, UserDetails.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getUserDetails_Customer(), this.getCustomer(), this.getCustomer_UserDetails(), "customer", null, 1, 1, UserDetails.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getUserDetails_Address(), this.getAddress(), this.getAddress_UserDetails(), "address", null, 1, -1, UserDetails.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getUserDetails__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getUserDetails__SetUserId(), null, "setUserId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getUserDetails__SetUsername(), null, "setUsername", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getUserDetails__SetPassword(), null, "setPassword", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getUserDetails__GetUserId(), null, "getUserId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getUserDetails__GetUsername(), null, "getUsername", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(deliveryAgentEClass, DeliveryAgent.class, "DeliveryAgent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDeliveryAgent_AgentId(), ecorePackage.getEString(), "agentId", null, 1, 1, DeliveryAgent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDeliveryAgent_ContactNo(), ecorePackage.getEInt(), "contactNo", null, 1, 1, DeliveryAgent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDeliveryAgent_Ssn(), ecorePackage.getEInt(), "ssn", null, 1, 1, DeliveryAgent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDeliveryAgent_DrivingLicenseNo(), ecorePackage.getEString(), "drivingLicenseNo", null, 1, 1, DeliveryAgent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getDeliveryAgent_UserId(), this.getUserDetails(), null, "userId", null, 1, 1, DeliveryAgent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getDeliveryAgent_UserDetails(), this.getUserDetails(), this.getUserDetails_DeliveryAgent(), "userDetails", null, 1, 1, DeliveryAgent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getDeliveryAgent__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getDeliveryAgent__SetAgentId(), null, "setAgentId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeliveryAgent__SetContactNo(), null, "setContactNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeliveryAgent__SetSsn(), null, "setSsn", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeliveryAgent__SetDrivingLicenseNo(), null, "setDrivingLicenseNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeliveryAgent__GetAgentId(), null, "getAgentId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeliveryAgent__GetContactNo(), null, "getContactNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeliveryAgent__GetSsn(), null, "getSsn", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeliveryAgent__GetDrivingLicenseNo(), null, "getDrivingLicenseNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(personEClass, Person.class, "Person", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPerson_FirstName(), ecorePackage.getEString(), "firstName", null, 1, 1, Person.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPerson_LastName(), ecorePackage.getEString(), "lastName", null, 1, 1, Person.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPerson_Sex(), this.getGender(), "sex", null, 1, 1, Person.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getPerson_DateOfBirth(), this.getDate(), null, "dateOfBirth", null, 1, 1, Person.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPerson_Gender(), this.getGender(), "gender", null, 1, 1, Person.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getPerson__SetFirstName(), null, "setFirstName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPerson__SetLastName(), null, "setLastName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPerson__SetDateOfBirth(), null, "setDateOfBirth", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPerson__GetFirstName(), null, "getFirstName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPerson__GetLastName(), null, "getLastName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPerson__GetDateOfBirth(), null, "getDateOfBirth", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(dateEClass, Date.class, "Date", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(customerEClass, Customer.class, "Customer", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCustomer_CustomerId(), ecorePackage.getEString(), "customerId", null, 1, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getCustomer_EmailId(), ecorePackage.getEString(), "emailId", null, 1, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getCustomer_ContactNo(), ecorePackage.getEInt(), "contactNo", null, 1, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCustomer_UserId(), this.getUserDetails(), null, "userId", null, 1, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCustomer_UserDetails(), this.getUserDetails(), this.getUserDetails_Customer(), "userDetails", null, 1, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getCustomer__SetUserId(), null, "setUserId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCustomer__SetCustomerId(), null, "setCustomerId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCustomer__SetEmailId(), null, "setEmailId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCustomer__SetContactNo(), null, "setContactNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCustomer__GetCustomerId(), null, "getCustomerId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCustomer__GetEmailId(), null, "getEmailId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCustomer__GetContactNo(), null, "getContactNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(addressEClass, Address.class, "Address", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAddress_AddressType(), ecorePackage.getEString(), "addressType", null, 1, 1, Address.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAddress_LocationId(), this.getLocation(), null, "locationId", null, 1, 1, Address.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAddress_Location(), this.getLocation(), this.getLocation_Address(), "location", null, 1, 1, Address.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAddress_UserId(), this.getUserDetails(), null, "userId", null, 1, 1, Address.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getAddress_UserDetails(), this.getUserDetails(), this.getUserDetails_Address(), "userDetails", null, 1, 1, Address.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getAddress__SetAddressType(), null, "setAddressType", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAddress__GetAddressType(), null, "getAddressType", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(locationEClass, Location.class, "Location", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLocation_LocationId(), ecorePackage.getEString(), "locationId", null, 1, 1, Location.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getLocation_StreetName(), ecorePackage.getEString(), "streetName", null, 1, 1, Location.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getLocation_HouseNo(), ecorePackage.getEString(), "houseNo", null, 1, 1, Location.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getLocation_Zip(), this.getZipcode(), null, "zip", null, 1, 1, Location.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getLocation_Zipcode(), this.getZipcode(), this.getZipcode_Location(), "zipcode", null, 1, 1, Location.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getLocation_Address(), this.getAddress(), this.getAddress_Location(), "address", null, 1, -1, Location.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getLocation__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getLocation__SetLocation(), null, "setLocation", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getLocation__SetStreetName(), null, "setStreetName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getLocation__SetHouseNo(), null, "setHouseNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getLocation__GetLocationId(), null, "getLocationId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getLocation__GetStreetName(), null, "getStreetName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getLocation__GetHouseNo(), null, "getHouseNo", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(zipcodeEClass, Zipcode.class, "Zipcode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getZipcode_Zip(), ecorePackage.getEInt(), "zip", null, 1, 1, Zipcode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getZipcode_City(), ecorePackage.getEString(), "city", null, 1, 1, Zipcode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getZipcode_State(), ecorePackage.getEString(), "state", null, 1, 1, Zipcode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getZipcode_Country(), ecorePackage.getEString(), "country", null, 1, 1, Zipcode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getZipcode_Location(), this.getLocation(), this.getLocation_Zipcode(), "location", null, 1, -1, Zipcode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getZipcode__SetZip(), null, "setZip", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getZipcode__SetCity(), null, "setCity", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getZipcode__SetStatus(), null, "setStatus", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getZipcode__SetCountry(), null, "setCountry", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getZipcode__GetZip(), null, "getZip", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getZipcode__GetCity(), null, "getCity", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getZipcode__GetState(), null, "getState", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getZipcode__GetCountry(), null, "getCountry", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(transactionsEClass, Transactions.class, "Transactions", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTransactions_TransactionId(), ecorePackage.getEString(), "transactionId", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getTransactions_TotalPrice(), ecorePackage.getEFloat(), "totalPrice", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getTransactions_TransactionDate(), this.getDate(), null, "transactionDate", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getTransactions_TransactionStatus(), ecorePackage.getEString(), "transactionStatus", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getTransactions_OrderId(), this.getOrder(), null, "orderId", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getTransactions_Status(), this.getStatus(), this.getStatus_Transactions(), "status", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getTransactions_Order(), this.getOrder(), this.getOrder_Transactions(), "order", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getTransactions_PaymentId(), this.getPaymentsInfo(), null, "paymentId", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getTransactions_StatusId(), this.getStatus(), null, "statusId", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getTransactions_PaymentsInfo(), this.getPaymentsInfo(), this.getPaymentsInfo_Transactions(), "paymentsInfo", null, 1, 1, Transactions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getTransactions__SetTotalPrice(), null, "setTotalPrice", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getTransactions__SetTransactionDate(), null, "setTransactionDate", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getTransactions__SetTransactionStatus(), null, "setTransactionStatus", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getTransactions__GetTotalPrice(), null, "getTotalPrice", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getTransactions__GetTransactionDate(), null, "getTransactionDate", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getTransactions__GetTransactionStatus(), null, "getTransactionStatus", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(orderEClass, Order.class, "Order", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOrder_OrderId(), ecorePackage.getEString(), "orderId", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrder_OrderPrice(), ecorePackage.getEFloat(), "orderPrice", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrder_Instructions(), ecorePackage.getEString(), "instructions", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrder_DiscountedPrice(), ecorePackage.getEFloat(), "discountedPrice", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrder_SourceLocationId(), ecorePackage.getEString(), "sourceLocationId", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrder_DestinationId(), ecorePackage.getEString(), "destinationId", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrder_Tax(), ecorePackage.getEFloat(), "tax", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrder_Delivery(), ecorePackage.getEFloat(), "delivery", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_StatusId(), this.getStatus(), null, "statusId", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_Status(), this.getStatus(), this.getStatus_Order(), "status", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_AgentId(), this.getDeliveryAgent(), null, "agentId", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_PaymentId(), this.getPaymentsInfo(), null, "paymentId", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_PromotionId(), this.getDiscounts(), null, "promotionId", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_Discounts(), this.getDiscounts(), this.getDiscounts_Order(), "discounts", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_CustomerId(), this.getCustomer(), null, "customerId", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_Transactions(), this.getTransactions(), this.getTransactions_Order(), "transactions", null, 1, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_PaymentsInfo(), this.getPaymentsInfo(), this.getPaymentsInfo_Order(), "paymentsInfo", null, 0, 1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrder_Catalog(), this.getCatalog(), this.getCatalog_Order(), "catalog", null, 1, -1, Order.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getOrder__SetOrderId(), null, "setOrderId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__SetOrderPrice(), null, "setOrderPrice", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__SetInstructions(), null, "setInstructions", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__SetDiscountedPrice(), null, "setDiscountedPrice", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__SetSourceLocationId(), null, "setSourceLocationId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__SetTax(), null, "setTax", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__SetDeliveryFee(), null, "setDeliveryFee", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__SetOderId(), null, "setOderId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__GetTax(), null, "getTax", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrder__GetDeliveryFee(), null, "getDeliveryFee", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(statusEClass, Status.class, "Status", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStatus_StatusId(), ecorePackage.getEString(), "statusId", null, 1, 1, Status.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getStatus_StatusType(), ecorePackage.getEString(), "statusType", null, 1, 1, Status.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getStatus_Transactions(), this.getTransactions(), this.getTransactions_Status(), "transactions", null, 1, -1, Status.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getStatus_Order(), this.getOrder(), this.getOrder_Status(), "order", null, 1, -1, Status.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getStatus__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getStatus__SetStatusId(), null, "setStatusId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getStatus__SetStatusType(), null, "setStatusType", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getStatus__GetStatusId(), null, "getStatusId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getStatus__GetStatusType(), null, "getStatusType", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(discountsEClass, Discounts.class, "Discounts", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDiscounts_PromotionId(), ecorePackage.getEString(), "promotionId", null, 1, 1, Discounts.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDiscounts_PromotionName(), ecorePackage.getEString(), "promotionName", null, 1, 1, Discounts.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDiscounts_PromotionCode(), ecorePackage.getEString(), "promotionCode", null, 1, 1, Discounts.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getDiscounts_Order(), this.getOrder(), this.getOrder_Discounts(), "order", null, 1, 1, Discounts.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getDiscounts__SetPromotionId(), null, "setPromotionId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDiscounts__SetPromotionName(), null, "setPromotionName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDiscounts__SetPromotionCode(), null, "setPromotionCode", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDiscounts__GetPromotionId(), null, "getPromotionId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDiscounts__GetPromotionName(), null, "getPromotionName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDiscounts__GetPromotionCode(), null, "getPromotionCode", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(catalogEClass, Catalog.class, "Catalog", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCatalog_Price(), ecorePackage.getEFloat(), "price", null, 1, 1, Catalog.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCatalog_ProductId(), this.getProduct(), null, "productId", null, 1, 1, Catalog.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCatalog_Product(), this.getProduct(), this.getProduct_Catalog(), "product", null, 1, -1, Catalog.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getCatalog_Order(), this.getOrder(), this.getOrder_Catalog(), "order", null, 1, 1, Catalog.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getCatalog__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCatalog__SetPrice(), null, "setPrice", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCatalog__GetPrice(), null, "getPrice", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(productEClass, Product.class, "Product", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getProduct_ProductId(), ecorePackage.getEString(), "productId", null, 1, 1, Product.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getProduct_ProductName(), ecorePackage.getEString(), "productName", null, 1, 1, Product.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getProduct_ProductDescripton(), ecorePackage.getEString(), "productDescripton", null, 1, 1, Product.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getProduct_CategoryId(), this.getProductCategory(), null, "categoryId", null, 1, 1, Product.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getProduct_ProductCategory(), this.getProductCategory(), this.getProductCategory_Product(), "productCategory", null, 1, -1, Product.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getProduct_OrderItemsId(), this.getOrderItems(), null, "orderItemsId", null, 1, 1, Product.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getProduct_OrderItems(), this.getOrderItems(), this.getOrderItems_Product(), "orderItems", null, 1, 1, Product.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getProduct_Catalog(), this.getCatalog(), this.getCatalog_Product(), "catalog", null, 0, 1, Product.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getProduct__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getProduct__SetProductId(), null, "setProductId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProduct__SetProductName(), null, "setProductName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProduct__SetProductDescription(), null, "setProductDescription", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProduct__GetProductId(), null, "getProductId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProduct__GetProductName(), null, "getProductName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProduct__GetProductDescription(), null, "getProductDescription", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(productCategoryEClass, ProductCategory.class, "ProductCategory", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getProductCategory_CategoryId(), ecorePackage.getEString(), "categoryId", null, 1, 1, ProductCategory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getProductCategory_CategoryName(), ecorePackage.getEString(), "categoryName", null, 1, 1, ProductCategory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getProductCategory_Product(), this.getProduct(), this.getProduct_ProductCategory(), "product", null, 1, 1, ProductCategory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getProductCategory__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getProductCategory__SetCategoryId(), null, "setCategoryId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProductCategory__SetCategoryName(), null, "setCategoryName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProductCategory__GetCategoryId(), null, "getCategoryId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProductCategory__GetcategoryName(), null, "getcategoryName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(orderItemsEClass, OrderItems.class, "OrderItems", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOrderItems_OrderItemsId(), ecorePackage.getEString(), "orderItemsId", null, 1, 1, OrderItems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrderItems_ProductQuantity(), ecorePackage.getEInt(), "productQuantity", null, 1, 1, OrderItems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrderItems_ProductId(), this.getProduct(), null, "productId", null, 1, 1, OrderItems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrderItems_OrderId(), this.getOrder(), null, "orderId", null, 1, 1, OrderItems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrderItems_Product(), this.getProduct(), this.getProduct_OrderItems(), "product", null, 1, 1, OrderItems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getOrderItems__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getOrderItems__SetOrderItemsId(), null, "setOrderItemsId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderItems__SetProductQuantity(), null, "setProductQuantity", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderItems__GetOrderItemsId(), null, "getOrderItemsId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderItems__GetProductQuantity(), null, "getProductQuantity", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(ratingsEClass, Ratings.class, "Ratings", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRatings_RatingId(), ecorePackage.getEString(), "ratingId", null, 1, 1, Ratings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getRatings_Rating(), ecorePackage.getEString(), "rating", null, 1, 1, Ratings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getRatings_Orderfeedback(), this.getOrderFeedback(), this.getOrderFeedback_Ratings(), "orderfeedback", null, 1, -1, Ratings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getRatings__Constraint1__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "constraint1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getRatings__SetRatingId(), null, "setRatingId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRatings__SetRating(), null, "setRating", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRatings__GetRatingId(), null, "getRatingId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRatings__GetRating(), null, "getRating", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(orderFeedbackEClass, OrderFeedback.class, "OrderFeedback", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOrderFeedback_ProductFeedback(), ecorePackage.getEString(), "productFeedback", null, 1, 1, OrderFeedback.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrderFeedback_DeliveryAgentFeedback(), ecorePackage.getEString(), "deliveryAgentFeedback", null, 1, 1, OrderFeedback.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getOrderFeedback_ProductRatingId(), ecorePackage.getEString(), "productRatingId", null, 1, 1, OrderFeedback.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrderFeedback_DeliveryAgentRatingId(), this.getDeliveryAgent(), null, "deliveryAgentRatingId", null, 1, 1, OrderFeedback.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrderFeedback_RatingId(), this.getRatings(), null, "ratingId", null, 1, 1, OrderFeedback.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrderFeedback_OrderId(), this.getOrder(), null, "orderId", null, 1, 1, OrderFeedback.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getOrderFeedback_Ratings(), this.getRatings(), this.getRatings_Orderfeedback(), "ratings", null, 1, 1, OrderFeedback.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getOrderFeedback__SetProductFeedback(), null, "setProductFeedback", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderFeedback__SetDeliveryAgentFeedback(), null, "setDeliveryAgentFeedback", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderFeedback__SetProductRatingId(), null, "setProductRatingId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderFeedback__SetDeliveryAgentRatingId(), null, "setDeliveryAgentRatingId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderFeedback__GetProductFeedback(), null, "getProductFeedback", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderFeedback__GetDeliveryAgentFeedback(), null, "getDeliveryAgentFeedback", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderFeedback__GetProductRatingId(), null, "getProductRatingId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getOrderFeedback__GetDeliveryAgentRatingId(), null, "getDeliveryAgentRatingId", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(primitiveTypesDateEClass, PrimitiveTypesDate.class, "PrimitiveTypesDate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(test1DateEClass, test1Date.class, "test1Date", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(test1DateEClass, test1Date.class, "test1Date", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(genderEEnum, Gender.class, "Gender");
		addEEnumLiteral(genderEEnum, Gender.MALE);
		addEEnumLiteral(genderEEnum, Gender.FEMALE);
		addEEnumLiteral(genderEEnum, Gender.OTHER);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/uml2/2.0.0/UML
		createUMLAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/uml2/2.0.0/UML</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createUMLAnnotations() {
		String source = "http://www.eclipse.org/uml2/2.0.0/UML";
		addAnnotation
		  (primitiveTypesDateEClass,
		   source,
		   new String[] {
			   "originalName", "PrimitiveTypes::Date"
		   });
		addAnnotation
		  (test1DateEClass,
		   source,
		   new String[] {
			   "originalName", "test1::Date"
		   });
		addAnnotation
		  (test1DateEClass,
		   source,
		   new String[] {
			   "originalName", "test1:: Date"
		   });
	}

} //Test1PackageImpl
