/**
 */
package test1.impl;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import test1.DeliveryAgent;
import test1.Order;
import test1.OrderFeedback;
import test1.Ratings;
import test1.Test1Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Order Feedback</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link test1.impl.OrderFeedbackImpl#getProductFeedback <em>Product Feedback</em>}</li>
 *   <li>{@link test1.impl.OrderFeedbackImpl#getDeliveryAgentFeedback <em>Delivery Agent Feedback</em>}</li>
 *   <li>{@link test1.impl.OrderFeedbackImpl#getProductRatingId <em>Product Rating Id</em>}</li>
 *   <li>{@link test1.impl.OrderFeedbackImpl#getDeliveryAgentRatingId <em>Delivery Agent Rating Id</em>}</li>
 *   <li>{@link test1.impl.OrderFeedbackImpl#getRatingId <em>Rating Id</em>}</li>
 *   <li>{@link test1.impl.OrderFeedbackImpl#getOrderId <em>Order Id</em>}</li>
 *   <li>{@link test1.impl.OrderFeedbackImpl#getRatings <em>Ratings</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OrderFeedbackImpl extends MinimalEObjectImpl.Container implements OrderFeedback {
	/**
	 * The default value of the '{@link #getProductFeedback() <em>Product Feedback</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductFeedback()
	 * @generated
	 * @ordered
	 */
	protected static final String PRODUCT_FEEDBACK_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProductFeedback() <em>Product Feedback</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductFeedback()
	 * @generated
	 * @ordered
	 */
	protected String productFeedback = PRODUCT_FEEDBACK_EDEFAULT;

	/**
	 * The default value of the '{@link #getDeliveryAgentFeedback() <em>Delivery Agent Feedback</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeliveryAgentFeedback()
	 * @generated
	 * @ordered
	 */
	protected static final String DELIVERY_AGENT_FEEDBACK_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDeliveryAgentFeedback() <em>Delivery Agent Feedback</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeliveryAgentFeedback()
	 * @generated
	 * @ordered
	 */
	protected String deliveryAgentFeedback = DELIVERY_AGENT_FEEDBACK_EDEFAULT;

	/**
	 * The default value of the '{@link #getProductRatingId() <em>Product Rating Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductRatingId()
	 * @generated
	 * @ordered
	 */
	protected static final String PRODUCT_RATING_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProductRatingId() <em>Product Rating Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductRatingId()
	 * @generated
	 * @ordered
	 */
	protected String productRatingId = PRODUCT_RATING_ID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDeliveryAgentRatingId() <em>Delivery Agent Rating Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeliveryAgentRatingId()
	 * @generated
	 * @ordered
	 */
	protected DeliveryAgent deliveryAgentRatingId;

	/**
	 * The cached value of the '{@link #getRatingId() <em>Rating Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRatingId()
	 * @generated
	 * @ordered
	 */
	protected Ratings ratingId;

	/**
	 * The cached value of the '{@link #getOrderId() <em>Order Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderId()
	 * @generated
	 * @ordered
	 */
	protected Order orderId;

	/**
	 * The cached value of the '{@link #getRatings() <em>Ratings</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRatings()
	 * @generated
	 * @ordered
	 */
	protected Ratings ratings;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OrderFeedbackImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Test1Package.Literals.ORDER_FEEDBACK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProductFeedback() {
		return productFeedback;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductFeedback(String newProductFeedback) {
		String oldProductFeedback = productFeedback;
		productFeedback = newProductFeedback;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER_FEEDBACK__PRODUCT_FEEDBACK, oldProductFeedback, productFeedback));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDeliveryAgentFeedback() {
		return deliveryAgentFeedback;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeliveryAgentFeedback(String newDeliveryAgentFeedback) {
		String oldDeliveryAgentFeedback = deliveryAgentFeedback;
		deliveryAgentFeedback = newDeliveryAgentFeedback;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_FEEDBACK, oldDeliveryAgentFeedback, deliveryAgentFeedback));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProductRatingId() {
		return productRatingId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductRatingId(String newProductRatingId) {
		String oldProductRatingId = productRatingId;
		productRatingId = newProductRatingId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER_FEEDBACK__PRODUCT_RATING_ID, oldProductRatingId, productRatingId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeliveryAgent getDeliveryAgentRatingId() {
		if (deliveryAgentRatingId != null && deliveryAgentRatingId.eIsProxy()) {
			InternalEObject oldDeliveryAgentRatingId = (InternalEObject)deliveryAgentRatingId;
			deliveryAgentRatingId = (DeliveryAgent)eResolveProxy(oldDeliveryAgentRatingId);
			if (deliveryAgentRatingId != oldDeliveryAgentRatingId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID, oldDeliveryAgentRatingId, deliveryAgentRatingId));
			}
		}
		return deliveryAgentRatingId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeliveryAgent basicGetDeliveryAgentRatingId() {
		return deliveryAgentRatingId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeliveryAgentRatingId(DeliveryAgent newDeliveryAgentRatingId) {
		DeliveryAgent oldDeliveryAgentRatingId = deliveryAgentRatingId;
		deliveryAgentRatingId = newDeliveryAgentRatingId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID, oldDeliveryAgentRatingId, deliveryAgentRatingId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ratings getRatingId() {
		if (ratingId != null && ratingId.eIsProxy()) {
			InternalEObject oldRatingId = (InternalEObject)ratingId;
			ratingId = (Ratings)eResolveProxy(oldRatingId);
			if (ratingId != oldRatingId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER_FEEDBACK__RATING_ID, oldRatingId, ratingId));
			}
		}
		return ratingId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ratings basicGetRatingId() {
		return ratingId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRatingId(Ratings newRatingId) {
		Ratings oldRatingId = ratingId;
		ratingId = newRatingId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER_FEEDBACK__RATING_ID, oldRatingId, ratingId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order getOrderId() {
		if (orderId != null && orderId.eIsProxy()) {
			InternalEObject oldOrderId = (InternalEObject)orderId;
			orderId = (Order)eResolveProxy(oldOrderId);
			if (orderId != oldOrderId) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Test1Package.ORDER_FEEDBACK__ORDER_ID, oldOrderId, orderId));
			}
		}
		return orderId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order basicGetOrderId() {
		return orderId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderId(Order newOrderId) {
		Order oldOrderId = orderId;
		orderId = newOrderId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER_FEEDBACK__ORDER_ID, oldOrderId, orderId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ratings getRatings() {
		return ratings;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRatings(Ratings newRatings, NotificationChain msgs) {
		Ratings oldRatings = ratings;
		ratings = newRatings;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Test1Package.ORDER_FEEDBACK__RATINGS, oldRatings, newRatings);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRatings(Ratings newRatings) {
		if (newRatings != ratings) {
			NotificationChain msgs = null;
			if (ratings != null)
				msgs = ((InternalEObject)ratings).eInverseRemove(this, Test1Package.RATINGS__ORDERFEEDBACK, Ratings.class, msgs);
			if (newRatings != null)
				msgs = ((InternalEObject)newRatings).eInverseAdd(this, Test1Package.RATINGS__ORDERFEEDBACK, Ratings.class, msgs);
			msgs = basicSetRatings(newRatings, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Test1Package.ORDER_FEEDBACK__RATINGS, newRatings, newRatings));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductFeedback() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeliveryAgentFeedback() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProductRatingId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeliveryAgentRatingId() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.ORDER_FEEDBACK__RATINGS:
				if (ratings != null)
					msgs = ((InternalEObject)ratings).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Test1Package.ORDER_FEEDBACK__RATINGS, null, msgs);
				return basicSetRatings((Ratings)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Test1Package.ORDER_FEEDBACK__RATINGS:
				return basicSetRatings(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Test1Package.ORDER_FEEDBACK__PRODUCT_FEEDBACK:
				return getProductFeedback();
			case Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_FEEDBACK:
				return getDeliveryAgentFeedback();
			case Test1Package.ORDER_FEEDBACK__PRODUCT_RATING_ID:
				return getProductRatingId();
			case Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID:
				if (resolve) return getDeliveryAgentRatingId();
				return basicGetDeliveryAgentRatingId();
			case Test1Package.ORDER_FEEDBACK__RATING_ID:
				if (resolve) return getRatingId();
				return basicGetRatingId();
			case Test1Package.ORDER_FEEDBACK__ORDER_ID:
				if (resolve) return getOrderId();
				return basicGetOrderId();
			case Test1Package.ORDER_FEEDBACK__RATINGS:
				return getRatings();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Test1Package.ORDER_FEEDBACK__PRODUCT_FEEDBACK:
				setProductFeedback((String)newValue);
				return;
			case Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_FEEDBACK:
				setDeliveryAgentFeedback((String)newValue);
				return;
			case Test1Package.ORDER_FEEDBACK__PRODUCT_RATING_ID:
				setProductRatingId((String)newValue);
				return;
			case Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID:
				setDeliveryAgentRatingId((DeliveryAgent)newValue);
				return;
			case Test1Package.ORDER_FEEDBACK__RATING_ID:
				setRatingId((Ratings)newValue);
				return;
			case Test1Package.ORDER_FEEDBACK__ORDER_ID:
				setOrderId((Order)newValue);
				return;
			case Test1Package.ORDER_FEEDBACK__RATINGS:
				setRatings((Ratings)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Test1Package.ORDER_FEEDBACK__PRODUCT_FEEDBACK:
				setProductFeedback(PRODUCT_FEEDBACK_EDEFAULT);
				return;
			case Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_FEEDBACK:
				setDeliveryAgentFeedback(DELIVERY_AGENT_FEEDBACK_EDEFAULT);
				return;
			case Test1Package.ORDER_FEEDBACK__PRODUCT_RATING_ID:
				setProductRatingId(PRODUCT_RATING_ID_EDEFAULT);
				return;
			case Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID:
				setDeliveryAgentRatingId((DeliveryAgent)null);
				return;
			case Test1Package.ORDER_FEEDBACK__RATING_ID:
				setRatingId((Ratings)null);
				return;
			case Test1Package.ORDER_FEEDBACK__ORDER_ID:
				setOrderId((Order)null);
				return;
			case Test1Package.ORDER_FEEDBACK__RATINGS:
				setRatings((Ratings)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Test1Package.ORDER_FEEDBACK__PRODUCT_FEEDBACK:
				return PRODUCT_FEEDBACK_EDEFAULT == null ? productFeedback != null : !PRODUCT_FEEDBACK_EDEFAULT.equals(productFeedback);
			case Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_FEEDBACK:
				return DELIVERY_AGENT_FEEDBACK_EDEFAULT == null ? deliveryAgentFeedback != null : !DELIVERY_AGENT_FEEDBACK_EDEFAULT.equals(deliveryAgentFeedback);
			case Test1Package.ORDER_FEEDBACK__PRODUCT_RATING_ID:
				return PRODUCT_RATING_ID_EDEFAULT == null ? productRatingId != null : !PRODUCT_RATING_ID_EDEFAULT.equals(productRatingId);
			case Test1Package.ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID:
				return deliveryAgentRatingId != null;
			case Test1Package.ORDER_FEEDBACK__RATING_ID:
				return ratingId != null;
			case Test1Package.ORDER_FEEDBACK__ORDER_ID:
				return orderId != null;
			case Test1Package.ORDER_FEEDBACK__RATINGS:
				return ratings != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Test1Package.ORDER_FEEDBACK___SET_PRODUCT_FEEDBACK:
				setProductFeedback();
				return null;
			case Test1Package.ORDER_FEEDBACK___SET_DELIVERY_AGENT_FEEDBACK:
				setDeliveryAgentFeedback();
				return null;
			case Test1Package.ORDER_FEEDBACK___SET_PRODUCT_RATING_ID:
				setProductRatingId();
				return null;
			case Test1Package.ORDER_FEEDBACK___SET_DELIVERY_AGENT_RATING_ID:
				setDeliveryAgentRatingId();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (productFeedback: ");
		result.append(productFeedback);
		result.append(", deliveryAgentFeedback: ");
		result.append(deliveryAgentFeedback);
		result.append(", productRatingId: ");
		result.append(productRatingId);
		result.append(')');
		return result.toString();
	}

} //OrderFeedbackImpl
