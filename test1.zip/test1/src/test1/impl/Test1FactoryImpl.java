/**
 */
package test1.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import test1.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Test1FactoryImpl extends EFactoryImpl implements Test1Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test1Factory init() {
		try {
			Test1Factory theTest1Factory = (Test1Factory)EPackage.Registry.INSTANCE.getEFactory(Test1Package.eNS_URI);
			if (theTest1Factory != null) {
				return theTest1Factory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Test1FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Test1FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case Test1Package.CARD: return createCard();
			case Test1Package.PAYMENTS_INFO: return createPaymentsInfo();
			case Test1Package.USER_DETAILS: return createUserDetails();
			case Test1Package.DELIVERY_AGENT: return createDeliveryAgent();
			case Test1Package.DATE: return createDate();
			case Test1Package.CUSTOMER: return createCustomer();
			case Test1Package.ADDRESS: return createAddress();
			case Test1Package.LOCATION: return createLocation();
			case Test1Package.ZIPCODE: return createZipcode();
			case Test1Package.TRANSACTIONS: return createTransactions();
			case Test1Package.ORDER: return createOrder();
			case Test1Package.STATUS: return createStatus();
			case Test1Package.DISCOUNTS: return createDiscounts();
			case Test1Package.CATALOG: return createCatalog();
			case Test1Package.PRODUCT: return createProduct();
			case Test1Package.PRODUCT_CATEGORY: return createProductCategory();
			case Test1Package.ORDER_ITEMS: return createOrderItems();
			case Test1Package.RATINGS: return createRatings();
			case Test1Package.ORDER_FEEDBACK: return createOrderFeedback();
			case Test1Package.PRIMITIVE_TYPES_DATE: return createPrimitiveTypesDate();
			case Test1Package.TEST1_DATE: return createtest1Date();
			case Test1Package.TEST1_DATE: return createtest1Date();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case Test1Package.GENDER:
				return createGenderFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case Test1Package.GENDER:
				return convertGenderToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Card createCard() {
		CardImpl card = new CardImpl();
		return card;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentsInfo createPaymentsInfo() {
		PaymentsInfoImpl paymentsInfo = new PaymentsInfoImpl();
		return paymentsInfo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserDetails createUserDetails() {
		UserDetailsImpl userDetails = new UserDetailsImpl();
		return userDetails;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeliveryAgent createDeliveryAgent() {
		DeliveryAgentImpl deliveryAgent = new DeliveryAgentImpl();
		return deliveryAgent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date createDate() {
		DateImpl date = new DateImpl();
		return date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer createCustomer() {
		CustomerImpl customer = new CustomerImpl();
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Address createAddress() {
		AddressImpl address = new AddressImpl();
		return address;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Location createLocation() {
		LocationImpl location = new LocationImpl();
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zipcode createZipcode() {
		ZipcodeImpl zipcode = new ZipcodeImpl();
		return zipcode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transactions createTransactions() {
		TransactionsImpl transactions = new TransactionsImpl();
		return transactions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Order createOrder() {
		OrderImpl order = new OrderImpl();
		return order;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Status createStatus() {
		StatusImpl status = new StatusImpl();
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Discounts createDiscounts() {
		DiscountsImpl discounts = new DiscountsImpl();
		return discounts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Catalog createCatalog() {
		CatalogImpl catalog = new CatalogImpl();
		return catalog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Product createProduct() {
		ProductImpl product = new ProductImpl();
		return product;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProductCategory createProductCategory() {
		ProductCategoryImpl productCategory = new ProductCategoryImpl();
		return productCategory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OrderItems createOrderItems() {
		OrderItemsImpl orderItems = new OrderItemsImpl();
		return orderItems;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ratings createRatings() {
		RatingsImpl ratings = new RatingsImpl();
		return ratings;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OrderFeedback createOrderFeedback() {
		OrderFeedbackImpl orderFeedback = new OrderFeedbackImpl();
		return orderFeedback;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PrimitiveTypesDate createPrimitiveTypesDate() {
		PrimitiveTypesDateImpl primitiveTypesDate = new PrimitiveTypesDateImpl();
		return primitiveTypesDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public test1Date createtest1Date() {
		test1DateImpl test1Date = new test1DateImpl();
		return test1Date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public test1Date createtest1Date() {
		test1DateImpl test1Date = new test1DateImpl();
		return test1Date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public test1Date createtest1Date() {
		test1DateImpl test1Date = new test1DateImpl();
		return test1Date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public test1Date createtest1Date() {
		test1DateImpl test1Date = new test1DateImpl();
		return test1Date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public test1Date createtest1Date() {
		test1DateImpl test1Date = new test1DateImpl();
		return test1Date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Gender createGenderFromString(EDataType eDataType, String initialValue) {
		Gender result = Gender.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertGenderToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Test1Package getTest1Package() {
		return (Test1Package)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Test1Package getPackage() {
		return Test1Package.eINSTANCE;
	}

} //Test1FactoryImpl
