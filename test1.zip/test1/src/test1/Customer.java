/**
 */
package test1;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Customer#getCustomerId <em>Customer Id</em>}</li>
 *   <li>{@link test1.Customer#getEmailId <em>Email Id</em>}</li>
 *   <li>{@link test1.Customer#getContactNo <em>Contact No</em>}</li>
 *   <li>{@link test1.Customer#getUserId <em>User Id</em>}</li>
 *   <li>{@link test1.Customer#getUserDetails <em>User Details</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getCustomer()
 * @model
 * @generated
 */
public interface Customer extends Person {
	/**
	 * Returns the value of the '<em><b>Customer Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Customer Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer Id</em>' attribute.
	 * @see #setCustomerId(String)
	 * @see test1.Test1Package#getCustomer_CustomerId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getCustomerId();

	/**
	 * Sets the value of the '{@link test1.Customer#getCustomerId <em>Customer Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Customer Id</em>' attribute.
	 * @see #getCustomerId()
	 * @generated
	 */
	void setCustomerId(String value);

	/**
	 * Returns the value of the '<em><b>Email Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Email Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Email Id</em>' attribute.
	 * @see #setEmailId(String)
	 * @see test1.Test1Package#getCustomer_EmailId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getEmailId();

	/**
	 * Sets the value of the '{@link test1.Customer#getEmailId <em>Email Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Email Id</em>' attribute.
	 * @see #getEmailId()
	 * @generated
	 */
	void setEmailId(String value);

	/**
	 * Returns the value of the '<em><b>Contact No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Contact No</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contact No</em>' attribute.
	 * @see #setContactNo(int)
	 * @see test1.Test1Package#getCustomer_ContactNo()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getContactNo();

	/**
	 * Sets the value of the '{@link test1.Customer#getContactNo <em>Contact No</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Contact No</em>' attribute.
	 * @see #getContactNo()
	 * @generated
	 */
	void setContactNo(int value);

	/**
	 * Returns the value of the '<em><b>User Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Id</em>' reference.
	 * @see #setUserId(UserDetails)
	 * @see test1.Test1Package#getCustomer_UserId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	UserDetails getUserId();

	/**
	 * Sets the value of the '{@link test1.Customer#getUserId <em>User Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Id</em>' reference.
	 * @see #getUserId()
	 * @generated
	 */
	void setUserId(UserDetails value);

	/**
	 * Returns the value of the '<em><b>User Details</b></em>' containment reference.
	 * It is bidirectional and its opposite is '{@link test1.UserDetails#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>User Details</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User Details</em>' containment reference.
	 * @see #setUserDetails(UserDetails)
	 * @see test1.Test1Package#getCustomer_UserDetails()
	 * @see test1.UserDetails#getCustomer
	 * @model opposite="customer" containment="true" required="true" ordered="false"
	 * @generated
	 */
	UserDetails getUserDetails();

	/**
	 * Sets the value of the '{@link test1.Customer#getUserDetails <em>User Details</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User Details</em>' containment reference.
	 * @see #getUserDetails()
	 * @generated
	 */
	void setUserDetails(UserDetails value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setUserId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setCustomerId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setEmailId();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setContactNo();

} // Customer
