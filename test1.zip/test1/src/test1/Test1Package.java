/**
 */
package test1;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see test1.Test1Factory
 * @model kind="package"
 * @generated
 */
public interface Test1Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "test1";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///test1.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "test1";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Test1Package eINSTANCE = test1.impl.Test1PackageImpl.init();

	/**
	 * The meta object id for the '{@link test1.impl.CardImpl <em>Card</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.CardImpl
	 * @see test1.impl.Test1PackageImpl#getCard()
	 * @generated
	 */
	int CARD = 0;

	/**
	 * The feature id for the '<em><b>Card Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD__CARD_ID = 0;

	/**
	 * The feature id for the '<em><b>Card Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD__CARD_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Payments Info</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD__PAYMENTS_INFO = 2;

	/**
	 * The number of structural features of the '<em>Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Card Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD___SET_CARD_ID = 1;

	/**
	 * The operation id for the '<em>Set Card Type</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD___SET_CARD_TYPE = 2;

	/**
	 * The operation id for the '<em>Get Card Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD___GET_CARD_ID = 3;

	/**
	 * The operation id for the '<em>Get Card Type</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD___GET_CARD_TYPE = 4;

	/**
	 * The number of operations of the '<em>Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD_OPERATION_COUNT = 5;

	/**
	 * The meta object id for the '{@link test1.impl.PaymentsInfoImpl <em>Payments Info</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.PaymentsInfoImpl
	 * @see test1.impl.Test1PackageImpl#getPaymentsInfo()
	 * @generated
	 */
	int PAYMENTS_INFO = 1;

	/**
	 * The feature id for the '<em><b>Payment Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__PAYMENT_ID = 0;

	/**
	 * The feature id for the '<em><b>Card No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__CARD_NO = 1;

	/**
	 * The feature id for the '<em><b>Expiry Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__EXPIRY_DATE = 2;

	/**
	 * The feature id for the '<em><b>Card Holder Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__CARD_HOLDER_NAME = 3;

	/**
	 * The feature id for the '<em><b>Cvv</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__CVV = 4;

	/**
	 * The feature id for the '<em><b>Card Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__CARD_ID = 5;

	/**
	 * The feature id for the '<em><b>User Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__USER_ID = 6;

	/**
	 * The feature id for the '<em><b>Transactions</b></em>' container reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__TRANSACTIONS = 7;

	/**
	 * The feature id for the '<em><b>Order</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__ORDER = 8;

	/**
	 * The feature id for the '<em><b>Card</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO__CARD = 9;

	/**
	 * The number of structural features of the '<em>Payments Info</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO_FEATURE_COUNT = 10;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Card No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO___SET_CARD_NO = 1;

	/**
	 * The operation id for the '<em>Set Expiry Date</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO___SET_EXPIRY_DATE = 2;

	/**
	 * The operation id for the '<em>Set Card Holder Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO___SET_CARD_HOLDER_NAME = 3;

	/**
	 * The operation id for the '<em>Set Cvv</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO___SET_CVV = 4;

	/**
	 * The operation id for the '<em>Get Card No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO___GET_CARD_NO = 5;

	/**
	 * The operation id for the '<em>Get Expiry Date</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO___GET_EXPIRY_DATE = 6;

	/**
	 * The operation id for the '<em>Get Card Holder Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO___GET_CARD_HOLDER_NAME = 7;

	/**
	 * The number of operations of the '<em>Payments Info</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENTS_INFO_OPERATION_COUNT = 8;

	/**
	 * The meta object id for the '{@link test1.impl.UserDetailsImpl <em>User Details</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.UserDetailsImpl
	 * @see test1.impl.Test1PackageImpl#getUserDetails()
	 * @generated
	 */
	int USER_DETAILS = 2;

	/**
	 * The feature id for the '<em><b>User Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS__USER_ID = 0;

	/**
	 * The feature id for the '<em><b>Username</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS__USERNAME = 1;

	/**
	 * The feature id for the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS__PASSWORD = 2;

	/**
	 * The feature id for the '<em><b>Delivery Agent</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS__DELIVERY_AGENT = 3;

	/**
	 * The feature id for the '<em><b>Customer</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS__CUSTOMER = 4;

	/**
	 * The feature id for the '<em><b>Address</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS__ADDRESS = 5;

	/**
	 * The number of structural features of the '<em>User Details</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS_FEATURE_COUNT = 6;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set User Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS___SET_USER_ID = 1;

	/**
	 * The operation id for the '<em>Set Username</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS___SET_USERNAME = 2;

	/**
	 * The operation id for the '<em>Set Password</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS___SET_PASSWORD = 3;

	/**
	 * The operation id for the '<em>Get User Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS___GET_USER_ID = 4;

	/**
	 * The operation id for the '<em>Get Username</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS___GET_USERNAME = 5;

	/**
	 * The number of operations of the '<em>User Details</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_DETAILS_OPERATION_COUNT = 6;

	/**
	 * The meta object id for the '{@link test1.impl.PersonImpl <em>Person</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.PersonImpl
	 * @see test1.impl.Test1PackageImpl#getPerson()
	 * @generated
	 */
	int PERSON = 4;

	/**
	 * The feature id for the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__FIRST_NAME = 0;

	/**
	 * The feature id for the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__LAST_NAME = 1;

	/**
	 * The feature id for the '<em><b>Sex</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__SEX = 2;

	/**
	 * The feature id for the '<em><b>Date Of Birth</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__DATE_OF_BIRTH = 3;

	/**
	 * The feature id for the '<em><b>Gender</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__GENDER = 4;

	/**
	 * The number of structural features of the '<em>Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Set First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___SET_FIRST_NAME = 0;

	/**
	 * The operation id for the '<em>Set Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___SET_LAST_NAME = 1;

	/**
	 * The operation id for the '<em>Set Date Of Birth</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___SET_DATE_OF_BIRTH = 2;

	/**
	 * The operation id for the '<em>Get First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___GET_FIRST_NAME = 3;

	/**
	 * The operation id for the '<em>Get Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___GET_LAST_NAME = 4;

	/**
	 * The operation id for the '<em>Get Date Of Birth</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___GET_DATE_OF_BIRTH = 5;

	/**
	 * The number of operations of the '<em>Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON_OPERATION_COUNT = 6;

	/**
	 * The meta object id for the '{@link test1.impl.DeliveryAgentImpl <em>Delivery Agent</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.DeliveryAgentImpl
	 * @see test1.impl.Test1PackageImpl#getDeliveryAgent()
	 * @generated
	 */
	int DELIVERY_AGENT = 3;

	/**
	 * The feature id for the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__FIRST_NAME = PERSON__FIRST_NAME;

	/**
	 * The feature id for the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__LAST_NAME = PERSON__LAST_NAME;

	/**
	 * The feature id for the '<em><b>Sex</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__SEX = PERSON__SEX;

	/**
	 * The feature id for the '<em><b>Date Of Birth</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__DATE_OF_BIRTH = PERSON__DATE_OF_BIRTH;

	/**
	 * The feature id for the '<em><b>Gender</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__GENDER = PERSON__GENDER;

	/**
	 * The feature id for the '<em><b>Agent Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__AGENT_ID = PERSON_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Contact No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__CONTACT_NO = PERSON_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Ssn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__SSN = PERSON_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Driving License No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__DRIVING_LICENSE_NO = PERSON_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>User Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__USER_ID = PERSON_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>User Details</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT__USER_DETAILS = PERSON_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Delivery Agent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT_FEATURE_COUNT = PERSON_FEATURE_COUNT + 6;

	/**
	 * The operation id for the '<em>Set First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___SET_FIRST_NAME = PERSON___SET_FIRST_NAME;

	/**
	 * The operation id for the '<em>Set Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___SET_LAST_NAME = PERSON___SET_LAST_NAME;

	/**
	 * The operation id for the '<em>Set Date Of Birth</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___SET_DATE_OF_BIRTH = PERSON___SET_DATE_OF_BIRTH;

	/**
	 * The operation id for the '<em>Get First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___GET_FIRST_NAME = PERSON___GET_FIRST_NAME;

	/**
	 * The operation id for the '<em>Get Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___GET_LAST_NAME = PERSON___GET_LAST_NAME;

	/**
	 * The operation id for the '<em>Get Date Of Birth</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___GET_DATE_OF_BIRTH = PERSON___GET_DATE_OF_BIRTH;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = PERSON_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Agent Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___SET_AGENT_ID = PERSON_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Set Contact No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___SET_CONTACT_NO = PERSON_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Set Ssn</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___SET_SSN = PERSON_OPERATION_COUNT + 3;

	/**
	 * The operation id for the '<em>Set Driving License No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___SET_DRIVING_LICENSE_NO = PERSON_OPERATION_COUNT + 4;

	/**
	 * The operation id for the '<em>Get Agent Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___GET_AGENT_ID = PERSON_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Get Contact No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___GET_CONTACT_NO = PERSON_OPERATION_COUNT + 6;

	/**
	 * The operation id for the '<em>Get Ssn</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___GET_SSN = PERSON_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Get Driving License No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT___GET_DRIVING_LICENSE_NO = PERSON_OPERATION_COUNT + 8;

	/**
	 * The number of operations of the '<em>Delivery Agent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVERY_AGENT_OPERATION_COUNT = PERSON_OPERATION_COUNT + 9;

	/**
	 * The meta object id for the '{@link test1.impl.DateImpl <em>Date</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.DateImpl
	 * @see test1.impl.Test1PackageImpl#getDate()
	 * @generated
	 */
	int DATE = 5;

	/**
	 * The number of structural features of the '<em>Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link test1.impl.CustomerImpl <em>Customer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.CustomerImpl
	 * @see test1.impl.Test1PackageImpl#getCustomer()
	 * @generated
	 */
	int CUSTOMER = 6;

	/**
	 * The feature id for the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__FIRST_NAME = PERSON__FIRST_NAME;

	/**
	 * The feature id for the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__LAST_NAME = PERSON__LAST_NAME;

	/**
	 * The feature id for the '<em><b>Sex</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__SEX = PERSON__SEX;

	/**
	 * The feature id for the '<em><b>Date Of Birth</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__DATE_OF_BIRTH = PERSON__DATE_OF_BIRTH;

	/**
	 * The feature id for the '<em><b>Gender</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__GENDER = PERSON__GENDER;

	/**
	 * The feature id for the '<em><b>Customer Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__CUSTOMER_ID = PERSON_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Email Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__EMAIL_ID = PERSON_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Contact No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__CONTACT_NO = PERSON_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>User Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__USER_ID = PERSON_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>User Details</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__USER_DETAILS = PERSON_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Customer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER_FEATURE_COUNT = PERSON_FEATURE_COUNT + 5;

	/**
	 * The operation id for the '<em>Set First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___SET_FIRST_NAME = PERSON___SET_FIRST_NAME;

	/**
	 * The operation id for the '<em>Set Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___SET_LAST_NAME = PERSON___SET_LAST_NAME;

	/**
	 * The operation id for the '<em>Set Date Of Birth</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___SET_DATE_OF_BIRTH = PERSON___SET_DATE_OF_BIRTH;

	/**
	 * The operation id for the '<em>Get First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___GET_FIRST_NAME = PERSON___GET_FIRST_NAME;

	/**
	 * The operation id for the '<em>Get Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___GET_LAST_NAME = PERSON___GET_LAST_NAME;

	/**
	 * The operation id for the '<em>Get Date Of Birth</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___GET_DATE_OF_BIRTH = PERSON___GET_DATE_OF_BIRTH;

	/**
	 * The operation id for the '<em>Set User Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___SET_USER_ID = PERSON_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Customer Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___SET_CUSTOMER_ID = PERSON_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Set Email Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___SET_EMAIL_ID = PERSON_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Set Contact No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___SET_CONTACT_NO = PERSON_OPERATION_COUNT + 3;

	/**
	 * The operation id for the '<em>Get Customer Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___GET_CUSTOMER_ID = PERSON_OPERATION_COUNT + 4;

	/**
	 * The operation id for the '<em>Get Email Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___GET_EMAIL_ID = PERSON_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Get Contact No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER___GET_CONTACT_NO = PERSON_OPERATION_COUNT + 6;

	/**
	 * The number of operations of the '<em>Customer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER_OPERATION_COUNT = PERSON_OPERATION_COUNT + 7;

	/**
	 * The meta object id for the '{@link test1.impl.AddressImpl <em>Address</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.AddressImpl
	 * @see test1.impl.Test1PackageImpl#getAddress()
	 * @generated
	 */
	int ADDRESS = 7;

	/**
	 * The feature id for the '<em><b>Address Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS__ADDRESS_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Location Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS__LOCATION_ID = 1;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS__LOCATION = 2;

	/**
	 * The feature id for the '<em><b>User Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS__USER_ID = 3;

	/**
	 * The feature id for the '<em><b>User Details</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS__USER_DETAILS = 4;

	/**
	 * The number of structural features of the '<em>Address</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Set Address Type</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS___SET_ADDRESS_TYPE = 0;

	/**
	 * The operation id for the '<em>Get Address Type</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS___GET_ADDRESS_TYPE = 1;

	/**
	 * The number of operations of the '<em>Address</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDRESS_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link test1.impl.LocationImpl <em>Location</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.LocationImpl
	 * @see test1.impl.Test1PackageImpl#getLocation()
	 * @generated
	 */
	int LOCATION = 8;

	/**
	 * The feature id for the '<em><b>Location Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__LOCATION_ID = 0;

	/**
	 * The feature id for the '<em><b>Street Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__STREET_NAME = 1;

	/**
	 * The feature id for the '<em><b>House No</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__HOUSE_NO = 2;

	/**
	 * The feature id for the '<em><b>Zip</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__ZIP = 3;

	/**
	 * The feature id for the '<em><b>Zipcode</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__ZIPCODE = 4;

	/**
	 * The feature id for the '<em><b>Address</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__ADDRESS = 5;

	/**
	 * The number of structural features of the '<em>Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION_FEATURE_COUNT = 6;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Location</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION___SET_LOCATION = 1;

	/**
	 * The operation id for the '<em>Set Street Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION___SET_STREET_NAME = 2;

	/**
	 * The operation id for the '<em>Set House No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION___SET_HOUSE_NO = 3;

	/**
	 * The operation id for the '<em>Get Location Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION___GET_LOCATION_ID = 4;

	/**
	 * The operation id for the '<em>Get Street Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION___GET_STREET_NAME = 5;

	/**
	 * The operation id for the '<em>Get House No</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION___GET_HOUSE_NO = 6;

	/**
	 * The number of operations of the '<em>Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION_OPERATION_COUNT = 7;

	/**
	 * The meta object id for the '{@link test1.impl.ZipcodeImpl <em>Zipcode</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.ZipcodeImpl
	 * @see test1.impl.Test1PackageImpl#getZipcode()
	 * @generated
	 */
	int ZIPCODE = 9;

	/**
	 * The feature id for the '<em><b>Zip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE__ZIP = 0;

	/**
	 * The feature id for the '<em><b>City</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE__CITY = 1;

	/**
	 * The feature id for the '<em><b>State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE__STATE = 2;

	/**
	 * The feature id for the '<em><b>Country</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE__COUNTRY = 3;

	/**
	 * The feature id for the '<em><b>Location</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE__LOCATION = 4;

	/**
	 * The number of structural features of the '<em>Zipcode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Set Zip</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE___SET_ZIP = 0;

	/**
	 * The operation id for the '<em>Set City</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE___SET_CITY = 1;

	/**
	 * The operation id for the '<em>Set Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE___SET_STATUS = 2;

	/**
	 * The operation id for the '<em>Set Country</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE___SET_COUNTRY = 3;

	/**
	 * The operation id for the '<em>Get Zip</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE___GET_ZIP = 4;

	/**
	 * The operation id for the '<em>Get City</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE___GET_CITY = 5;

	/**
	 * The operation id for the '<em>Get State</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE___GET_STATE = 6;

	/**
	 * The operation id for the '<em>Get Country</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE___GET_COUNTRY = 7;

	/**
	 * The number of operations of the '<em>Zipcode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZIPCODE_OPERATION_COUNT = 8;

	/**
	 * The meta object id for the '{@link test1.impl.TransactionsImpl <em>Transactions</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.TransactionsImpl
	 * @see test1.impl.Test1PackageImpl#getTransactions()
	 * @generated
	 */
	int TRANSACTIONS = 10;

	/**
	 * The feature id for the '<em><b>Transaction Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__TRANSACTION_ID = 0;

	/**
	 * The feature id for the '<em><b>Total Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__TOTAL_PRICE = 1;

	/**
	 * The feature id for the '<em><b>Transaction Date</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__TRANSACTION_DATE = 2;

	/**
	 * The feature id for the '<em><b>Transaction Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__TRANSACTION_STATUS = 3;

	/**
	 * The feature id for the '<em><b>Order Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__ORDER_ID = 4;

	/**
	 * The feature id for the '<em><b>Status</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__STATUS = 5;

	/**
	 * The feature id for the '<em><b>Order</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__ORDER = 6;

	/**
	 * The feature id for the '<em><b>Payment Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__PAYMENT_ID = 7;

	/**
	 * The feature id for the '<em><b>Status Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__STATUS_ID = 8;

	/**
	 * The feature id for the '<em><b>Payments Info</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS__PAYMENTS_INFO = 9;

	/**
	 * The number of structural features of the '<em>Transactions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS_FEATURE_COUNT = 10;

	/**
	 * The operation id for the '<em>Set Total Price</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS___SET_TOTAL_PRICE = 0;

	/**
	 * The operation id for the '<em>Set Transaction Date</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS___SET_TRANSACTION_DATE = 1;

	/**
	 * The operation id for the '<em>Set Transaction Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS___SET_TRANSACTION_STATUS = 2;

	/**
	 * The operation id for the '<em>Get Total Price</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS___GET_TOTAL_PRICE = 3;

	/**
	 * The operation id for the '<em>Get Transaction Date</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS___GET_TRANSACTION_DATE = 4;

	/**
	 * The operation id for the '<em>Get Transaction Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS___GET_TRANSACTION_STATUS = 5;

	/**
	 * The number of operations of the '<em>Transactions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSACTIONS_OPERATION_COUNT = 6;

	/**
	 * The meta object id for the '{@link test1.impl.OrderImpl <em>Order</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.OrderImpl
	 * @see test1.impl.Test1PackageImpl#getOrder()
	 * @generated
	 */
	int ORDER = 11;

	/**
	 * The feature id for the '<em><b>Order Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__ORDER_ID = 0;

	/**
	 * The feature id for the '<em><b>Order Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__ORDER_PRICE = 1;

	/**
	 * The feature id for the '<em><b>Instructions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__INSTRUCTIONS = 2;

	/**
	 * The feature id for the '<em><b>Discounted Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__DISCOUNTED_PRICE = 3;

	/**
	 * The feature id for the '<em><b>Source Location Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__SOURCE_LOCATION_ID = 4;

	/**
	 * The feature id for the '<em><b>Destination Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__DESTINATION_ID = 5;

	/**
	 * The feature id for the '<em><b>Tax</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__TAX = 6;

	/**
	 * The feature id for the '<em><b>Delivery</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__DELIVERY = 7;

	/**
	 * The feature id for the '<em><b>Status Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__STATUS_ID = 8;

	/**
	 * The feature id for the '<em><b>Status</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__STATUS = 9;

	/**
	 * The feature id for the '<em><b>Agent Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__AGENT_ID = 10;

	/**
	 * The feature id for the '<em><b>Payment Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__PAYMENT_ID = 11;

	/**
	 * The feature id for the '<em><b>Promotion Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__PROMOTION_ID = 12;

	/**
	 * The feature id for the '<em><b>Discounts</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__DISCOUNTS = 13;

	/**
	 * The feature id for the '<em><b>Customer Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__CUSTOMER_ID = 14;

	/**
	 * The feature id for the '<em><b>Transactions</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__TRANSACTIONS = 15;

	/**
	 * The feature id for the '<em><b>Payments Info</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__PAYMENTS_INFO = 16;

	/**
	 * The feature id for the '<em><b>Catalog</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER__CATALOG = 17;

	/**
	 * The number of structural features of the '<em>Order</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEATURE_COUNT = 18;

	/**
	 * The operation id for the '<em>Set Order Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___SET_ORDER_ID = 0;

	/**
	 * The operation id for the '<em>Set Order Price</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___SET_ORDER_PRICE = 1;

	/**
	 * The operation id for the '<em>Set Instructions</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___SET_INSTRUCTIONS = 2;

	/**
	 * The operation id for the '<em>Set Discounted Price</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___SET_DISCOUNTED_PRICE = 3;

	/**
	 * The operation id for the '<em>Set Source Location Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___SET_SOURCE_LOCATION_ID = 4;

	/**
	 * The operation id for the '<em>Set Tax</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___SET_TAX = 5;

	/**
	 * The operation id for the '<em>Set Delivery Fee</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___SET_DELIVERY_FEE = 6;

	/**
	 * The operation id for the '<em>Set Oder Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___SET_ODER_ID = 7;

	/**
	 * The operation id for the '<em>Get Tax</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___GET_TAX = 8;

	/**
	 * The operation id for the '<em>Get Delivery Fee</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER___GET_DELIVERY_FEE = 9;

	/**
	 * The number of operations of the '<em>Order</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_OPERATION_COUNT = 10;

	/**
	 * The meta object id for the '{@link test1.impl.StatusImpl <em>Status</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.StatusImpl
	 * @see test1.impl.Test1PackageImpl#getStatus()
	 * @generated
	 */
	int STATUS = 12;

	/**
	 * The feature id for the '<em><b>Status Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS__STATUS_ID = 0;

	/**
	 * The feature id for the '<em><b>Status Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS__STATUS_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Transactions</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS__TRANSACTIONS = 2;

	/**
	 * The feature id for the '<em><b>Order</b></em>' container reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS__ORDER = 3;

	/**
	 * The number of structural features of the '<em>Status</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Status Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS___SET_STATUS_ID = 1;

	/**
	 * The operation id for the '<em>Set Status Type</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS___SET_STATUS_TYPE = 2;

	/**
	 * The operation id for the '<em>Get Status Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS___GET_STATUS_ID = 3;

	/**
	 * The operation id for the '<em>Get Status Type</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS___GET_STATUS_TYPE = 4;

	/**
	 * The number of operations of the '<em>Status</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS_OPERATION_COUNT = 5;

	/**
	 * The meta object id for the '{@link test1.impl.DiscountsImpl <em>Discounts</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.DiscountsImpl
	 * @see test1.impl.Test1PackageImpl#getDiscounts()
	 * @generated
	 */
	int DISCOUNTS = 13;

	/**
	 * The feature id for the '<em><b>Promotion Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS__PROMOTION_ID = 0;

	/**
	 * The feature id for the '<em><b>Promotion Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS__PROMOTION_NAME = 1;

	/**
	 * The feature id for the '<em><b>Promotion Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS__PROMOTION_CODE = 2;

	/**
	 * The feature id for the '<em><b>Order</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS__ORDER = 3;

	/**
	 * The number of structural features of the '<em>Discounts</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>Set Promotion Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS___SET_PROMOTION_ID = 0;

	/**
	 * The operation id for the '<em>Set Promotion Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS___SET_PROMOTION_NAME = 1;

	/**
	 * The operation id for the '<em>Set Promotion Code</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS___SET_PROMOTION_CODE = 2;

	/**
	 * The operation id for the '<em>Get Promotion Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS___GET_PROMOTION_ID = 3;

	/**
	 * The operation id for the '<em>Get Promotion Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS___GET_PROMOTION_NAME = 4;

	/**
	 * The operation id for the '<em>Get Promotion Code</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS___GET_PROMOTION_CODE = 5;

	/**
	 * The number of operations of the '<em>Discounts</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCOUNTS_OPERATION_COUNT = 6;

	/**
	 * The meta object id for the '{@link test1.impl.CatalogImpl <em>Catalog</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.CatalogImpl
	 * @see test1.impl.Test1PackageImpl#getCatalog()
	 * @generated
	 */
	int CATALOG = 14;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG__PRICE = 0;

	/**
	 * The feature id for the '<em><b>Product Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG__PRODUCT_ID = 1;

	/**
	 * The feature id for the '<em><b>Product</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG__PRODUCT = 2;

	/**
	 * The feature id for the '<em><b>Order</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG__ORDER = 3;

	/**
	 * The number of structural features of the '<em>Catalog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Price</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG___SET_PRICE = 1;

	/**
	 * The operation id for the '<em>Get Price</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG___GET_PRICE = 2;

	/**
	 * The number of operations of the '<em>Catalog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOG_OPERATION_COUNT = 3;

	/**
	 * The meta object id for the '{@link test1.impl.ProductImpl <em>Product</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.ProductImpl
	 * @see test1.impl.Test1PackageImpl#getProduct()
	 * @generated
	 */
	int PRODUCT = 15;

	/**
	 * The feature id for the '<em><b>Product Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__PRODUCT_ID = 0;

	/**
	 * The feature id for the '<em><b>Product Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__PRODUCT_NAME = 1;

	/**
	 * The feature id for the '<em><b>Product Descripton</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__PRODUCT_DESCRIPTON = 2;

	/**
	 * The feature id for the '<em><b>Category Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__CATEGORY_ID = 3;

	/**
	 * The feature id for the '<em><b>Product Category</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__PRODUCT_CATEGORY = 4;

	/**
	 * The feature id for the '<em><b>Order Items Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__ORDER_ITEMS_ID = 5;

	/**
	 * The feature id for the '<em><b>Order Items</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__ORDER_ITEMS = 6;

	/**
	 * The feature id for the '<em><b>Catalog</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__CATALOG = 7;

	/**
	 * The number of structural features of the '<em>Product</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_FEATURE_COUNT = 8;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Product Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT___SET_PRODUCT_ID = 1;

	/**
	 * The operation id for the '<em>Set Product Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT___SET_PRODUCT_NAME = 2;

	/**
	 * The operation id for the '<em>Set Product Description</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT___SET_PRODUCT_DESCRIPTION = 3;

	/**
	 * The operation id for the '<em>Get Product Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT___GET_PRODUCT_ID = 4;

	/**
	 * The operation id for the '<em>Get Product Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT___GET_PRODUCT_NAME = 5;

	/**
	 * The operation id for the '<em>Get Product Description</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT___GET_PRODUCT_DESCRIPTION = 6;

	/**
	 * The number of operations of the '<em>Product</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_OPERATION_COUNT = 7;

	/**
	 * The meta object id for the '{@link test1.impl.ProductCategoryImpl <em>Product Category</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.ProductCategoryImpl
	 * @see test1.impl.Test1PackageImpl#getProductCategory()
	 * @generated
	 */
	int PRODUCT_CATEGORY = 16;

	/**
	 * The feature id for the '<em><b>Category Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY__CATEGORY_ID = 0;

	/**
	 * The feature id for the '<em><b>Category Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY__CATEGORY_NAME = 1;

	/**
	 * The feature id for the '<em><b>Product</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY__PRODUCT = 2;

	/**
	 * The number of structural features of the '<em>Product Category</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Category Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY___SET_CATEGORY_ID = 1;

	/**
	 * The operation id for the '<em>Set Category Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY___SET_CATEGORY_NAME = 2;

	/**
	 * The operation id for the '<em>Get Category Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY___GET_CATEGORY_ID = 3;

	/**
	 * The operation id for the '<em>Getcategory Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY___GETCATEGORY_NAME = 4;

	/**
	 * The number of operations of the '<em>Product Category</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_CATEGORY_OPERATION_COUNT = 5;

	/**
	 * The meta object id for the '{@link test1.impl.OrderItemsImpl <em>Order Items</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.OrderItemsImpl
	 * @see test1.impl.Test1PackageImpl#getOrderItems()
	 * @generated
	 */
	int ORDER_ITEMS = 17;

	/**
	 * The feature id for the '<em><b>Order Items Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS__ORDER_ITEMS_ID = 0;

	/**
	 * The feature id for the '<em><b>Product Quantity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS__PRODUCT_QUANTITY = 1;

	/**
	 * The feature id for the '<em><b>Product Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS__PRODUCT_ID = 2;

	/**
	 * The feature id for the '<em><b>Order Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS__ORDER_ID = 3;

	/**
	 * The feature id for the '<em><b>Product</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS__PRODUCT = 4;

	/**
	 * The number of structural features of the '<em>Order Items</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Order Items Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS___SET_ORDER_ITEMS_ID = 1;

	/**
	 * The operation id for the '<em>Set Product Quantity</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS___SET_PRODUCT_QUANTITY = 2;

	/**
	 * The operation id for the '<em>Get Order Items Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS___GET_ORDER_ITEMS_ID = 3;

	/**
	 * The operation id for the '<em>Get Product Quantity</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS___GET_PRODUCT_QUANTITY = 4;

	/**
	 * The number of operations of the '<em>Order Items</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_ITEMS_OPERATION_COUNT = 5;

	/**
	 * The meta object id for the '{@link test1.impl.RatingsImpl <em>Ratings</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.RatingsImpl
	 * @see test1.impl.Test1PackageImpl#getRatings()
	 * @generated
	 */
	int RATINGS = 18;

	/**
	 * The feature id for the '<em><b>Rating Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS__RATING_ID = 0;

	/**
	 * The feature id for the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS__RATING = 1;

	/**
	 * The feature id for the '<em><b>Orderfeedback</b></em>' container reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS__ORDERFEEDBACK = 2;

	/**
	 * The number of structural features of the '<em>Ratings</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Set Rating Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS___SET_RATING_ID = 1;

	/**
	 * The operation id for the '<em>Set Rating</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS___SET_RATING = 2;

	/**
	 * The operation id for the '<em>Get Rating Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS___GET_RATING_ID = 3;

	/**
	 * The operation id for the '<em>Get Rating</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS___GET_RATING = 4;

	/**
	 * The number of operations of the '<em>Ratings</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RATINGS_OPERATION_COUNT = 5;

	/**
	 * The meta object id for the '{@link test1.impl.OrderFeedbackImpl <em>Order Feedback</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.OrderFeedbackImpl
	 * @see test1.impl.Test1PackageImpl#getOrderFeedback()
	 * @generated
	 */
	int ORDER_FEEDBACK = 19;

	/**
	 * The feature id for the '<em><b>Product Feedback</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK__PRODUCT_FEEDBACK = 0;

	/**
	 * The feature id for the '<em><b>Delivery Agent Feedback</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK__DELIVERY_AGENT_FEEDBACK = 1;

	/**
	 * The feature id for the '<em><b>Product Rating Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK__PRODUCT_RATING_ID = 2;

	/**
	 * The feature id for the '<em><b>Delivery Agent Rating Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID = 3;

	/**
	 * The feature id for the '<em><b>Rating Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK__RATING_ID = 4;

	/**
	 * The feature id for the '<em><b>Order Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK__ORDER_ID = 5;

	/**
	 * The feature id for the '<em><b>Ratings</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK__RATINGS = 6;

	/**
	 * The number of structural features of the '<em>Order Feedback</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK_FEATURE_COUNT = 7;

	/**
	 * The operation id for the '<em>Set Product Feedback</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK___SET_PRODUCT_FEEDBACK = 0;

	/**
	 * The operation id for the '<em>Set Delivery Agent Feedback</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK___SET_DELIVERY_AGENT_FEEDBACK = 1;

	/**
	 * The operation id for the '<em>Set Product Rating Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK___SET_PRODUCT_RATING_ID = 2;

	/**
	 * The operation id for the '<em>Set Delivery Agent Rating Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK___SET_DELIVERY_AGENT_RATING_ID = 3;

	/**
	 * The operation id for the '<em>Get Product Feedback</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK___GET_PRODUCT_FEEDBACK = 4;

	/**
	 * The operation id for the '<em>Get Delivery Agent Feedback</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK___GET_DELIVERY_AGENT_FEEDBACK = 5;

	/**
	 * The operation id for the '<em>Get Product Rating Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK___GET_PRODUCT_RATING_ID = 6;

	/**
	 * The operation id for the '<em>Get Delivery Agent Rating Id</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK___GET_DELIVERY_AGENT_RATING_ID = 7;

	/**
	 * The number of operations of the '<em>Order Feedback</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ORDER_FEEDBACK_OPERATION_COUNT = 8;

	/**
	 * The meta object id for the '{@link test1.impl.PrimitiveTypesDateImpl <em>Primitive Types Date</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.PrimitiveTypesDateImpl
	 * @see test1.impl.Test1PackageImpl#getPrimitiveTypesDate()
	 * @generated
	 */
	int PRIMITIVE_TYPES_DATE = 20;

	/**
	 * The number of structural features of the '<em>Primitive Types Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMITIVE_TYPES_DATE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Primitive Types Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMITIVE_TYPES_DATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.test1DateImpl
	 * @see test1.impl.Test1PackageImpl#gettest1Date()
	 * @generated
	 */
	int TEST1_DATE = 21;

	/**
	 * The number of structural features of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.test1DateImpl
	 * @see test1.impl.Test1PackageImpl#gettest1Date()
	 * @generated
	 */
	int TEST1_DATE = 22;

	/**
	 * The number of structural features of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.test1DateImpl
	 * @see test1.impl.Test1PackageImpl#gettest1Date()
	 * @generated
	 */
	int TEST1_DATE = 22;

	/**
	 * The number of structural features of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.test1DateImpl
	 * @see test1.impl.Test1PackageImpl#gettest1Date()
	 * @generated
	 */
	int TEST1_DATE = 22;

	/**
	 * The number of structural features of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.impl.test1DateImpl
	 * @see test1.impl.Test1PackageImpl#gettest1Date()
	 * @generated
	 */
	int TEST1_DATE = 22;

	/**
	 * The number of structural features of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>test1 Date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST1_DATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link test1.Gender <em>Gender</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see test1.Gender
	 * @see test1.impl.Test1PackageImpl#getGender()
	 * @generated
	 */
	int GENDER = 23;


	/**
	 * Returns the meta object for class '{@link test1.Card <em>Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Card</em>'.
	 * @see test1.Card
	 * @generated
	 */
	EClass getCard();

	/**
	 * Returns the meta object for the attribute '{@link test1.Card#getCardId <em>Card Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Card Id</em>'.
	 * @see test1.Card#getCardId()
	 * @see #getCard()
	 * @generated
	 */
	EAttribute getCard_CardId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Card#getCardType <em>Card Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Card Type</em>'.
	 * @see test1.Card#getCardType()
	 * @see #getCard()
	 * @generated
	 */
	EAttribute getCard_CardType();

	/**
	 * Returns the meta object for the reference list '{@link test1.Card#getPaymentsInfo <em>Payments Info</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Payments Info</em>'.
	 * @see test1.Card#getPaymentsInfo()
	 * @see #getCard()
	 * @generated
	 */
	EReference getCard_PaymentsInfo();

	/**
	 * Returns the meta object for the '{@link test1.Card#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.Card#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getCard__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.Card#setCardId() <em>Set Card Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Card Id</em>' operation.
	 * @see test1.Card#setCardId()
	 * @generated
	 */
	EOperation getCard__SetCardId();

	/**
	 * Returns the meta object for the '{@link test1.Card#setCardType() <em>Set Card Type</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Card Type</em>' operation.
	 * @see test1.Card#setCardType()
	 * @generated
	 */
	EOperation getCard__SetCardType();

	/**
	 * Returns the meta object for the '{@link test1.Card#getCardId() <em>Get Card Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Card Id</em>' operation.
	 * @see test1.Card#getCardId()
	 * @generated
	 */
	EOperation getCard__GetCardId();

	/**
	 * Returns the meta object for the '{@link test1.Card#getCardType() <em>Get Card Type</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Card Type</em>' operation.
	 * @see test1.Card#getCardType()
	 * @generated
	 */
	EOperation getCard__GetCardType();

	/**
	 * Returns the meta object for class '{@link test1.PaymentsInfo <em>Payments Info</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Payments Info</em>'.
	 * @see test1.PaymentsInfo
	 * @generated
	 */
	EClass getPaymentsInfo();

	/**
	 * Returns the meta object for the attribute '{@link test1.PaymentsInfo#getPaymentId <em>Payment Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Payment Id</em>'.
	 * @see test1.PaymentsInfo#getPaymentId()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EAttribute getPaymentsInfo_PaymentId();

	/**
	 * Returns the meta object for the attribute '{@link test1.PaymentsInfo#getCardNo <em>Card No</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Card No</em>'.
	 * @see test1.PaymentsInfo#getCardNo()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EAttribute getPaymentsInfo_CardNo();

	/**
	 * Returns the meta object for the attribute '{@link test1.PaymentsInfo#getExpiryDate <em>Expiry Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Expiry Date</em>'.
	 * @see test1.PaymentsInfo#getExpiryDate()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EAttribute getPaymentsInfo_ExpiryDate();

	/**
	 * Returns the meta object for the attribute '{@link test1.PaymentsInfo#getCardHolderName <em>Card Holder Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Card Holder Name</em>'.
	 * @see test1.PaymentsInfo#getCardHolderName()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EAttribute getPaymentsInfo_CardHolderName();

	/**
	 * Returns the meta object for the attribute '{@link test1.PaymentsInfo#getCvv <em>Cvv</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cvv</em>'.
	 * @see test1.PaymentsInfo#getCvv()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EAttribute getPaymentsInfo_Cvv();

	/**
	 * Returns the meta object for the reference '{@link test1.PaymentsInfo#getCardId <em>Card Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Card Id</em>'.
	 * @see test1.PaymentsInfo#getCardId()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EReference getPaymentsInfo_CardId();

	/**
	 * Returns the meta object for the reference '{@link test1.PaymentsInfo#getUserId <em>User Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User Id</em>'.
	 * @see test1.PaymentsInfo#getUserId()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EReference getPaymentsInfo_UserId();

	/**
	 * Returns the meta object for the container reference list '{@link test1.PaymentsInfo#getTransactions <em>Transactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference list '<em>Transactions</em>'.
	 * @see test1.PaymentsInfo#getTransactions()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EReference getPaymentsInfo_Transactions();

	/**
	 * Returns the meta object for the reference '{@link test1.PaymentsInfo#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Order</em>'.
	 * @see test1.PaymentsInfo#getOrder()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EReference getPaymentsInfo_Order();

	/**
	 * Returns the meta object for the reference '{@link test1.PaymentsInfo#getCard <em>Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Card</em>'.
	 * @see test1.PaymentsInfo#getCard()
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	EReference getPaymentsInfo_Card();

	/**
	 * Returns the meta object for the '{@link test1.PaymentsInfo#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.PaymentsInfo#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getPaymentsInfo__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.PaymentsInfo#setCardNo() <em>Set Card No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Card No</em>' operation.
	 * @see test1.PaymentsInfo#setCardNo()
	 * @generated
	 */
	EOperation getPaymentsInfo__SetCardNo();

	/**
	 * Returns the meta object for the '{@link test1.PaymentsInfo#setExpiryDate() <em>Set Expiry Date</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Expiry Date</em>' operation.
	 * @see test1.PaymentsInfo#setExpiryDate()
	 * @generated
	 */
	EOperation getPaymentsInfo__SetExpiryDate();

	/**
	 * Returns the meta object for the '{@link test1.PaymentsInfo#setCardHolderName() <em>Set Card Holder Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Card Holder Name</em>' operation.
	 * @see test1.PaymentsInfo#setCardHolderName()
	 * @generated
	 */
	EOperation getPaymentsInfo__SetCardHolderName();

	/**
	 * Returns the meta object for the '{@link test1.PaymentsInfo#setCvv() <em>Set Cvv</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Cvv</em>' operation.
	 * @see test1.PaymentsInfo#setCvv()
	 * @generated
	 */
	EOperation getPaymentsInfo__SetCvv();

	/**
	 * Returns the meta object for the '{@link test1.PaymentsInfo#getCardNo() <em>Get Card No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Card No</em>' operation.
	 * @see test1.PaymentsInfo#getCardNo()
	 * @generated
	 */
	EOperation getPaymentsInfo__GetCardNo();

	/**
	 * Returns the meta object for the '{@link test1.PaymentsInfo#getExpiryDate() <em>Get Expiry Date</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Expiry Date</em>' operation.
	 * @see test1.PaymentsInfo#getExpiryDate()
	 * @generated
	 */
	EOperation getPaymentsInfo__GetExpiryDate();

	/**
	 * Returns the meta object for the '{@link test1.PaymentsInfo#getCardHolderName() <em>Get Card Holder Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Card Holder Name</em>' operation.
	 * @see test1.PaymentsInfo#getCardHolderName()
	 * @generated
	 */
	EOperation getPaymentsInfo__GetCardHolderName();

	/**
	 * Returns the meta object for class '{@link test1.UserDetails <em>User Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>User Details</em>'.
	 * @see test1.UserDetails
	 * @generated
	 */
	EClass getUserDetails();

	/**
	 * Returns the meta object for the attribute '{@link test1.UserDetails#getUserId <em>User Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>User Id</em>'.
	 * @see test1.UserDetails#getUserId()
	 * @see #getUserDetails()
	 * @generated
	 */
	EAttribute getUserDetails_UserId();

	/**
	 * Returns the meta object for the attribute '{@link test1.UserDetails#getUsername <em>Username</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Username</em>'.
	 * @see test1.UserDetails#getUsername()
	 * @see #getUserDetails()
	 * @generated
	 */
	EAttribute getUserDetails_Username();

	/**
	 * Returns the meta object for the attribute '{@link test1.UserDetails#getPassword <em>Password</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Password</em>'.
	 * @see test1.UserDetails#getPassword()
	 * @see #getUserDetails()
	 * @generated
	 */
	EAttribute getUserDetails_Password();

	/**
	 * Returns the meta object for the container reference '{@link test1.UserDetails#getDeliveryAgent <em>Delivery Agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Delivery Agent</em>'.
	 * @see test1.UserDetails#getDeliveryAgent()
	 * @see #getUserDetails()
	 * @generated
	 */
	EReference getUserDetails_DeliveryAgent();

	/**
	 * Returns the meta object for the container reference '{@link test1.UserDetails#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Customer</em>'.
	 * @see test1.UserDetails#getCustomer()
	 * @see #getUserDetails()
	 * @generated
	 */
	EReference getUserDetails_Customer();

	/**
	 * Returns the meta object for the reference list '{@link test1.UserDetails#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Address</em>'.
	 * @see test1.UserDetails#getAddress()
	 * @see #getUserDetails()
	 * @generated
	 */
	EReference getUserDetails_Address();

	/**
	 * Returns the meta object for the '{@link test1.UserDetails#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.UserDetails#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getUserDetails__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.UserDetails#setUserId() <em>Set User Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set User Id</em>' operation.
	 * @see test1.UserDetails#setUserId()
	 * @generated
	 */
	EOperation getUserDetails__SetUserId();

	/**
	 * Returns the meta object for the '{@link test1.UserDetails#setUsername() <em>Set Username</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Username</em>' operation.
	 * @see test1.UserDetails#setUsername()
	 * @generated
	 */
	EOperation getUserDetails__SetUsername();

	/**
	 * Returns the meta object for the '{@link test1.UserDetails#setPassword() <em>Set Password</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Password</em>' operation.
	 * @see test1.UserDetails#setPassword()
	 * @generated
	 */
	EOperation getUserDetails__SetPassword();

	/**
	 * Returns the meta object for the '{@link test1.UserDetails#getUserId() <em>Get User Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get User Id</em>' operation.
	 * @see test1.UserDetails#getUserId()
	 * @generated
	 */
	EOperation getUserDetails__GetUserId();

	/**
	 * Returns the meta object for the '{@link test1.UserDetails#getUsername() <em>Get Username</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Username</em>' operation.
	 * @see test1.UserDetails#getUsername()
	 * @generated
	 */
	EOperation getUserDetails__GetUsername();

	/**
	 * Returns the meta object for class '{@link test1.DeliveryAgent <em>Delivery Agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Delivery Agent</em>'.
	 * @see test1.DeliveryAgent
	 * @generated
	 */
	EClass getDeliveryAgent();

	/**
	 * Returns the meta object for the attribute '{@link test1.DeliveryAgent#getAgentId <em>Agent Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Agent Id</em>'.
	 * @see test1.DeliveryAgent#getAgentId()
	 * @see #getDeliveryAgent()
	 * @generated
	 */
	EAttribute getDeliveryAgent_AgentId();

	/**
	 * Returns the meta object for the attribute '{@link test1.DeliveryAgent#getContactNo <em>Contact No</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Contact No</em>'.
	 * @see test1.DeliveryAgent#getContactNo()
	 * @see #getDeliveryAgent()
	 * @generated
	 */
	EAttribute getDeliveryAgent_ContactNo();

	/**
	 * Returns the meta object for the attribute '{@link test1.DeliveryAgent#getSsn <em>Ssn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ssn</em>'.
	 * @see test1.DeliveryAgent#getSsn()
	 * @see #getDeliveryAgent()
	 * @generated
	 */
	EAttribute getDeliveryAgent_Ssn();

	/**
	 * Returns the meta object for the attribute '{@link test1.DeliveryAgent#getDrivingLicenseNo <em>Driving License No</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Driving License No</em>'.
	 * @see test1.DeliveryAgent#getDrivingLicenseNo()
	 * @see #getDeliveryAgent()
	 * @generated
	 */
	EAttribute getDeliveryAgent_DrivingLicenseNo();

	/**
	 * Returns the meta object for the reference '{@link test1.DeliveryAgent#getUserId <em>User Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User Id</em>'.
	 * @see test1.DeliveryAgent#getUserId()
	 * @see #getDeliveryAgent()
	 * @generated
	 */
	EReference getDeliveryAgent_UserId();

	/**
	 * Returns the meta object for the containment reference '{@link test1.DeliveryAgent#getUserDetails <em>User Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>User Details</em>'.
	 * @see test1.DeliveryAgent#getUserDetails()
	 * @see #getDeliveryAgent()
	 * @generated
	 */
	EReference getDeliveryAgent_UserDetails();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.DeliveryAgent#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getDeliveryAgent__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#setAgentId() <em>Set Agent Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Agent Id</em>' operation.
	 * @see test1.DeliveryAgent#setAgentId()
	 * @generated
	 */
	EOperation getDeliveryAgent__SetAgentId();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#setContactNo() <em>Set Contact No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Contact No</em>' operation.
	 * @see test1.DeliveryAgent#setContactNo()
	 * @generated
	 */
	EOperation getDeliveryAgent__SetContactNo();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#setSsn() <em>Set Ssn</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Ssn</em>' operation.
	 * @see test1.DeliveryAgent#setSsn()
	 * @generated
	 */
	EOperation getDeliveryAgent__SetSsn();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#setDrivingLicenseNo() <em>Set Driving License No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Driving License No</em>' operation.
	 * @see test1.DeliveryAgent#setDrivingLicenseNo()
	 * @generated
	 */
	EOperation getDeliveryAgent__SetDrivingLicenseNo();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#getAgentId() <em>Get Agent Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Agent Id</em>' operation.
	 * @see test1.DeliveryAgent#getAgentId()
	 * @generated
	 */
	EOperation getDeliveryAgent__GetAgentId();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#getContactNo() <em>Get Contact No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Contact No</em>' operation.
	 * @see test1.DeliveryAgent#getContactNo()
	 * @generated
	 */
	EOperation getDeliveryAgent__GetContactNo();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#getSsn() <em>Get Ssn</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Ssn</em>' operation.
	 * @see test1.DeliveryAgent#getSsn()
	 * @generated
	 */
	EOperation getDeliveryAgent__GetSsn();

	/**
	 * Returns the meta object for the '{@link test1.DeliveryAgent#getDrivingLicenseNo() <em>Get Driving License No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Driving License No</em>' operation.
	 * @see test1.DeliveryAgent#getDrivingLicenseNo()
	 * @generated
	 */
	EOperation getDeliveryAgent__GetDrivingLicenseNo();

	/**
	 * Returns the meta object for class '{@link test1.Person <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Person</em>'.
	 * @see test1.Person
	 * @generated
	 */
	EClass getPerson();

	/**
	 * Returns the meta object for the attribute '{@link test1.Person#getFirstName <em>First Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>First Name</em>'.
	 * @see test1.Person#getFirstName()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_FirstName();

	/**
	 * Returns the meta object for the attribute '{@link test1.Person#getLastName <em>Last Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Name</em>'.
	 * @see test1.Person#getLastName()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_LastName();

	/**
	 * Returns the meta object for the attribute '{@link test1.Person#getSex <em>Sex</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sex</em>'.
	 * @see test1.Person#getSex()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_Sex();

	/**
	 * Returns the meta object for the containment reference '{@link test1.Person#getDateOfBirth <em>Date Of Birth</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Date Of Birth</em>'.
	 * @see test1.Person#getDateOfBirth()
	 * @see #getPerson()
	 * @generated
	 */
	EReference getPerson_DateOfBirth();

	/**
	 * Returns the meta object for the attribute '{@link test1.Person#getGender <em>Gender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Gender</em>'.
	 * @see test1.Person#getGender()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_Gender();

	/**
	 * Returns the meta object for the '{@link test1.Person#setFirstName() <em>Set First Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set First Name</em>' operation.
	 * @see test1.Person#setFirstName()
	 * @generated
	 */
	EOperation getPerson__SetFirstName();

	/**
	 * Returns the meta object for the '{@link test1.Person#setLastName() <em>Set Last Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Last Name</em>' operation.
	 * @see test1.Person#setLastName()
	 * @generated
	 */
	EOperation getPerson__SetLastName();

	/**
	 * Returns the meta object for the '{@link test1.Person#setDateOfBirth() <em>Set Date Of Birth</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Date Of Birth</em>' operation.
	 * @see test1.Person#setDateOfBirth()
	 * @generated
	 */
	EOperation getPerson__SetDateOfBirth();

	/**
	 * Returns the meta object for the '{@link test1.Person#getFirstName() <em>Get First Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get First Name</em>' operation.
	 * @see test1.Person#getFirstName()
	 * @generated
	 */
	EOperation getPerson__GetFirstName();

	/**
	 * Returns the meta object for the '{@link test1.Person#getLastName() <em>Get Last Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Last Name</em>' operation.
	 * @see test1.Person#getLastName()
	 * @generated
	 */
	EOperation getPerson__GetLastName();

	/**
	 * Returns the meta object for the '{@link test1.Person#getDateOfBirth() <em>Get Date Of Birth</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Date Of Birth</em>' operation.
	 * @see test1.Person#getDateOfBirth()
	 * @generated
	 */
	EOperation getPerson__GetDateOfBirth();

	/**
	 * Returns the meta object for class '{@link test1.Date <em>Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Date</em>'.
	 * @see test1.Date
	 * @generated
	 */
	EClass getDate();

	/**
	 * Returns the meta object for class '{@link test1.Customer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Customer</em>'.
	 * @see test1.Customer
	 * @generated
	 */
	EClass getCustomer();

	/**
	 * Returns the meta object for the attribute '{@link test1.Customer#getCustomerId <em>Customer Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Customer Id</em>'.
	 * @see test1.Customer#getCustomerId()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_CustomerId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Customer#getEmailId <em>Email Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Email Id</em>'.
	 * @see test1.Customer#getEmailId()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_EmailId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Customer#getContactNo <em>Contact No</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Contact No</em>'.
	 * @see test1.Customer#getContactNo()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_ContactNo();

	/**
	 * Returns the meta object for the reference '{@link test1.Customer#getUserId <em>User Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User Id</em>'.
	 * @see test1.Customer#getUserId()
	 * @see #getCustomer()
	 * @generated
	 */
	EReference getCustomer_UserId();

	/**
	 * Returns the meta object for the containment reference '{@link test1.Customer#getUserDetails <em>User Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>User Details</em>'.
	 * @see test1.Customer#getUserDetails()
	 * @see #getCustomer()
	 * @generated
	 */
	EReference getCustomer_UserDetails();

	/**
	 * Returns the meta object for the '{@link test1.Customer#setUserId() <em>Set User Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set User Id</em>' operation.
	 * @see test1.Customer#setUserId()
	 * @generated
	 */
	EOperation getCustomer__SetUserId();

	/**
	 * Returns the meta object for the '{@link test1.Customer#setCustomerId() <em>Set Customer Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Customer Id</em>' operation.
	 * @see test1.Customer#setCustomerId()
	 * @generated
	 */
	EOperation getCustomer__SetCustomerId();

	/**
	 * Returns the meta object for the '{@link test1.Customer#setEmailId() <em>Set Email Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Email Id</em>' operation.
	 * @see test1.Customer#setEmailId()
	 * @generated
	 */
	EOperation getCustomer__SetEmailId();

	/**
	 * Returns the meta object for the '{@link test1.Customer#setContactNo() <em>Set Contact No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Contact No</em>' operation.
	 * @see test1.Customer#setContactNo()
	 * @generated
	 */
	EOperation getCustomer__SetContactNo();

	/**
	 * Returns the meta object for the '{@link test1.Customer#getCustomerId() <em>Get Customer Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Customer Id</em>' operation.
	 * @see test1.Customer#getCustomerId()
	 * @generated
	 */
	EOperation getCustomer__GetCustomerId();

	/**
	 * Returns the meta object for the '{@link test1.Customer#getEmailId() <em>Get Email Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Email Id</em>' operation.
	 * @see test1.Customer#getEmailId()
	 * @generated
	 */
	EOperation getCustomer__GetEmailId();

	/**
	 * Returns the meta object for the '{@link test1.Customer#getContactNo() <em>Get Contact No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Contact No</em>' operation.
	 * @see test1.Customer#getContactNo()
	 * @generated
	 */
	EOperation getCustomer__GetContactNo();

	/**
	 * Returns the meta object for class '{@link test1.Address <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Address</em>'.
	 * @see test1.Address
	 * @generated
	 */
	EClass getAddress();

	/**
	 * Returns the meta object for the attribute '{@link test1.Address#getAddressType <em>Address Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Address Type</em>'.
	 * @see test1.Address#getAddressType()
	 * @see #getAddress()
	 * @generated
	 */
	EAttribute getAddress_AddressType();

	/**
	 * Returns the meta object for the reference '{@link test1.Address#getLocationId <em>Location Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Location Id</em>'.
	 * @see test1.Address#getLocationId()
	 * @see #getAddress()
	 * @generated
	 */
	EReference getAddress_LocationId();

	/**
	 * Returns the meta object for the reference '{@link test1.Address#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Location</em>'.
	 * @see test1.Address#getLocation()
	 * @see #getAddress()
	 * @generated
	 */
	EReference getAddress_Location();

	/**
	 * Returns the meta object for the reference '{@link test1.Address#getUserId <em>User Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User Id</em>'.
	 * @see test1.Address#getUserId()
	 * @see #getAddress()
	 * @generated
	 */
	EReference getAddress_UserId();

	/**
	 * Returns the meta object for the reference '{@link test1.Address#getUserDetails <em>User Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User Details</em>'.
	 * @see test1.Address#getUserDetails()
	 * @see #getAddress()
	 * @generated
	 */
	EReference getAddress_UserDetails();

	/**
	 * Returns the meta object for the '{@link test1.Address#setAddressType() <em>Set Address Type</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Address Type</em>' operation.
	 * @see test1.Address#setAddressType()
	 * @generated
	 */
	EOperation getAddress__SetAddressType();

	/**
	 * Returns the meta object for the '{@link test1.Address#getAddressType() <em>Get Address Type</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Address Type</em>' operation.
	 * @see test1.Address#getAddressType()
	 * @generated
	 */
	EOperation getAddress__GetAddressType();

	/**
	 * Returns the meta object for class '{@link test1.Location <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Location</em>'.
	 * @see test1.Location
	 * @generated
	 */
	EClass getLocation();

	/**
	 * Returns the meta object for the attribute '{@link test1.Location#getLocationId <em>Location Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location Id</em>'.
	 * @see test1.Location#getLocationId()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_LocationId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Location#getStreetName <em>Street Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Street Name</em>'.
	 * @see test1.Location#getStreetName()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_StreetName();

	/**
	 * Returns the meta object for the attribute '{@link test1.Location#getHouseNo <em>House No</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>House No</em>'.
	 * @see test1.Location#getHouseNo()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_HouseNo();

	/**
	 * Returns the meta object for the reference '{@link test1.Location#getZip <em>Zip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Zip</em>'.
	 * @see test1.Location#getZip()
	 * @see #getLocation()
	 * @generated
	 */
	EReference getLocation_Zip();

	/**
	 * Returns the meta object for the reference '{@link test1.Location#getZipcode <em>Zipcode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Zipcode</em>'.
	 * @see test1.Location#getZipcode()
	 * @see #getLocation()
	 * @generated
	 */
	EReference getLocation_Zipcode();

	/**
	 * Returns the meta object for the reference list '{@link test1.Location#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Address</em>'.
	 * @see test1.Location#getAddress()
	 * @see #getLocation()
	 * @generated
	 */
	EReference getLocation_Address();

	/**
	 * Returns the meta object for the '{@link test1.Location#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.Location#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getLocation__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.Location#setLocation() <em>Set Location</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Location</em>' operation.
	 * @see test1.Location#setLocation()
	 * @generated
	 */
	EOperation getLocation__SetLocation();

	/**
	 * Returns the meta object for the '{@link test1.Location#setStreetName() <em>Set Street Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Street Name</em>' operation.
	 * @see test1.Location#setStreetName()
	 * @generated
	 */
	EOperation getLocation__SetStreetName();

	/**
	 * Returns the meta object for the '{@link test1.Location#setHouseNo() <em>Set House No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set House No</em>' operation.
	 * @see test1.Location#setHouseNo()
	 * @generated
	 */
	EOperation getLocation__SetHouseNo();

	/**
	 * Returns the meta object for the '{@link test1.Location#getLocationId() <em>Get Location Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Location Id</em>' operation.
	 * @see test1.Location#getLocationId()
	 * @generated
	 */
	EOperation getLocation__GetLocationId();

	/**
	 * Returns the meta object for the '{@link test1.Location#getStreetName() <em>Get Street Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Street Name</em>' operation.
	 * @see test1.Location#getStreetName()
	 * @generated
	 */
	EOperation getLocation__GetStreetName();

	/**
	 * Returns the meta object for the '{@link test1.Location#getHouseNo() <em>Get House No</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get House No</em>' operation.
	 * @see test1.Location#getHouseNo()
	 * @generated
	 */
	EOperation getLocation__GetHouseNo();

	/**
	 * Returns the meta object for class '{@link test1.Zipcode <em>Zipcode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Zipcode</em>'.
	 * @see test1.Zipcode
	 * @generated
	 */
	EClass getZipcode();

	/**
	 * Returns the meta object for the attribute '{@link test1.Zipcode#getZip <em>Zip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Zip</em>'.
	 * @see test1.Zipcode#getZip()
	 * @see #getZipcode()
	 * @generated
	 */
	EAttribute getZipcode_Zip();

	/**
	 * Returns the meta object for the attribute '{@link test1.Zipcode#getCity <em>City</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>City</em>'.
	 * @see test1.Zipcode#getCity()
	 * @see #getZipcode()
	 * @generated
	 */
	EAttribute getZipcode_City();

	/**
	 * Returns the meta object for the attribute '{@link test1.Zipcode#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>State</em>'.
	 * @see test1.Zipcode#getState()
	 * @see #getZipcode()
	 * @generated
	 */
	EAttribute getZipcode_State();

	/**
	 * Returns the meta object for the attribute '{@link test1.Zipcode#getCountry <em>Country</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Country</em>'.
	 * @see test1.Zipcode#getCountry()
	 * @see #getZipcode()
	 * @generated
	 */
	EAttribute getZipcode_Country();

	/**
	 * Returns the meta object for the reference list '{@link test1.Zipcode#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Location</em>'.
	 * @see test1.Zipcode#getLocation()
	 * @see #getZipcode()
	 * @generated
	 */
	EReference getZipcode_Location();

	/**
	 * Returns the meta object for the '{@link test1.Zipcode#setZip() <em>Set Zip</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Zip</em>' operation.
	 * @see test1.Zipcode#setZip()
	 * @generated
	 */
	EOperation getZipcode__SetZip();

	/**
	 * Returns the meta object for the '{@link test1.Zipcode#setCity() <em>Set City</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set City</em>' operation.
	 * @see test1.Zipcode#setCity()
	 * @generated
	 */
	EOperation getZipcode__SetCity();

	/**
	 * Returns the meta object for the '{@link test1.Zipcode#setStatus() <em>Set Status</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Status</em>' operation.
	 * @see test1.Zipcode#setStatus()
	 * @generated
	 */
	EOperation getZipcode__SetStatus();

	/**
	 * Returns the meta object for the '{@link test1.Zipcode#setCountry() <em>Set Country</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Country</em>' operation.
	 * @see test1.Zipcode#setCountry()
	 * @generated
	 */
	EOperation getZipcode__SetCountry();

	/**
	 * Returns the meta object for the '{@link test1.Zipcode#getZip() <em>Get Zip</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Zip</em>' operation.
	 * @see test1.Zipcode#getZip()
	 * @generated
	 */
	EOperation getZipcode__GetZip();

	/**
	 * Returns the meta object for the '{@link test1.Zipcode#getCity() <em>Get City</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get City</em>' operation.
	 * @see test1.Zipcode#getCity()
	 * @generated
	 */
	EOperation getZipcode__GetCity();

	/**
	 * Returns the meta object for the '{@link test1.Zipcode#getState() <em>Get State</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get State</em>' operation.
	 * @see test1.Zipcode#getState()
	 * @generated
	 */
	EOperation getZipcode__GetState();

	/**
	 * Returns the meta object for the '{@link test1.Zipcode#getCountry() <em>Get Country</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Country</em>' operation.
	 * @see test1.Zipcode#getCountry()
	 * @generated
	 */
	EOperation getZipcode__GetCountry();

	/**
	 * Returns the meta object for class '{@link test1.Transactions <em>Transactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transactions</em>'.
	 * @see test1.Transactions
	 * @generated
	 */
	EClass getTransactions();

	/**
	 * Returns the meta object for the attribute '{@link test1.Transactions#getTransactionId <em>Transaction Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transaction Id</em>'.
	 * @see test1.Transactions#getTransactionId()
	 * @see #getTransactions()
	 * @generated
	 */
	EAttribute getTransactions_TransactionId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Transactions#getTotalPrice <em>Total Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Total Price</em>'.
	 * @see test1.Transactions#getTotalPrice()
	 * @see #getTransactions()
	 * @generated
	 */
	EAttribute getTransactions_TotalPrice();

	/**
	 * Returns the meta object for the containment reference '{@link test1.Transactions#getTransactionDate <em>Transaction Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Transaction Date</em>'.
	 * @see test1.Transactions#getTransactionDate()
	 * @see #getTransactions()
	 * @generated
	 */
	EReference getTransactions_TransactionDate();

	/**
	 * Returns the meta object for the attribute '{@link test1.Transactions#getTransactionStatus <em>Transaction Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transaction Status</em>'.
	 * @see test1.Transactions#getTransactionStatus()
	 * @see #getTransactions()
	 * @generated
	 */
	EAttribute getTransactions_TransactionStatus();

	/**
	 * Returns the meta object for the reference '{@link test1.Transactions#getOrderId <em>Order Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Order Id</em>'.
	 * @see test1.Transactions#getOrderId()
	 * @see #getTransactions()
	 * @generated
	 */
	EReference getTransactions_OrderId();

	/**
	 * Returns the meta object for the reference '{@link test1.Transactions#getStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Status</em>'.
	 * @see test1.Transactions#getStatus()
	 * @see #getTransactions()
	 * @generated
	 */
	EReference getTransactions_Status();

	/**
	 * Returns the meta object for the reference '{@link test1.Transactions#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Order</em>'.
	 * @see test1.Transactions#getOrder()
	 * @see #getTransactions()
	 * @generated
	 */
	EReference getTransactions_Order();

	/**
	 * Returns the meta object for the reference '{@link test1.Transactions#getPaymentId <em>Payment Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Payment Id</em>'.
	 * @see test1.Transactions#getPaymentId()
	 * @see #getTransactions()
	 * @generated
	 */
	EReference getTransactions_PaymentId();

	/**
	 * Returns the meta object for the reference '{@link test1.Transactions#getStatusId <em>Status Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Status Id</em>'.
	 * @see test1.Transactions#getStatusId()
	 * @see #getTransactions()
	 * @generated
	 */
	EReference getTransactions_StatusId();

	/**
	 * Returns the meta object for the containment reference '{@link test1.Transactions#getPaymentsInfo <em>Payments Info</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Payments Info</em>'.
	 * @see test1.Transactions#getPaymentsInfo()
	 * @see #getTransactions()
	 * @generated
	 */
	EReference getTransactions_PaymentsInfo();

	/**
	 * Returns the meta object for the '{@link test1.Transactions#setTotalPrice() <em>Set Total Price</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Total Price</em>' operation.
	 * @see test1.Transactions#setTotalPrice()
	 * @generated
	 */
	EOperation getTransactions__SetTotalPrice();

	/**
	 * Returns the meta object for the '{@link test1.Transactions#setTransactionDate() <em>Set Transaction Date</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Transaction Date</em>' operation.
	 * @see test1.Transactions#setTransactionDate()
	 * @generated
	 */
	EOperation getTransactions__SetTransactionDate();

	/**
	 * Returns the meta object for the '{@link test1.Transactions#setTransactionStatus() <em>Set Transaction Status</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Transaction Status</em>' operation.
	 * @see test1.Transactions#setTransactionStatus()
	 * @generated
	 */
	EOperation getTransactions__SetTransactionStatus();

	/**
	 * Returns the meta object for the '{@link test1.Transactions#getTotalPrice() <em>Get Total Price</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Total Price</em>' operation.
	 * @see test1.Transactions#getTotalPrice()
	 * @generated
	 */
	EOperation getTransactions__GetTotalPrice();

	/**
	 * Returns the meta object for the '{@link test1.Transactions#getTransactionDate() <em>Get Transaction Date</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Transaction Date</em>' operation.
	 * @see test1.Transactions#getTransactionDate()
	 * @generated
	 */
	EOperation getTransactions__GetTransactionDate();

	/**
	 * Returns the meta object for the '{@link test1.Transactions#getTransactionStatus() <em>Get Transaction Status</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Transaction Status</em>' operation.
	 * @see test1.Transactions#getTransactionStatus()
	 * @generated
	 */
	EOperation getTransactions__GetTransactionStatus();

	/**
	 * Returns the meta object for class '{@link test1.Order <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Order</em>'.
	 * @see test1.Order
	 * @generated
	 */
	EClass getOrder();

	/**
	 * Returns the meta object for the attribute '{@link test1.Order#getOrderId <em>Order Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Order Id</em>'.
	 * @see test1.Order#getOrderId()
	 * @see #getOrder()
	 * @generated
	 */
	EAttribute getOrder_OrderId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Order#getOrderPrice <em>Order Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Order Price</em>'.
	 * @see test1.Order#getOrderPrice()
	 * @see #getOrder()
	 * @generated
	 */
	EAttribute getOrder_OrderPrice();

	/**
	 * Returns the meta object for the attribute '{@link test1.Order#getInstructions <em>Instructions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Instructions</em>'.
	 * @see test1.Order#getInstructions()
	 * @see #getOrder()
	 * @generated
	 */
	EAttribute getOrder_Instructions();

	/**
	 * Returns the meta object for the attribute '{@link test1.Order#getDiscountedPrice <em>Discounted Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Discounted Price</em>'.
	 * @see test1.Order#getDiscountedPrice()
	 * @see #getOrder()
	 * @generated
	 */
	EAttribute getOrder_DiscountedPrice();

	/**
	 * Returns the meta object for the attribute '{@link test1.Order#getSourceLocationId <em>Source Location Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source Location Id</em>'.
	 * @see test1.Order#getSourceLocationId()
	 * @see #getOrder()
	 * @generated
	 */
	EAttribute getOrder_SourceLocationId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Order#getDestinationId <em>Destination Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Destination Id</em>'.
	 * @see test1.Order#getDestinationId()
	 * @see #getOrder()
	 * @generated
	 */
	EAttribute getOrder_DestinationId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Order#getTax <em>Tax</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tax</em>'.
	 * @see test1.Order#getTax()
	 * @see #getOrder()
	 * @generated
	 */
	EAttribute getOrder_Tax();

	/**
	 * Returns the meta object for the attribute '{@link test1.Order#getDelivery <em>Delivery</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Delivery</em>'.
	 * @see test1.Order#getDelivery()
	 * @see #getOrder()
	 * @generated
	 */
	EAttribute getOrder_Delivery();

	/**
	 * Returns the meta object for the reference '{@link test1.Order#getStatusId <em>Status Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Status Id</em>'.
	 * @see test1.Order#getStatusId()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_StatusId();

	/**
	 * Returns the meta object for the containment reference '{@link test1.Order#getStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Status</em>'.
	 * @see test1.Order#getStatus()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_Status();

	/**
	 * Returns the meta object for the reference '{@link test1.Order#getAgentId <em>Agent Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Agent Id</em>'.
	 * @see test1.Order#getAgentId()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_AgentId();

	/**
	 * Returns the meta object for the reference '{@link test1.Order#getPaymentId <em>Payment Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Payment Id</em>'.
	 * @see test1.Order#getPaymentId()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_PaymentId();

	/**
	 * Returns the meta object for the reference '{@link test1.Order#getPromotionId <em>Promotion Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Promotion Id</em>'.
	 * @see test1.Order#getPromotionId()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_PromotionId();

	/**
	 * Returns the meta object for the reference '{@link test1.Order#getDiscounts <em>Discounts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Discounts</em>'.
	 * @see test1.Order#getDiscounts()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_Discounts();

	/**
	 * Returns the meta object for the reference '{@link test1.Order#getCustomerId <em>Customer Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Customer Id</em>'.
	 * @see test1.Order#getCustomerId()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_CustomerId();

	/**
	 * Returns the meta object for the reference '{@link test1.Order#getTransactions <em>Transactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Transactions</em>'.
	 * @see test1.Order#getTransactions()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_Transactions();

	/**
	 * Returns the meta object for the reference '{@link test1.Order#getPaymentsInfo <em>Payments Info</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Payments Info</em>'.
	 * @see test1.Order#getPaymentsInfo()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_PaymentsInfo();

	/**
	 * Returns the meta object for the reference list '{@link test1.Order#getCatalog <em>Catalog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Catalog</em>'.
	 * @see test1.Order#getCatalog()
	 * @see #getOrder()
	 * @generated
	 */
	EReference getOrder_Catalog();

	/**
	 * Returns the meta object for the '{@link test1.Order#setOrderId() <em>Set Order Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Order Id</em>' operation.
	 * @see test1.Order#setOrderId()
	 * @generated
	 */
	EOperation getOrder__SetOrderId();

	/**
	 * Returns the meta object for the '{@link test1.Order#setOrderPrice() <em>Set Order Price</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Order Price</em>' operation.
	 * @see test1.Order#setOrderPrice()
	 * @generated
	 */
	EOperation getOrder__SetOrderPrice();

	/**
	 * Returns the meta object for the '{@link test1.Order#setInstructions() <em>Set Instructions</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Instructions</em>' operation.
	 * @see test1.Order#setInstructions()
	 * @generated
	 */
	EOperation getOrder__SetInstructions();

	/**
	 * Returns the meta object for the '{@link test1.Order#setDiscountedPrice() <em>Set Discounted Price</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Discounted Price</em>' operation.
	 * @see test1.Order#setDiscountedPrice()
	 * @generated
	 */
	EOperation getOrder__SetDiscountedPrice();

	/**
	 * Returns the meta object for the '{@link test1.Order#setSourceLocationId() <em>Set Source Location Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Source Location Id</em>' operation.
	 * @see test1.Order#setSourceLocationId()
	 * @generated
	 */
	EOperation getOrder__SetSourceLocationId();

	/**
	 * Returns the meta object for the '{@link test1.Order#setTax() <em>Set Tax</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Tax</em>' operation.
	 * @see test1.Order#setTax()
	 * @generated
	 */
	EOperation getOrder__SetTax();

	/**
	 * Returns the meta object for the '{@link test1.Order#setDeliveryFee() <em>Set Delivery Fee</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Delivery Fee</em>' operation.
	 * @see test1.Order#setDeliveryFee()
	 * @generated
	 */
	EOperation getOrder__SetDeliveryFee();

	/**
	 * Returns the meta object for the '{@link test1.Order#setOderId() <em>Set Oder Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Oder Id</em>' operation.
	 * @see test1.Order#setOderId()
	 * @generated
	 */
	EOperation getOrder__SetOderId();

	/**
	 * Returns the meta object for the '{@link test1.Order#getTax() <em>Get Tax</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Tax</em>' operation.
	 * @see test1.Order#getTax()
	 * @generated
	 */
	EOperation getOrder__GetTax();

	/**
	 * Returns the meta object for the '{@link test1.Order#getDeliveryFee() <em>Get Delivery Fee</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Delivery Fee</em>' operation.
	 * @see test1.Order#getDeliveryFee()
	 * @generated
	 */
	EOperation getOrder__GetDeliveryFee();

	/**
	 * Returns the meta object for class '{@link test1.Status <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Status</em>'.
	 * @see test1.Status
	 * @generated
	 */
	EClass getStatus();

	/**
	 * Returns the meta object for the attribute '{@link test1.Status#getStatusId <em>Status Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status Id</em>'.
	 * @see test1.Status#getStatusId()
	 * @see #getStatus()
	 * @generated
	 */
	EAttribute getStatus_StatusId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Status#getStatusType <em>Status Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status Type</em>'.
	 * @see test1.Status#getStatusType()
	 * @see #getStatus()
	 * @generated
	 */
	EAttribute getStatus_StatusType();

	/**
	 * Returns the meta object for the reference list '{@link test1.Status#getTransactions <em>Transactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Transactions</em>'.
	 * @see test1.Status#getTransactions()
	 * @see #getStatus()
	 * @generated
	 */
	EReference getStatus_Transactions();

	/**
	 * Returns the meta object for the container reference list '{@link test1.Status#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference list '<em>Order</em>'.
	 * @see test1.Status#getOrder()
	 * @see #getStatus()
	 * @generated
	 */
	EReference getStatus_Order();

	/**
	 * Returns the meta object for the '{@link test1.Status#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.Status#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getStatus__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.Status#setStatusId() <em>Set Status Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Status Id</em>' operation.
	 * @see test1.Status#setStatusId()
	 * @generated
	 */
	EOperation getStatus__SetStatusId();

	/**
	 * Returns the meta object for the '{@link test1.Status#setStatusType() <em>Set Status Type</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Status Type</em>' operation.
	 * @see test1.Status#setStatusType()
	 * @generated
	 */
	EOperation getStatus__SetStatusType();

	/**
	 * Returns the meta object for the '{@link test1.Status#getStatusId() <em>Get Status Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Status Id</em>' operation.
	 * @see test1.Status#getStatusId()
	 * @generated
	 */
	EOperation getStatus__GetStatusId();

	/**
	 * Returns the meta object for the '{@link test1.Status#getStatusType() <em>Get Status Type</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Status Type</em>' operation.
	 * @see test1.Status#getStatusType()
	 * @generated
	 */
	EOperation getStatus__GetStatusType();

	/**
	 * Returns the meta object for class '{@link test1.Discounts <em>Discounts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Discounts</em>'.
	 * @see test1.Discounts
	 * @generated
	 */
	EClass getDiscounts();

	/**
	 * Returns the meta object for the attribute '{@link test1.Discounts#getPromotionId <em>Promotion Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Promotion Id</em>'.
	 * @see test1.Discounts#getPromotionId()
	 * @see #getDiscounts()
	 * @generated
	 */
	EAttribute getDiscounts_PromotionId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Discounts#getPromotionName <em>Promotion Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Promotion Name</em>'.
	 * @see test1.Discounts#getPromotionName()
	 * @see #getDiscounts()
	 * @generated
	 */
	EAttribute getDiscounts_PromotionName();

	/**
	 * Returns the meta object for the attribute '{@link test1.Discounts#getPromotionCode <em>Promotion Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Promotion Code</em>'.
	 * @see test1.Discounts#getPromotionCode()
	 * @see #getDiscounts()
	 * @generated
	 */
	EAttribute getDiscounts_PromotionCode();

	/**
	 * Returns the meta object for the reference '{@link test1.Discounts#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Order</em>'.
	 * @see test1.Discounts#getOrder()
	 * @see #getDiscounts()
	 * @generated
	 */
	EReference getDiscounts_Order();

	/**
	 * Returns the meta object for the '{@link test1.Discounts#setPromotionId() <em>Set Promotion Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Promotion Id</em>' operation.
	 * @see test1.Discounts#setPromotionId()
	 * @generated
	 */
	EOperation getDiscounts__SetPromotionId();

	/**
	 * Returns the meta object for the '{@link test1.Discounts#setPromotionName() <em>Set Promotion Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Promotion Name</em>' operation.
	 * @see test1.Discounts#setPromotionName()
	 * @generated
	 */
	EOperation getDiscounts__SetPromotionName();

	/**
	 * Returns the meta object for the '{@link test1.Discounts#setPromotionCode() <em>Set Promotion Code</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Promotion Code</em>' operation.
	 * @see test1.Discounts#setPromotionCode()
	 * @generated
	 */
	EOperation getDiscounts__SetPromotionCode();

	/**
	 * Returns the meta object for the '{@link test1.Discounts#getPromotionId() <em>Get Promotion Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Promotion Id</em>' operation.
	 * @see test1.Discounts#getPromotionId()
	 * @generated
	 */
	EOperation getDiscounts__GetPromotionId();

	/**
	 * Returns the meta object for the '{@link test1.Discounts#getPromotionName() <em>Get Promotion Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Promotion Name</em>' operation.
	 * @see test1.Discounts#getPromotionName()
	 * @generated
	 */
	EOperation getDiscounts__GetPromotionName();

	/**
	 * Returns the meta object for the '{@link test1.Discounts#getPromotionCode() <em>Get Promotion Code</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Promotion Code</em>' operation.
	 * @see test1.Discounts#getPromotionCode()
	 * @generated
	 */
	EOperation getDiscounts__GetPromotionCode();

	/**
	 * Returns the meta object for class '{@link test1.Catalog <em>Catalog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Catalog</em>'.
	 * @see test1.Catalog
	 * @generated
	 */
	EClass getCatalog();

	/**
	 * Returns the meta object for the attribute '{@link test1.Catalog#getPrice <em>Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Price</em>'.
	 * @see test1.Catalog#getPrice()
	 * @see #getCatalog()
	 * @generated
	 */
	EAttribute getCatalog_Price();

	/**
	 * Returns the meta object for the reference '{@link test1.Catalog#getProductId <em>Product Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Product Id</em>'.
	 * @see test1.Catalog#getProductId()
	 * @see #getCatalog()
	 * @generated
	 */
	EReference getCatalog_ProductId();

	/**
	 * Returns the meta object for the reference list '{@link test1.Catalog#getProduct <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Product</em>'.
	 * @see test1.Catalog#getProduct()
	 * @see #getCatalog()
	 * @generated
	 */
	EReference getCatalog_Product();

	/**
	 * Returns the meta object for the reference '{@link test1.Catalog#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Order</em>'.
	 * @see test1.Catalog#getOrder()
	 * @see #getCatalog()
	 * @generated
	 */
	EReference getCatalog_Order();

	/**
	 * Returns the meta object for the '{@link test1.Catalog#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.Catalog#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getCatalog__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.Catalog#setPrice() <em>Set Price</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Price</em>' operation.
	 * @see test1.Catalog#setPrice()
	 * @generated
	 */
	EOperation getCatalog__SetPrice();

	/**
	 * Returns the meta object for the '{@link test1.Catalog#getPrice() <em>Get Price</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Price</em>' operation.
	 * @see test1.Catalog#getPrice()
	 * @generated
	 */
	EOperation getCatalog__GetPrice();

	/**
	 * Returns the meta object for class '{@link test1.Product <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Product</em>'.
	 * @see test1.Product
	 * @generated
	 */
	EClass getProduct();

	/**
	 * Returns the meta object for the attribute '{@link test1.Product#getProductId <em>Product Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Product Id</em>'.
	 * @see test1.Product#getProductId()
	 * @see #getProduct()
	 * @generated
	 */
	EAttribute getProduct_ProductId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Product#getProductName <em>Product Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Product Name</em>'.
	 * @see test1.Product#getProductName()
	 * @see #getProduct()
	 * @generated
	 */
	EAttribute getProduct_ProductName();

	/**
	 * Returns the meta object for the attribute '{@link test1.Product#getProductDescripton <em>Product Descripton</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Product Descripton</em>'.
	 * @see test1.Product#getProductDescripton()
	 * @see #getProduct()
	 * @generated
	 */
	EAttribute getProduct_ProductDescripton();

	/**
	 * Returns the meta object for the reference '{@link test1.Product#getCategoryId <em>Category Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Category Id</em>'.
	 * @see test1.Product#getCategoryId()
	 * @see #getProduct()
	 * @generated
	 */
	EReference getProduct_CategoryId();

	/**
	 * Returns the meta object for the reference list '{@link test1.Product#getProductCategory <em>Product Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Product Category</em>'.
	 * @see test1.Product#getProductCategory()
	 * @see #getProduct()
	 * @generated
	 */
	EReference getProduct_ProductCategory();

	/**
	 * Returns the meta object for the reference '{@link test1.Product#getOrderItemsId <em>Order Items Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Order Items Id</em>'.
	 * @see test1.Product#getOrderItemsId()
	 * @see #getProduct()
	 * @generated
	 */
	EReference getProduct_OrderItemsId();

	/**
	 * Returns the meta object for the containment reference '{@link test1.Product#getOrderItems <em>Order Items</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Order Items</em>'.
	 * @see test1.Product#getOrderItems()
	 * @see #getProduct()
	 * @generated
	 */
	EReference getProduct_OrderItems();

	/**
	 * Returns the meta object for the reference '{@link test1.Product#getCatalog <em>Catalog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Catalog</em>'.
	 * @see test1.Product#getCatalog()
	 * @see #getProduct()
	 * @generated
	 */
	EReference getProduct_Catalog();

	/**
	 * Returns the meta object for the '{@link test1.Product#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.Product#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getProduct__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.Product#setProductId() <em>Set Product Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Product Id</em>' operation.
	 * @see test1.Product#setProductId()
	 * @generated
	 */
	EOperation getProduct__SetProductId();

	/**
	 * Returns the meta object for the '{@link test1.Product#setProductName() <em>Set Product Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Product Name</em>' operation.
	 * @see test1.Product#setProductName()
	 * @generated
	 */
	EOperation getProduct__SetProductName();

	/**
	 * Returns the meta object for the '{@link test1.Product#setProductDescription() <em>Set Product Description</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Product Description</em>' operation.
	 * @see test1.Product#setProductDescription()
	 * @generated
	 */
	EOperation getProduct__SetProductDescription();

	/**
	 * Returns the meta object for the '{@link test1.Product#getProductId() <em>Get Product Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Product Id</em>' operation.
	 * @see test1.Product#getProductId()
	 * @generated
	 */
	EOperation getProduct__GetProductId();

	/**
	 * Returns the meta object for the '{@link test1.Product#getProductName() <em>Get Product Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Product Name</em>' operation.
	 * @see test1.Product#getProductName()
	 * @generated
	 */
	EOperation getProduct__GetProductName();

	/**
	 * Returns the meta object for the '{@link test1.Product#getProductDescription() <em>Get Product Description</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Product Description</em>' operation.
	 * @see test1.Product#getProductDescription()
	 * @generated
	 */
	EOperation getProduct__GetProductDescription();

	/**
	 * Returns the meta object for class '{@link test1.ProductCategory <em>Product Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Product Category</em>'.
	 * @see test1.ProductCategory
	 * @generated
	 */
	EClass getProductCategory();

	/**
	 * Returns the meta object for the attribute '{@link test1.ProductCategory#getCategoryId <em>Category Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Category Id</em>'.
	 * @see test1.ProductCategory#getCategoryId()
	 * @see #getProductCategory()
	 * @generated
	 */
	EAttribute getProductCategory_CategoryId();

	/**
	 * Returns the meta object for the attribute '{@link test1.ProductCategory#getCategoryName <em>Category Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Category Name</em>'.
	 * @see test1.ProductCategory#getCategoryName()
	 * @see #getProductCategory()
	 * @generated
	 */
	EAttribute getProductCategory_CategoryName();

	/**
	 * Returns the meta object for the reference '{@link test1.ProductCategory#getProduct <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Product</em>'.
	 * @see test1.ProductCategory#getProduct()
	 * @see #getProductCategory()
	 * @generated
	 */
	EReference getProductCategory_Product();

	/**
	 * Returns the meta object for the '{@link test1.ProductCategory#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.ProductCategory#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getProductCategory__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.ProductCategory#setCategoryId() <em>Set Category Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Category Id</em>' operation.
	 * @see test1.ProductCategory#setCategoryId()
	 * @generated
	 */
	EOperation getProductCategory__SetCategoryId();

	/**
	 * Returns the meta object for the '{@link test1.ProductCategory#setCategoryName() <em>Set Category Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Category Name</em>' operation.
	 * @see test1.ProductCategory#setCategoryName()
	 * @generated
	 */
	EOperation getProductCategory__SetCategoryName();

	/**
	 * Returns the meta object for the '{@link test1.ProductCategory#getCategoryId() <em>Get Category Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Category Id</em>' operation.
	 * @see test1.ProductCategory#getCategoryId()
	 * @generated
	 */
	EOperation getProductCategory__GetCategoryId();

	/**
	 * Returns the meta object for the '{@link test1.ProductCategory#getcategoryName() <em>Getcategory Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Getcategory Name</em>' operation.
	 * @see test1.ProductCategory#getcategoryName()
	 * @generated
	 */
	EOperation getProductCategory__GetcategoryName();

	/**
	 * Returns the meta object for class '{@link test1.OrderItems <em>Order Items</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Order Items</em>'.
	 * @see test1.OrderItems
	 * @generated
	 */
	EClass getOrderItems();

	/**
	 * Returns the meta object for the attribute '{@link test1.OrderItems#getOrderItemsId <em>Order Items Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Order Items Id</em>'.
	 * @see test1.OrderItems#getOrderItemsId()
	 * @see #getOrderItems()
	 * @generated
	 */
	EAttribute getOrderItems_OrderItemsId();

	/**
	 * Returns the meta object for the attribute '{@link test1.OrderItems#getProductQuantity <em>Product Quantity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Product Quantity</em>'.
	 * @see test1.OrderItems#getProductQuantity()
	 * @see #getOrderItems()
	 * @generated
	 */
	EAttribute getOrderItems_ProductQuantity();

	/**
	 * Returns the meta object for the reference '{@link test1.OrderItems#getProductId <em>Product Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Product Id</em>'.
	 * @see test1.OrderItems#getProductId()
	 * @see #getOrderItems()
	 * @generated
	 */
	EReference getOrderItems_ProductId();

	/**
	 * Returns the meta object for the reference '{@link test1.OrderItems#getOrderId <em>Order Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Order Id</em>'.
	 * @see test1.OrderItems#getOrderId()
	 * @see #getOrderItems()
	 * @generated
	 */
	EReference getOrderItems_OrderId();

	/**
	 * Returns the meta object for the container reference '{@link test1.OrderItems#getProduct <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Product</em>'.
	 * @see test1.OrderItems#getProduct()
	 * @see #getOrderItems()
	 * @generated
	 */
	EReference getOrderItems_Product();

	/**
	 * Returns the meta object for the '{@link test1.OrderItems#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.OrderItems#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getOrderItems__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.OrderItems#setOrderItemsId() <em>Set Order Items Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Order Items Id</em>' operation.
	 * @see test1.OrderItems#setOrderItemsId()
	 * @generated
	 */
	EOperation getOrderItems__SetOrderItemsId();

	/**
	 * Returns the meta object for the '{@link test1.OrderItems#setProductQuantity() <em>Set Product Quantity</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Product Quantity</em>' operation.
	 * @see test1.OrderItems#setProductQuantity()
	 * @generated
	 */
	EOperation getOrderItems__SetProductQuantity();

	/**
	 * Returns the meta object for the '{@link test1.OrderItems#getOrderItemsId() <em>Get Order Items Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Order Items Id</em>' operation.
	 * @see test1.OrderItems#getOrderItemsId()
	 * @generated
	 */
	EOperation getOrderItems__GetOrderItemsId();

	/**
	 * Returns the meta object for the '{@link test1.OrderItems#getProductQuantity() <em>Get Product Quantity</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Product Quantity</em>' operation.
	 * @see test1.OrderItems#getProductQuantity()
	 * @generated
	 */
	EOperation getOrderItems__GetProductQuantity();

	/**
	 * Returns the meta object for class '{@link test1.Ratings <em>Ratings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ratings</em>'.
	 * @see test1.Ratings
	 * @generated
	 */
	EClass getRatings();

	/**
	 * Returns the meta object for the attribute '{@link test1.Ratings#getRatingId <em>Rating Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rating Id</em>'.
	 * @see test1.Ratings#getRatingId()
	 * @see #getRatings()
	 * @generated
	 */
	EAttribute getRatings_RatingId();

	/**
	 * Returns the meta object for the attribute '{@link test1.Ratings#getRating <em>Rating</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rating</em>'.
	 * @see test1.Ratings#getRating()
	 * @see #getRatings()
	 * @generated
	 */
	EAttribute getRatings_Rating();

	/**
	 * Returns the meta object for the container reference list '{@link test1.Ratings#getOrderfeedback <em>Orderfeedback</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference list '<em>Orderfeedback</em>'.
	 * @see test1.Ratings#getOrderfeedback()
	 * @see #getRatings()
	 * @generated
	 */
	EReference getRatings_Orderfeedback();

	/**
	 * Returns the meta object for the '{@link test1.Ratings#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see test1.Ratings#constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getRatings__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link test1.Ratings#setRatingId() <em>Set Rating Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Rating Id</em>' operation.
	 * @see test1.Ratings#setRatingId()
	 * @generated
	 */
	EOperation getRatings__SetRatingId();

	/**
	 * Returns the meta object for the '{@link test1.Ratings#setRating() <em>Set Rating</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Rating</em>' operation.
	 * @see test1.Ratings#setRating()
	 * @generated
	 */
	EOperation getRatings__SetRating();

	/**
	 * Returns the meta object for the '{@link test1.Ratings#getRatingId() <em>Get Rating Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Rating Id</em>' operation.
	 * @see test1.Ratings#getRatingId()
	 * @generated
	 */
	EOperation getRatings__GetRatingId();

	/**
	 * Returns the meta object for the '{@link test1.Ratings#getRating() <em>Get Rating</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Rating</em>' operation.
	 * @see test1.Ratings#getRating()
	 * @generated
	 */
	EOperation getRatings__GetRating();

	/**
	 * Returns the meta object for class '{@link test1.OrderFeedback <em>Order Feedback</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Order Feedback</em>'.
	 * @see test1.OrderFeedback
	 * @generated
	 */
	EClass getOrderFeedback();

	/**
	 * Returns the meta object for the attribute '{@link test1.OrderFeedback#getProductFeedback <em>Product Feedback</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Product Feedback</em>'.
	 * @see test1.OrderFeedback#getProductFeedback()
	 * @see #getOrderFeedback()
	 * @generated
	 */
	EAttribute getOrderFeedback_ProductFeedback();

	/**
	 * Returns the meta object for the attribute '{@link test1.OrderFeedback#getDeliveryAgentFeedback <em>Delivery Agent Feedback</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Delivery Agent Feedback</em>'.
	 * @see test1.OrderFeedback#getDeliveryAgentFeedback()
	 * @see #getOrderFeedback()
	 * @generated
	 */
	EAttribute getOrderFeedback_DeliveryAgentFeedback();

	/**
	 * Returns the meta object for the attribute '{@link test1.OrderFeedback#getProductRatingId <em>Product Rating Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Product Rating Id</em>'.
	 * @see test1.OrderFeedback#getProductRatingId()
	 * @see #getOrderFeedback()
	 * @generated
	 */
	EAttribute getOrderFeedback_ProductRatingId();

	/**
	 * Returns the meta object for the reference '{@link test1.OrderFeedback#getDeliveryAgentRatingId <em>Delivery Agent Rating Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Delivery Agent Rating Id</em>'.
	 * @see test1.OrderFeedback#getDeliveryAgentRatingId()
	 * @see #getOrderFeedback()
	 * @generated
	 */
	EReference getOrderFeedback_DeliveryAgentRatingId();

	/**
	 * Returns the meta object for the reference '{@link test1.OrderFeedback#getRatingId <em>Rating Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rating Id</em>'.
	 * @see test1.OrderFeedback#getRatingId()
	 * @see #getOrderFeedback()
	 * @generated
	 */
	EReference getOrderFeedback_RatingId();

	/**
	 * Returns the meta object for the reference '{@link test1.OrderFeedback#getOrderId <em>Order Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Order Id</em>'.
	 * @see test1.OrderFeedback#getOrderId()
	 * @see #getOrderFeedback()
	 * @generated
	 */
	EReference getOrderFeedback_OrderId();

	/**
	 * Returns the meta object for the containment reference '{@link test1.OrderFeedback#getRatings <em>Ratings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Ratings</em>'.
	 * @see test1.OrderFeedback#getRatings()
	 * @see #getOrderFeedback()
	 * @generated
	 */
	EReference getOrderFeedback_Ratings();

	/**
	 * Returns the meta object for the '{@link test1.OrderFeedback#setProductFeedback() <em>Set Product Feedback</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Product Feedback</em>' operation.
	 * @see test1.OrderFeedback#setProductFeedback()
	 * @generated
	 */
	EOperation getOrderFeedback__SetProductFeedback();

	/**
	 * Returns the meta object for the '{@link test1.OrderFeedback#setDeliveryAgentFeedback() <em>Set Delivery Agent Feedback</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Delivery Agent Feedback</em>' operation.
	 * @see test1.OrderFeedback#setDeliveryAgentFeedback()
	 * @generated
	 */
	EOperation getOrderFeedback__SetDeliveryAgentFeedback();

	/**
	 * Returns the meta object for the '{@link test1.OrderFeedback#setProductRatingId() <em>Set Product Rating Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Product Rating Id</em>' operation.
	 * @see test1.OrderFeedback#setProductRatingId()
	 * @generated
	 */
	EOperation getOrderFeedback__SetProductRatingId();

	/**
	 * Returns the meta object for the '{@link test1.OrderFeedback#setDeliveryAgentRatingId() <em>Set Delivery Agent Rating Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Delivery Agent Rating Id</em>' operation.
	 * @see test1.OrderFeedback#setDeliveryAgentRatingId()
	 * @generated
	 */
	EOperation getOrderFeedback__SetDeliveryAgentRatingId();

	/**
	 * Returns the meta object for the '{@link test1.OrderFeedback#getProductFeedback() <em>Get Product Feedback</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Product Feedback</em>' operation.
	 * @see test1.OrderFeedback#getProductFeedback()
	 * @generated
	 */
	EOperation getOrderFeedback__GetProductFeedback();

	/**
	 * Returns the meta object for the '{@link test1.OrderFeedback#getDeliveryAgentFeedback() <em>Get Delivery Agent Feedback</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Delivery Agent Feedback</em>' operation.
	 * @see test1.OrderFeedback#getDeliveryAgentFeedback()
	 * @generated
	 */
	EOperation getOrderFeedback__GetDeliveryAgentFeedback();

	/**
	 * Returns the meta object for the '{@link test1.OrderFeedback#getProductRatingId() <em>Get Product Rating Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Product Rating Id</em>' operation.
	 * @see test1.OrderFeedback#getProductRatingId()
	 * @generated
	 */
	EOperation getOrderFeedback__GetProductRatingId();

	/**
	 * Returns the meta object for the '{@link test1.OrderFeedback#getDeliveryAgentRatingId() <em>Get Delivery Agent Rating Id</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Delivery Agent Rating Id</em>' operation.
	 * @see test1.OrderFeedback#getDeliveryAgentRatingId()
	 * @generated
	 */
	EOperation getOrderFeedback__GetDeliveryAgentRatingId();

	/**
	 * Returns the meta object for class '{@link test1.PrimitiveTypesDate <em>Primitive Types Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Primitive Types Date</em>'.
	 * @see test1.PrimitiveTypesDate
	 * @generated
	 */
	EClass getPrimitiveTypesDate();

	/**
	 * Returns the meta object for class '{@link test1.test1Date <em>test1 Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>test1 Date</em>'.
	 * @see test1.test1Date
	 * @generated
	 */
	EClass gettest1Date();

	/**
	 * Returns the meta object for class '{@link test1.test1Date <em>test1 Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>test1 Date</em>'.
	 * @see test1.test1Date
	 * @generated
	 */
	EClass gettest1Date();

	/**
	 * Returns the meta object for class '{@link test1.test1Date <em>test1 Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>test1 Date</em>'.
	 * @see test1.test1Date
	 * @generated
	 */
	EClass gettest1Date();

	/**
	 * Returns the meta object for class '{@link test1.test1Date <em>test1 Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>test1 Date</em>'.
	 * @see test1.test1Date
	 * @generated
	 */
	EClass gettest1Date();

	/**
	 * Returns the meta object for class '{@link test1.test1Date <em>test1 Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>test1 Date</em>'.
	 * @see test1.test1Date
	 * @generated
	 */
	EClass gettest1Date();

	/**
	 * Returns the meta object for enum '{@link test1.Gender <em>Gender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Gender</em>'.
	 * @see test1.Gender
	 * @generated
	 */
	EEnum getGender();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Test1Factory getTest1Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link test1.impl.CardImpl <em>Card</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.CardImpl
		 * @see test1.impl.Test1PackageImpl#getCard()
		 * @generated
		 */
		EClass CARD = eINSTANCE.getCard();

		/**
		 * The meta object literal for the '<em><b>Card Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARD__CARD_ID = eINSTANCE.getCard_CardId();

		/**
		 * The meta object literal for the '<em><b>Card Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARD__CARD_TYPE = eINSTANCE.getCard_CardType();

		/**
		 * The meta object literal for the '<em><b>Payments Info</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CARD__PAYMENTS_INFO = eINSTANCE.getCard_PaymentsInfo();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CARD___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getCard__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Card Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CARD___SET_CARD_ID = eINSTANCE.getCard__SetCardId();

		/**
		 * The meta object literal for the '<em><b>Set Card Type</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CARD___SET_CARD_TYPE = eINSTANCE.getCard__SetCardType();

		/**
		 * The meta object literal for the '<em><b>Get Card Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CARD___GET_CARD_ID = eINSTANCE.getCard__GetCardId();

		/**
		 * The meta object literal for the '<em><b>Get Card Type</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CARD___GET_CARD_TYPE = eINSTANCE.getCard__GetCardType();

		/**
		 * The meta object literal for the '{@link test1.impl.PaymentsInfoImpl <em>Payments Info</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.PaymentsInfoImpl
		 * @see test1.impl.Test1PackageImpl#getPaymentsInfo()
		 * @generated
		 */
		EClass PAYMENTS_INFO = eINSTANCE.getPaymentsInfo();

		/**
		 * The meta object literal for the '<em><b>Payment Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENTS_INFO__PAYMENT_ID = eINSTANCE.getPaymentsInfo_PaymentId();

		/**
		 * The meta object literal for the '<em><b>Card No</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENTS_INFO__CARD_NO = eINSTANCE.getPaymentsInfo_CardNo();

		/**
		 * The meta object literal for the '<em><b>Expiry Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENTS_INFO__EXPIRY_DATE = eINSTANCE.getPaymentsInfo_ExpiryDate();

		/**
		 * The meta object literal for the '<em><b>Card Holder Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENTS_INFO__CARD_HOLDER_NAME = eINSTANCE.getPaymentsInfo_CardHolderName();

		/**
		 * The meta object literal for the '<em><b>Cvv</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENTS_INFO__CVV = eINSTANCE.getPaymentsInfo_Cvv();

		/**
		 * The meta object literal for the '<em><b>Card Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENTS_INFO__CARD_ID = eINSTANCE.getPaymentsInfo_CardId();

		/**
		 * The meta object literal for the '<em><b>User Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENTS_INFO__USER_ID = eINSTANCE.getPaymentsInfo_UserId();

		/**
		 * The meta object literal for the '<em><b>Transactions</b></em>' container reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENTS_INFO__TRANSACTIONS = eINSTANCE.getPaymentsInfo_Transactions();

		/**
		 * The meta object literal for the '<em><b>Order</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENTS_INFO__ORDER = eINSTANCE.getPaymentsInfo_Order();

		/**
		 * The meta object literal for the '<em><b>Card</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENTS_INFO__CARD = eINSTANCE.getPaymentsInfo_Card();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAYMENTS_INFO___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getPaymentsInfo__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Card No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAYMENTS_INFO___SET_CARD_NO = eINSTANCE.getPaymentsInfo__SetCardNo();

		/**
		 * The meta object literal for the '<em><b>Set Expiry Date</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAYMENTS_INFO___SET_EXPIRY_DATE = eINSTANCE.getPaymentsInfo__SetExpiryDate();

		/**
		 * The meta object literal for the '<em><b>Set Card Holder Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAYMENTS_INFO___SET_CARD_HOLDER_NAME = eINSTANCE.getPaymentsInfo__SetCardHolderName();

		/**
		 * The meta object literal for the '<em><b>Set Cvv</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAYMENTS_INFO___SET_CVV = eINSTANCE.getPaymentsInfo__SetCvv();

		/**
		 * The meta object literal for the '<em><b>Get Card No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAYMENTS_INFO___GET_CARD_NO = eINSTANCE.getPaymentsInfo__GetCardNo();

		/**
		 * The meta object literal for the '<em><b>Get Expiry Date</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAYMENTS_INFO___GET_EXPIRY_DATE = eINSTANCE.getPaymentsInfo__GetExpiryDate();

		/**
		 * The meta object literal for the '<em><b>Get Card Holder Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAYMENTS_INFO___GET_CARD_HOLDER_NAME = eINSTANCE.getPaymentsInfo__GetCardHolderName();

		/**
		 * The meta object literal for the '{@link test1.impl.UserDetailsImpl <em>User Details</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.UserDetailsImpl
		 * @see test1.impl.Test1PackageImpl#getUserDetails()
		 * @generated
		 */
		EClass USER_DETAILS = eINSTANCE.getUserDetails();

		/**
		 * The meta object literal for the '<em><b>User Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER_DETAILS__USER_ID = eINSTANCE.getUserDetails_UserId();

		/**
		 * The meta object literal for the '<em><b>Username</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER_DETAILS__USERNAME = eINSTANCE.getUserDetails_Username();

		/**
		 * The meta object literal for the '<em><b>Password</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER_DETAILS__PASSWORD = eINSTANCE.getUserDetails_Password();

		/**
		 * The meta object literal for the '<em><b>Delivery Agent</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER_DETAILS__DELIVERY_AGENT = eINSTANCE.getUserDetails_DeliveryAgent();

		/**
		 * The meta object literal for the '<em><b>Customer</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER_DETAILS__CUSTOMER = eINSTANCE.getUserDetails_Customer();

		/**
		 * The meta object literal for the '<em><b>Address</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER_DETAILS__ADDRESS = eINSTANCE.getUserDetails_Address();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation USER_DETAILS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getUserDetails__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set User Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation USER_DETAILS___SET_USER_ID = eINSTANCE.getUserDetails__SetUserId();

		/**
		 * The meta object literal for the '<em><b>Set Username</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation USER_DETAILS___SET_USERNAME = eINSTANCE.getUserDetails__SetUsername();

		/**
		 * The meta object literal for the '<em><b>Set Password</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation USER_DETAILS___SET_PASSWORD = eINSTANCE.getUserDetails__SetPassword();

		/**
		 * The meta object literal for the '<em><b>Get User Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation USER_DETAILS___GET_USER_ID = eINSTANCE.getUserDetails__GetUserId();

		/**
		 * The meta object literal for the '<em><b>Get Username</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation USER_DETAILS___GET_USERNAME = eINSTANCE.getUserDetails__GetUsername();

		/**
		 * The meta object literal for the '{@link test1.impl.DeliveryAgentImpl <em>Delivery Agent</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.DeliveryAgentImpl
		 * @see test1.impl.Test1PackageImpl#getDeliveryAgent()
		 * @generated
		 */
		EClass DELIVERY_AGENT = eINSTANCE.getDeliveryAgent();

		/**
		 * The meta object literal for the '<em><b>Agent Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELIVERY_AGENT__AGENT_ID = eINSTANCE.getDeliveryAgent_AgentId();

		/**
		 * The meta object literal for the '<em><b>Contact No</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELIVERY_AGENT__CONTACT_NO = eINSTANCE.getDeliveryAgent_ContactNo();

		/**
		 * The meta object literal for the '<em><b>Ssn</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELIVERY_AGENT__SSN = eINSTANCE.getDeliveryAgent_Ssn();

		/**
		 * The meta object literal for the '<em><b>Driving License No</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELIVERY_AGENT__DRIVING_LICENSE_NO = eINSTANCE.getDeliveryAgent_DrivingLicenseNo();

		/**
		 * The meta object literal for the '<em><b>User Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELIVERY_AGENT__USER_ID = eINSTANCE.getDeliveryAgent_UserId();

		/**
		 * The meta object literal for the '<em><b>User Details</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELIVERY_AGENT__USER_DETAILS = eINSTANCE.getDeliveryAgent_UserDetails();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getDeliveryAgent__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Agent Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___SET_AGENT_ID = eINSTANCE.getDeliveryAgent__SetAgentId();

		/**
		 * The meta object literal for the '<em><b>Set Contact No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___SET_CONTACT_NO = eINSTANCE.getDeliveryAgent__SetContactNo();

		/**
		 * The meta object literal for the '<em><b>Set Ssn</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___SET_SSN = eINSTANCE.getDeliveryAgent__SetSsn();

		/**
		 * The meta object literal for the '<em><b>Set Driving License No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___SET_DRIVING_LICENSE_NO = eINSTANCE.getDeliveryAgent__SetDrivingLicenseNo();

		/**
		 * The meta object literal for the '<em><b>Get Agent Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___GET_AGENT_ID = eINSTANCE.getDeliveryAgent__GetAgentId();

		/**
		 * The meta object literal for the '<em><b>Get Contact No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___GET_CONTACT_NO = eINSTANCE.getDeliveryAgent__GetContactNo();

		/**
		 * The meta object literal for the '<em><b>Get Ssn</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___GET_SSN = eINSTANCE.getDeliveryAgent__GetSsn();

		/**
		 * The meta object literal for the '<em><b>Get Driving License No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DELIVERY_AGENT___GET_DRIVING_LICENSE_NO = eINSTANCE.getDeliveryAgent__GetDrivingLicenseNo();

		/**
		 * The meta object literal for the '{@link test1.impl.PersonImpl <em>Person</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.PersonImpl
		 * @see test1.impl.Test1PackageImpl#getPerson()
		 * @generated
		 */
		EClass PERSON = eINSTANCE.getPerson();

		/**
		 * The meta object literal for the '<em><b>First Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__FIRST_NAME = eINSTANCE.getPerson_FirstName();

		/**
		 * The meta object literal for the '<em><b>Last Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__LAST_NAME = eINSTANCE.getPerson_LastName();

		/**
		 * The meta object literal for the '<em><b>Sex</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__SEX = eINSTANCE.getPerson_Sex();

		/**
		 * The meta object literal for the '<em><b>Date Of Birth</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERSON__DATE_OF_BIRTH = eINSTANCE.getPerson_DateOfBirth();

		/**
		 * The meta object literal for the '<em><b>Gender</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__GENDER = eINSTANCE.getPerson_Gender();

		/**
		 * The meta object literal for the '<em><b>Set First Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___SET_FIRST_NAME = eINSTANCE.getPerson__SetFirstName();

		/**
		 * The meta object literal for the '<em><b>Set Last Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___SET_LAST_NAME = eINSTANCE.getPerson__SetLastName();

		/**
		 * The meta object literal for the '<em><b>Set Date Of Birth</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___SET_DATE_OF_BIRTH = eINSTANCE.getPerson__SetDateOfBirth();

		/**
		 * The meta object literal for the '<em><b>Get First Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___GET_FIRST_NAME = eINSTANCE.getPerson__GetFirstName();

		/**
		 * The meta object literal for the '<em><b>Get Last Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___GET_LAST_NAME = eINSTANCE.getPerson__GetLastName();

		/**
		 * The meta object literal for the '<em><b>Get Date Of Birth</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___GET_DATE_OF_BIRTH = eINSTANCE.getPerson__GetDateOfBirth();

		/**
		 * The meta object literal for the '{@link test1.impl.DateImpl <em>Date</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.DateImpl
		 * @see test1.impl.Test1PackageImpl#getDate()
		 * @generated
		 */
		EClass DATE = eINSTANCE.getDate();

		/**
		 * The meta object literal for the '{@link test1.impl.CustomerImpl <em>Customer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.CustomerImpl
		 * @see test1.impl.Test1PackageImpl#getCustomer()
		 * @generated
		 */
		EClass CUSTOMER = eINSTANCE.getCustomer();

		/**
		 * The meta object literal for the '<em><b>Customer Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__CUSTOMER_ID = eINSTANCE.getCustomer_CustomerId();

		/**
		 * The meta object literal for the '<em><b>Email Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__EMAIL_ID = eINSTANCE.getCustomer_EmailId();

		/**
		 * The meta object literal for the '<em><b>Contact No</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__CONTACT_NO = eINSTANCE.getCustomer_ContactNo();

		/**
		 * The meta object literal for the '<em><b>User Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CUSTOMER__USER_ID = eINSTANCE.getCustomer_UserId();

		/**
		 * The meta object literal for the '<em><b>User Details</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CUSTOMER__USER_DETAILS = eINSTANCE.getCustomer_UserDetails();

		/**
		 * The meta object literal for the '<em><b>Set User Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CUSTOMER___SET_USER_ID = eINSTANCE.getCustomer__SetUserId();

		/**
		 * The meta object literal for the '<em><b>Set Customer Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CUSTOMER___SET_CUSTOMER_ID = eINSTANCE.getCustomer__SetCustomerId();

		/**
		 * The meta object literal for the '<em><b>Set Email Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CUSTOMER___SET_EMAIL_ID = eINSTANCE.getCustomer__SetEmailId();

		/**
		 * The meta object literal for the '<em><b>Set Contact No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CUSTOMER___SET_CONTACT_NO = eINSTANCE.getCustomer__SetContactNo();

		/**
		 * The meta object literal for the '<em><b>Get Customer Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CUSTOMER___GET_CUSTOMER_ID = eINSTANCE.getCustomer__GetCustomerId();

		/**
		 * The meta object literal for the '<em><b>Get Email Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CUSTOMER___GET_EMAIL_ID = eINSTANCE.getCustomer__GetEmailId();

		/**
		 * The meta object literal for the '<em><b>Get Contact No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CUSTOMER___GET_CONTACT_NO = eINSTANCE.getCustomer__GetContactNo();

		/**
		 * The meta object literal for the '{@link test1.impl.AddressImpl <em>Address</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.AddressImpl
		 * @see test1.impl.Test1PackageImpl#getAddress()
		 * @generated
		 */
		EClass ADDRESS = eINSTANCE.getAddress();

		/**
		 * The meta object literal for the '<em><b>Address Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADDRESS__ADDRESS_TYPE = eINSTANCE.getAddress_AddressType();

		/**
		 * The meta object literal for the '<em><b>Location Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADDRESS__LOCATION_ID = eINSTANCE.getAddress_LocationId();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADDRESS__LOCATION = eINSTANCE.getAddress_Location();

		/**
		 * The meta object literal for the '<em><b>User Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADDRESS__USER_ID = eINSTANCE.getAddress_UserId();

		/**
		 * The meta object literal for the '<em><b>User Details</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADDRESS__USER_DETAILS = eINSTANCE.getAddress_UserDetails();

		/**
		 * The meta object literal for the '<em><b>Set Address Type</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ADDRESS___SET_ADDRESS_TYPE = eINSTANCE.getAddress__SetAddressType();

		/**
		 * The meta object literal for the '<em><b>Get Address Type</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ADDRESS___GET_ADDRESS_TYPE = eINSTANCE.getAddress__GetAddressType();

		/**
		 * The meta object literal for the '{@link test1.impl.LocationImpl <em>Location</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.LocationImpl
		 * @see test1.impl.Test1PackageImpl#getLocation()
		 * @generated
		 */
		EClass LOCATION = eINSTANCE.getLocation();

		/**
		 * The meta object literal for the '<em><b>Location Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__LOCATION_ID = eINSTANCE.getLocation_LocationId();

		/**
		 * The meta object literal for the '<em><b>Street Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__STREET_NAME = eINSTANCE.getLocation_StreetName();

		/**
		 * The meta object literal for the '<em><b>House No</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__HOUSE_NO = eINSTANCE.getLocation_HouseNo();

		/**
		 * The meta object literal for the '<em><b>Zip</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCATION__ZIP = eINSTANCE.getLocation_Zip();

		/**
		 * The meta object literal for the '<em><b>Zipcode</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCATION__ZIPCODE = eINSTANCE.getLocation_Zipcode();

		/**
		 * The meta object literal for the '<em><b>Address</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCATION__ADDRESS = eINSTANCE.getLocation_Address();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LOCATION___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getLocation__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Location</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LOCATION___SET_LOCATION = eINSTANCE.getLocation__SetLocation();

		/**
		 * The meta object literal for the '<em><b>Set Street Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LOCATION___SET_STREET_NAME = eINSTANCE.getLocation__SetStreetName();

		/**
		 * The meta object literal for the '<em><b>Set House No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LOCATION___SET_HOUSE_NO = eINSTANCE.getLocation__SetHouseNo();

		/**
		 * The meta object literal for the '<em><b>Get Location Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LOCATION___GET_LOCATION_ID = eINSTANCE.getLocation__GetLocationId();

		/**
		 * The meta object literal for the '<em><b>Get Street Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LOCATION___GET_STREET_NAME = eINSTANCE.getLocation__GetStreetName();

		/**
		 * The meta object literal for the '<em><b>Get House No</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LOCATION___GET_HOUSE_NO = eINSTANCE.getLocation__GetHouseNo();

		/**
		 * The meta object literal for the '{@link test1.impl.ZipcodeImpl <em>Zipcode</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.ZipcodeImpl
		 * @see test1.impl.Test1PackageImpl#getZipcode()
		 * @generated
		 */
		EClass ZIPCODE = eINSTANCE.getZipcode();

		/**
		 * The meta object literal for the '<em><b>Zip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ZIPCODE__ZIP = eINSTANCE.getZipcode_Zip();

		/**
		 * The meta object literal for the '<em><b>City</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ZIPCODE__CITY = eINSTANCE.getZipcode_City();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ZIPCODE__STATE = eINSTANCE.getZipcode_State();

		/**
		 * The meta object literal for the '<em><b>Country</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ZIPCODE__COUNTRY = eINSTANCE.getZipcode_Country();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ZIPCODE__LOCATION = eINSTANCE.getZipcode_Location();

		/**
		 * The meta object literal for the '<em><b>Set Zip</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ZIPCODE___SET_ZIP = eINSTANCE.getZipcode__SetZip();

		/**
		 * The meta object literal for the '<em><b>Set City</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ZIPCODE___SET_CITY = eINSTANCE.getZipcode__SetCity();

		/**
		 * The meta object literal for the '<em><b>Set Status</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ZIPCODE___SET_STATUS = eINSTANCE.getZipcode__SetStatus();

		/**
		 * The meta object literal for the '<em><b>Set Country</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ZIPCODE___SET_COUNTRY = eINSTANCE.getZipcode__SetCountry();

		/**
		 * The meta object literal for the '<em><b>Get Zip</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ZIPCODE___GET_ZIP = eINSTANCE.getZipcode__GetZip();

		/**
		 * The meta object literal for the '<em><b>Get City</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ZIPCODE___GET_CITY = eINSTANCE.getZipcode__GetCity();

		/**
		 * The meta object literal for the '<em><b>Get State</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ZIPCODE___GET_STATE = eINSTANCE.getZipcode__GetState();

		/**
		 * The meta object literal for the '<em><b>Get Country</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ZIPCODE___GET_COUNTRY = eINSTANCE.getZipcode__GetCountry();

		/**
		 * The meta object literal for the '{@link test1.impl.TransactionsImpl <em>Transactions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.TransactionsImpl
		 * @see test1.impl.Test1PackageImpl#getTransactions()
		 * @generated
		 */
		EClass TRANSACTIONS = eINSTANCE.getTransactions();

		/**
		 * The meta object literal for the '<em><b>Transaction Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSACTIONS__TRANSACTION_ID = eINSTANCE.getTransactions_TransactionId();

		/**
		 * The meta object literal for the '<em><b>Total Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSACTIONS__TOTAL_PRICE = eINSTANCE.getTransactions_TotalPrice();

		/**
		 * The meta object literal for the '<em><b>Transaction Date</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSACTIONS__TRANSACTION_DATE = eINSTANCE.getTransactions_TransactionDate();

		/**
		 * The meta object literal for the '<em><b>Transaction Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSACTIONS__TRANSACTION_STATUS = eINSTANCE.getTransactions_TransactionStatus();

		/**
		 * The meta object literal for the '<em><b>Order Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSACTIONS__ORDER_ID = eINSTANCE.getTransactions_OrderId();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSACTIONS__STATUS = eINSTANCE.getTransactions_Status();

		/**
		 * The meta object literal for the '<em><b>Order</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSACTIONS__ORDER = eINSTANCE.getTransactions_Order();

		/**
		 * The meta object literal for the '<em><b>Payment Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSACTIONS__PAYMENT_ID = eINSTANCE.getTransactions_PaymentId();

		/**
		 * The meta object literal for the '<em><b>Status Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSACTIONS__STATUS_ID = eINSTANCE.getTransactions_StatusId();

		/**
		 * The meta object literal for the '<em><b>Payments Info</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSACTIONS__PAYMENTS_INFO = eINSTANCE.getTransactions_PaymentsInfo();

		/**
		 * The meta object literal for the '<em><b>Set Total Price</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSACTIONS___SET_TOTAL_PRICE = eINSTANCE.getTransactions__SetTotalPrice();

		/**
		 * The meta object literal for the '<em><b>Set Transaction Date</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSACTIONS___SET_TRANSACTION_DATE = eINSTANCE.getTransactions__SetTransactionDate();

		/**
		 * The meta object literal for the '<em><b>Set Transaction Status</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSACTIONS___SET_TRANSACTION_STATUS = eINSTANCE.getTransactions__SetTransactionStatus();

		/**
		 * The meta object literal for the '<em><b>Get Total Price</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSACTIONS___GET_TOTAL_PRICE = eINSTANCE.getTransactions__GetTotalPrice();

		/**
		 * The meta object literal for the '<em><b>Get Transaction Date</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSACTIONS___GET_TRANSACTION_DATE = eINSTANCE.getTransactions__GetTransactionDate();

		/**
		 * The meta object literal for the '<em><b>Get Transaction Status</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSACTIONS___GET_TRANSACTION_STATUS = eINSTANCE.getTransactions__GetTransactionStatus();

		/**
		 * The meta object literal for the '{@link test1.impl.OrderImpl <em>Order</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.OrderImpl
		 * @see test1.impl.Test1PackageImpl#getOrder()
		 * @generated
		 */
		EClass ORDER = eINSTANCE.getOrder();

		/**
		 * The meta object literal for the '<em><b>Order Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER__ORDER_ID = eINSTANCE.getOrder_OrderId();

		/**
		 * The meta object literal for the '<em><b>Order Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER__ORDER_PRICE = eINSTANCE.getOrder_OrderPrice();

		/**
		 * The meta object literal for the '<em><b>Instructions</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER__INSTRUCTIONS = eINSTANCE.getOrder_Instructions();

		/**
		 * The meta object literal for the '<em><b>Discounted Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER__DISCOUNTED_PRICE = eINSTANCE.getOrder_DiscountedPrice();

		/**
		 * The meta object literal for the '<em><b>Source Location Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER__SOURCE_LOCATION_ID = eINSTANCE.getOrder_SourceLocationId();

		/**
		 * The meta object literal for the '<em><b>Destination Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER__DESTINATION_ID = eINSTANCE.getOrder_DestinationId();

		/**
		 * The meta object literal for the '<em><b>Tax</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER__TAX = eINSTANCE.getOrder_Tax();

		/**
		 * The meta object literal for the '<em><b>Delivery</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER__DELIVERY = eINSTANCE.getOrder_Delivery();

		/**
		 * The meta object literal for the '<em><b>Status Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__STATUS_ID = eINSTANCE.getOrder_StatusId();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__STATUS = eINSTANCE.getOrder_Status();

		/**
		 * The meta object literal for the '<em><b>Agent Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__AGENT_ID = eINSTANCE.getOrder_AgentId();

		/**
		 * The meta object literal for the '<em><b>Payment Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__PAYMENT_ID = eINSTANCE.getOrder_PaymentId();

		/**
		 * The meta object literal for the '<em><b>Promotion Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__PROMOTION_ID = eINSTANCE.getOrder_PromotionId();

		/**
		 * The meta object literal for the '<em><b>Discounts</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__DISCOUNTS = eINSTANCE.getOrder_Discounts();

		/**
		 * The meta object literal for the '<em><b>Customer Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__CUSTOMER_ID = eINSTANCE.getOrder_CustomerId();

		/**
		 * The meta object literal for the '<em><b>Transactions</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__TRANSACTIONS = eINSTANCE.getOrder_Transactions();

		/**
		 * The meta object literal for the '<em><b>Payments Info</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__PAYMENTS_INFO = eINSTANCE.getOrder_PaymentsInfo();

		/**
		 * The meta object literal for the '<em><b>Catalog</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER__CATALOG = eINSTANCE.getOrder_Catalog();

		/**
		 * The meta object literal for the '<em><b>Set Order Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___SET_ORDER_ID = eINSTANCE.getOrder__SetOrderId();

		/**
		 * The meta object literal for the '<em><b>Set Order Price</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___SET_ORDER_PRICE = eINSTANCE.getOrder__SetOrderPrice();

		/**
		 * The meta object literal for the '<em><b>Set Instructions</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___SET_INSTRUCTIONS = eINSTANCE.getOrder__SetInstructions();

		/**
		 * The meta object literal for the '<em><b>Set Discounted Price</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___SET_DISCOUNTED_PRICE = eINSTANCE.getOrder__SetDiscountedPrice();

		/**
		 * The meta object literal for the '<em><b>Set Source Location Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___SET_SOURCE_LOCATION_ID = eINSTANCE.getOrder__SetSourceLocationId();

		/**
		 * The meta object literal for the '<em><b>Set Tax</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___SET_TAX = eINSTANCE.getOrder__SetTax();

		/**
		 * The meta object literal for the '<em><b>Set Delivery Fee</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___SET_DELIVERY_FEE = eINSTANCE.getOrder__SetDeliveryFee();

		/**
		 * The meta object literal for the '<em><b>Set Oder Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___SET_ODER_ID = eINSTANCE.getOrder__SetOderId();

		/**
		 * The meta object literal for the '<em><b>Get Tax</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___GET_TAX = eINSTANCE.getOrder__GetTax();

		/**
		 * The meta object literal for the '<em><b>Get Delivery Fee</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER___GET_DELIVERY_FEE = eINSTANCE.getOrder__GetDeliveryFee();

		/**
		 * The meta object literal for the '{@link test1.impl.StatusImpl <em>Status</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.StatusImpl
		 * @see test1.impl.Test1PackageImpl#getStatus()
		 * @generated
		 */
		EClass STATUS = eINSTANCE.getStatus();

		/**
		 * The meta object literal for the '<em><b>Status Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATUS__STATUS_ID = eINSTANCE.getStatus_StatusId();

		/**
		 * The meta object literal for the '<em><b>Status Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATUS__STATUS_TYPE = eINSTANCE.getStatus_StatusType();

		/**
		 * The meta object literal for the '<em><b>Transactions</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATUS__TRANSACTIONS = eINSTANCE.getStatus_Transactions();

		/**
		 * The meta object literal for the '<em><b>Order</b></em>' container reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATUS__ORDER = eINSTANCE.getStatus_Order();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATUS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getStatus__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Status Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATUS___SET_STATUS_ID = eINSTANCE.getStatus__SetStatusId();

		/**
		 * The meta object literal for the '<em><b>Set Status Type</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATUS___SET_STATUS_TYPE = eINSTANCE.getStatus__SetStatusType();

		/**
		 * The meta object literal for the '<em><b>Get Status Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATUS___GET_STATUS_ID = eINSTANCE.getStatus__GetStatusId();

		/**
		 * The meta object literal for the '<em><b>Get Status Type</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATUS___GET_STATUS_TYPE = eINSTANCE.getStatus__GetStatusType();

		/**
		 * The meta object literal for the '{@link test1.impl.DiscountsImpl <em>Discounts</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.DiscountsImpl
		 * @see test1.impl.Test1PackageImpl#getDiscounts()
		 * @generated
		 */
		EClass DISCOUNTS = eINSTANCE.getDiscounts();

		/**
		 * The meta object literal for the '<em><b>Promotion Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DISCOUNTS__PROMOTION_ID = eINSTANCE.getDiscounts_PromotionId();

		/**
		 * The meta object literal for the '<em><b>Promotion Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DISCOUNTS__PROMOTION_NAME = eINSTANCE.getDiscounts_PromotionName();

		/**
		 * The meta object literal for the '<em><b>Promotion Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DISCOUNTS__PROMOTION_CODE = eINSTANCE.getDiscounts_PromotionCode();

		/**
		 * The meta object literal for the '<em><b>Order</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISCOUNTS__ORDER = eINSTANCE.getDiscounts_Order();

		/**
		 * The meta object literal for the '<em><b>Set Promotion Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DISCOUNTS___SET_PROMOTION_ID = eINSTANCE.getDiscounts__SetPromotionId();

		/**
		 * The meta object literal for the '<em><b>Set Promotion Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DISCOUNTS___SET_PROMOTION_NAME = eINSTANCE.getDiscounts__SetPromotionName();

		/**
		 * The meta object literal for the '<em><b>Set Promotion Code</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DISCOUNTS___SET_PROMOTION_CODE = eINSTANCE.getDiscounts__SetPromotionCode();

		/**
		 * The meta object literal for the '<em><b>Get Promotion Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DISCOUNTS___GET_PROMOTION_ID = eINSTANCE.getDiscounts__GetPromotionId();

		/**
		 * The meta object literal for the '<em><b>Get Promotion Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DISCOUNTS___GET_PROMOTION_NAME = eINSTANCE.getDiscounts__GetPromotionName();

		/**
		 * The meta object literal for the '<em><b>Get Promotion Code</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DISCOUNTS___GET_PROMOTION_CODE = eINSTANCE.getDiscounts__GetPromotionCode();

		/**
		 * The meta object literal for the '{@link test1.impl.CatalogImpl <em>Catalog</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.CatalogImpl
		 * @see test1.impl.Test1PackageImpl#getCatalog()
		 * @generated
		 */
		EClass CATALOG = eINSTANCE.getCatalog();

		/**
		 * The meta object literal for the '<em><b>Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CATALOG__PRICE = eINSTANCE.getCatalog_Price();

		/**
		 * The meta object literal for the '<em><b>Product Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CATALOG__PRODUCT_ID = eINSTANCE.getCatalog_ProductId();

		/**
		 * The meta object literal for the '<em><b>Product</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CATALOG__PRODUCT = eINSTANCE.getCatalog_Product();

		/**
		 * The meta object literal for the '<em><b>Order</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CATALOG__ORDER = eINSTANCE.getCatalog_Order();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CATALOG___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getCatalog__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Price</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CATALOG___SET_PRICE = eINSTANCE.getCatalog__SetPrice();

		/**
		 * The meta object literal for the '<em><b>Get Price</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CATALOG___GET_PRICE = eINSTANCE.getCatalog__GetPrice();

		/**
		 * The meta object literal for the '{@link test1.impl.ProductImpl <em>Product</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.ProductImpl
		 * @see test1.impl.Test1PackageImpl#getProduct()
		 * @generated
		 */
		EClass PRODUCT = eINSTANCE.getProduct();

		/**
		 * The meta object literal for the '<em><b>Product Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT__PRODUCT_ID = eINSTANCE.getProduct_ProductId();

		/**
		 * The meta object literal for the '<em><b>Product Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT__PRODUCT_NAME = eINSTANCE.getProduct_ProductName();

		/**
		 * The meta object literal for the '<em><b>Product Descripton</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT__PRODUCT_DESCRIPTON = eINSTANCE.getProduct_ProductDescripton();

		/**
		 * The meta object literal for the '<em><b>Category Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCT__CATEGORY_ID = eINSTANCE.getProduct_CategoryId();

		/**
		 * The meta object literal for the '<em><b>Product Category</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCT__PRODUCT_CATEGORY = eINSTANCE.getProduct_ProductCategory();

		/**
		 * The meta object literal for the '<em><b>Order Items Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCT__ORDER_ITEMS_ID = eINSTANCE.getProduct_OrderItemsId();

		/**
		 * The meta object literal for the '<em><b>Order Items</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCT__ORDER_ITEMS = eINSTANCE.getProduct_OrderItems();

		/**
		 * The meta object literal for the '<em><b>Catalog</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCT__CATALOG = eINSTANCE.getProduct_Catalog();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getProduct__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Product Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT___SET_PRODUCT_ID = eINSTANCE.getProduct__SetProductId();

		/**
		 * The meta object literal for the '<em><b>Set Product Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT___SET_PRODUCT_NAME = eINSTANCE.getProduct__SetProductName();

		/**
		 * The meta object literal for the '<em><b>Set Product Description</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT___SET_PRODUCT_DESCRIPTION = eINSTANCE.getProduct__SetProductDescription();

		/**
		 * The meta object literal for the '<em><b>Get Product Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT___GET_PRODUCT_ID = eINSTANCE.getProduct__GetProductId();

		/**
		 * The meta object literal for the '<em><b>Get Product Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT___GET_PRODUCT_NAME = eINSTANCE.getProduct__GetProductName();

		/**
		 * The meta object literal for the '<em><b>Get Product Description</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT___GET_PRODUCT_DESCRIPTION = eINSTANCE.getProduct__GetProductDescription();

		/**
		 * The meta object literal for the '{@link test1.impl.ProductCategoryImpl <em>Product Category</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.ProductCategoryImpl
		 * @see test1.impl.Test1PackageImpl#getProductCategory()
		 * @generated
		 */
		EClass PRODUCT_CATEGORY = eINSTANCE.getProductCategory();

		/**
		 * The meta object literal for the '<em><b>Category Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT_CATEGORY__CATEGORY_ID = eINSTANCE.getProductCategory_CategoryId();

		/**
		 * The meta object literal for the '<em><b>Category Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT_CATEGORY__CATEGORY_NAME = eINSTANCE.getProductCategory_CategoryName();

		/**
		 * The meta object literal for the '<em><b>Product</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCT_CATEGORY__PRODUCT = eINSTANCE.getProductCategory_Product();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT_CATEGORY___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getProductCategory__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Category Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT_CATEGORY___SET_CATEGORY_ID = eINSTANCE.getProductCategory__SetCategoryId();

		/**
		 * The meta object literal for the '<em><b>Set Category Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT_CATEGORY___SET_CATEGORY_NAME = eINSTANCE.getProductCategory__SetCategoryName();

		/**
		 * The meta object literal for the '<em><b>Get Category Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT_CATEGORY___GET_CATEGORY_ID = eINSTANCE.getProductCategory__GetCategoryId();

		/**
		 * The meta object literal for the '<em><b>Getcategory Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PRODUCT_CATEGORY___GETCATEGORY_NAME = eINSTANCE.getProductCategory__GetcategoryName();

		/**
		 * The meta object literal for the '{@link test1.impl.OrderItemsImpl <em>Order Items</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.OrderItemsImpl
		 * @see test1.impl.Test1PackageImpl#getOrderItems()
		 * @generated
		 */
		EClass ORDER_ITEMS = eINSTANCE.getOrderItems();

		/**
		 * The meta object literal for the '<em><b>Order Items Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER_ITEMS__ORDER_ITEMS_ID = eINSTANCE.getOrderItems_OrderItemsId();

		/**
		 * The meta object literal for the '<em><b>Product Quantity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER_ITEMS__PRODUCT_QUANTITY = eINSTANCE.getOrderItems_ProductQuantity();

		/**
		 * The meta object literal for the '<em><b>Product Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_ITEMS__PRODUCT_ID = eINSTANCE.getOrderItems_ProductId();

		/**
		 * The meta object literal for the '<em><b>Order Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_ITEMS__ORDER_ID = eINSTANCE.getOrderItems_OrderId();

		/**
		 * The meta object literal for the '<em><b>Product</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_ITEMS__PRODUCT = eINSTANCE.getOrderItems_Product();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_ITEMS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getOrderItems__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Order Items Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_ITEMS___SET_ORDER_ITEMS_ID = eINSTANCE.getOrderItems__SetOrderItemsId();

		/**
		 * The meta object literal for the '<em><b>Set Product Quantity</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_ITEMS___SET_PRODUCT_QUANTITY = eINSTANCE.getOrderItems__SetProductQuantity();

		/**
		 * The meta object literal for the '<em><b>Get Order Items Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_ITEMS___GET_ORDER_ITEMS_ID = eINSTANCE.getOrderItems__GetOrderItemsId();

		/**
		 * The meta object literal for the '<em><b>Get Product Quantity</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_ITEMS___GET_PRODUCT_QUANTITY = eINSTANCE.getOrderItems__GetProductQuantity();

		/**
		 * The meta object literal for the '{@link test1.impl.RatingsImpl <em>Ratings</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.RatingsImpl
		 * @see test1.impl.Test1PackageImpl#getRatings()
		 * @generated
		 */
		EClass RATINGS = eINSTANCE.getRatings();

		/**
		 * The meta object literal for the '<em><b>Rating Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RATINGS__RATING_ID = eINSTANCE.getRatings_RatingId();

		/**
		 * The meta object literal for the '<em><b>Rating</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RATINGS__RATING = eINSTANCE.getRatings_Rating();

		/**
		 * The meta object literal for the '<em><b>Orderfeedback</b></em>' container reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RATINGS__ORDERFEEDBACK = eINSTANCE.getRatings_Orderfeedback();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RATINGS___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getRatings__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Set Rating Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RATINGS___SET_RATING_ID = eINSTANCE.getRatings__SetRatingId();

		/**
		 * The meta object literal for the '<em><b>Set Rating</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RATINGS___SET_RATING = eINSTANCE.getRatings__SetRating();

		/**
		 * The meta object literal for the '<em><b>Get Rating Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RATINGS___GET_RATING_ID = eINSTANCE.getRatings__GetRatingId();

		/**
		 * The meta object literal for the '<em><b>Get Rating</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RATINGS___GET_RATING = eINSTANCE.getRatings__GetRating();

		/**
		 * The meta object literal for the '{@link test1.impl.OrderFeedbackImpl <em>Order Feedback</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.OrderFeedbackImpl
		 * @see test1.impl.Test1PackageImpl#getOrderFeedback()
		 * @generated
		 */
		EClass ORDER_FEEDBACK = eINSTANCE.getOrderFeedback();

		/**
		 * The meta object literal for the '<em><b>Product Feedback</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER_FEEDBACK__PRODUCT_FEEDBACK = eINSTANCE.getOrderFeedback_ProductFeedback();

		/**
		 * The meta object literal for the '<em><b>Delivery Agent Feedback</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER_FEEDBACK__DELIVERY_AGENT_FEEDBACK = eINSTANCE.getOrderFeedback_DeliveryAgentFeedback();

		/**
		 * The meta object literal for the '<em><b>Product Rating Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ORDER_FEEDBACK__PRODUCT_RATING_ID = eINSTANCE.getOrderFeedback_ProductRatingId();

		/**
		 * The meta object literal for the '<em><b>Delivery Agent Rating Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_FEEDBACK__DELIVERY_AGENT_RATING_ID = eINSTANCE.getOrderFeedback_DeliveryAgentRatingId();

		/**
		 * The meta object literal for the '<em><b>Rating Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_FEEDBACK__RATING_ID = eINSTANCE.getOrderFeedback_RatingId();

		/**
		 * The meta object literal for the '<em><b>Order Id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_FEEDBACK__ORDER_ID = eINSTANCE.getOrderFeedback_OrderId();

		/**
		 * The meta object literal for the '<em><b>Ratings</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ORDER_FEEDBACK__RATINGS = eINSTANCE.getOrderFeedback_Ratings();

		/**
		 * The meta object literal for the '<em><b>Set Product Feedback</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_FEEDBACK___SET_PRODUCT_FEEDBACK = eINSTANCE.getOrderFeedback__SetProductFeedback();

		/**
		 * The meta object literal for the '<em><b>Set Delivery Agent Feedback</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_FEEDBACK___SET_DELIVERY_AGENT_FEEDBACK = eINSTANCE.getOrderFeedback__SetDeliveryAgentFeedback();

		/**
		 * The meta object literal for the '<em><b>Set Product Rating Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_FEEDBACK___SET_PRODUCT_RATING_ID = eINSTANCE.getOrderFeedback__SetProductRatingId();

		/**
		 * The meta object literal for the '<em><b>Set Delivery Agent Rating Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_FEEDBACK___SET_DELIVERY_AGENT_RATING_ID = eINSTANCE.getOrderFeedback__SetDeliveryAgentRatingId();

		/**
		 * The meta object literal for the '<em><b>Get Product Feedback</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_FEEDBACK___GET_PRODUCT_FEEDBACK = eINSTANCE.getOrderFeedback__GetProductFeedback();

		/**
		 * The meta object literal for the '<em><b>Get Delivery Agent Feedback</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_FEEDBACK___GET_DELIVERY_AGENT_FEEDBACK = eINSTANCE.getOrderFeedback__GetDeliveryAgentFeedback();

		/**
		 * The meta object literal for the '<em><b>Get Product Rating Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_FEEDBACK___GET_PRODUCT_RATING_ID = eINSTANCE.getOrderFeedback__GetProductRatingId();

		/**
		 * The meta object literal for the '<em><b>Get Delivery Agent Rating Id</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ORDER_FEEDBACK___GET_DELIVERY_AGENT_RATING_ID = eINSTANCE.getOrderFeedback__GetDeliveryAgentRatingId();

		/**
		 * The meta object literal for the '{@link test1.impl.PrimitiveTypesDateImpl <em>Primitive Types Date</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.PrimitiveTypesDateImpl
		 * @see test1.impl.Test1PackageImpl#getPrimitiveTypesDate()
		 * @generated
		 */
		EClass PRIMITIVE_TYPES_DATE = eINSTANCE.getPrimitiveTypesDate();

		/**
		 * The meta object literal for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.test1DateImpl
		 * @see test1.impl.Test1PackageImpl#gettest1Date()
		 * @generated
		 */
		EClass TEST1_DATE = eINSTANCE.gettest1Date();

		/**
		 * The meta object literal for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.test1DateImpl
		 * @see test1.impl.Test1PackageImpl#gettest1Date()
		 * @generated
		 */
		EClass TEST1_DATE = eINSTANCE.gettest1Date();

		/**
		 * The meta object literal for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.test1DateImpl
		 * @see test1.impl.Test1PackageImpl#gettest1Date()
		 * @generated
		 */
		EClass TEST1_DATE = eINSTANCE.gettest1Date();

		/**
		 * The meta object literal for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.test1DateImpl
		 * @see test1.impl.Test1PackageImpl#gettest1Date()
		 * @generated
		 */
		EClass TEST1_DATE = eINSTANCE.gettest1Date();

		/**
		 * The meta object literal for the '{@link test1.impl.test1DateImpl <em>test1 Date</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.impl.test1DateImpl
		 * @see test1.impl.Test1PackageImpl#gettest1Date()
		 * @generated
		 */
		EClass TEST1_DATE = eINSTANCE.gettest1Date();

		/**
		 * The meta object literal for the '{@link test1.Gender <em>Gender</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see test1.Gender
		 * @see test1.impl.Test1PackageImpl#getGender()
		 * @generated
		 */
		EEnum GENDER = eINSTANCE.getGender();

	}

} //Test1Package
