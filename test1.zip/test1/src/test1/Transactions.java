/**
 */
package test1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transactions</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link test1.Transactions#getTransactionId <em>Transaction Id</em>}</li>
 *   <li>{@link test1.Transactions#getTotalPrice <em>Total Price</em>}</li>
 *   <li>{@link test1.Transactions#getTransactionDate <em>Transaction Date</em>}</li>
 *   <li>{@link test1.Transactions#getTransactionStatus <em>Transaction Status</em>}</li>
 *   <li>{@link test1.Transactions#getOrderId <em>Order Id</em>}</li>
 *   <li>{@link test1.Transactions#getStatus <em>Status</em>}</li>
 *   <li>{@link test1.Transactions#getOrder <em>Order</em>}</li>
 *   <li>{@link test1.Transactions#getPaymentId <em>Payment Id</em>}</li>
 *   <li>{@link test1.Transactions#getStatusId <em>Status Id</em>}</li>
 *   <li>{@link test1.Transactions#getPaymentsInfo <em>Payments Info</em>}</li>
 * </ul>
 *
 * @see test1.Test1Package#getTransactions()
 * @model
 * @generated
 */
public interface Transactions extends EObject {
	/**
	 * Returns the value of the '<em><b>Transaction Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transaction Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transaction Id</em>' attribute.
	 * @see #setTransactionId(String)
	 * @see test1.Test1Package#getTransactions_TransactionId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getTransactionId();

	/**
	 * Sets the value of the '{@link test1.Transactions#getTransactionId <em>Transaction Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transaction Id</em>' attribute.
	 * @see #getTransactionId()
	 * @generated
	 */
	void setTransactionId(String value);

	/**
	 * Returns the value of the '<em><b>Total Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Total Price</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Total Price</em>' attribute.
	 * @see #setTotalPrice(float)
	 * @see test1.Test1Package#getTransactions_TotalPrice()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	float getTotalPrice();

	/**
	 * Sets the value of the '{@link test1.Transactions#getTotalPrice <em>Total Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Total Price</em>' attribute.
	 * @see #getTotalPrice()
	 * @generated
	 */
	void setTotalPrice(float value);

	/**
	 * Returns the value of the '<em><b>Transaction Date</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transaction Date</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transaction Date</em>' containment reference.
	 * @see #setTransactionDate(Date)
	 * @see test1.Test1Package#getTransactions_TransactionDate()
	 * @model containment="true" required="true" ordered="false"
	 * @generated
	 */
	Date getTransactionDate();

	/**
	 * Sets the value of the '{@link test1.Transactions#getTransactionDate <em>Transaction Date</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transaction Date</em>' containment reference.
	 * @see #getTransactionDate()
	 * @generated
	 */
	void setTransactionDate(Date value);

	/**
	 * Returns the value of the '<em><b>Transaction Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transaction Status</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transaction Status</em>' attribute.
	 * @see #setTransactionStatus(String)
	 * @see test1.Test1Package#getTransactions_TransactionStatus()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getTransactionStatus();

	/**
	 * Sets the value of the '{@link test1.Transactions#getTransactionStatus <em>Transaction Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transaction Status</em>' attribute.
	 * @see #getTransactionStatus()
	 * @generated
	 */
	void setTransactionStatus(String value);

	/**
	 * Returns the value of the '<em><b>Order Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Id</em>' reference.
	 * @see #setOrderId(Order)
	 * @see test1.Test1Package#getTransactions_OrderId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Order getOrderId();

	/**
	 * Sets the value of the '{@link test1.Transactions#getOrderId <em>Order Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Id</em>' reference.
	 * @see #getOrderId()
	 * @generated
	 */
	void setOrderId(Order value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Status#getTransactions <em>Transactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Status</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' reference.
	 * @see #setStatus(Status)
	 * @see test1.Test1Package#getTransactions_Status()
	 * @see test1.Status#getTransactions
	 * @model opposite="transactions" required="true" ordered="false"
	 * @generated
	 */
	Status getStatus();

	/**
	 * Sets the value of the '{@link test1.Transactions#getStatus <em>Status</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' reference.
	 * @see #getStatus()
	 * @generated
	 */
	void setStatus(Status value);

	/**
	 * Returns the value of the '<em><b>Order</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link test1.Order#getTransactions <em>Transactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order</em>' reference.
	 * @see #setOrder(Order)
	 * @see test1.Test1Package#getTransactions_Order()
	 * @see test1.Order#getTransactions
	 * @model opposite="transactions" required="true" ordered="false"
	 * @generated
	 */
	Order getOrder();

	/**
	 * Sets the value of the '{@link test1.Transactions#getOrder <em>Order</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order</em>' reference.
	 * @see #getOrder()
	 * @generated
	 */
	void setOrder(Order value);

	/**
	 * Returns the value of the '<em><b>Payment Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Payment Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payment Id</em>' reference.
	 * @see #setPaymentId(PaymentsInfo)
	 * @see test1.Test1Package#getTransactions_PaymentId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	PaymentsInfo getPaymentId();

	/**
	 * Sets the value of the '{@link test1.Transactions#getPaymentId <em>Payment Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payment Id</em>' reference.
	 * @see #getPaymentId()
	 * @generated
	 */
	void setPaymentId(PaymentsInfo value);

	/**
	 * Returns the value of the '<em><b>Status Id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Status Id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status Id</em>' reference.
	 * @see #setStatusId(Status)
	 * @see test1.Test1Package#getTransactions_StatusId()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Status getStatusId();

	/**
	 * Sets the value of the '{@link test1.Transactions#getStatusId <em>Status Id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status Id</em>' reference.
	 * @see #getStatusId()
	 * @generated
	 */
	void setStatusId(Status value);

	/**
	 * Returns the value of the '<em><b>Payments Info</b></em>' containment reference.
	 * It is bidirectional and its opposite is '{@link test1.PaymentsInfo#getTransactions <em>Transactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Payments Info</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payments Info</em>' containment reference.
	 * @see #setPaymentsInfo(PaymentsInfo)
	 * @see test1.Test1Package#getTransactions_PaymentsInfo()
	 * @see test1.PaymentsInfo#getTransactions
	 * @model opposite="transactions" containment="true" required="true" ordered="false"
	 * @generated
	 */
	PaymentsInfo getPaymentsInfo();

	/**
	 * Sets the value of the '{@link test1.Transactions#getPaymentsInfo <em>Payments Info</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payments Info</em>' containment reference.
	 * @see #getPaymentsInfo()
	 * @generated
	 */
	void setPaymentsInfo(PaymentsInfo value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setTotalPrice();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setTransactionDate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setTransactionStatus();

} // Transactions
